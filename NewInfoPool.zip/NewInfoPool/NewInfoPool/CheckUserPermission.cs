﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace NewInfoPool
{
    public class CheckUserPermission
    {
        public static bool Ispermitted(string appDec)
        {
            //ProductCode=3 is Staff

            bool Result = false;
            SPWeb web = SPContext.Current.Web;
            
            try
            {
                switch (appDec)
                {
                    case "AccountBalance":
                        if (web.Groups["VAccBalance"].ContainsCurrentUser)
                        {
                            Result = true;
                        }
                        else
                        {
                            Result = false;
                        }
                        break;
                    //case "CotDetails":
                    //    if (web.Groups["VCotDetails"].ContainsCurrentUser)
                    //    {
                    //        Result = true;
                    //    }
                    //    else
                    //    {
                    //        Result = false;
                    //    }
                    //    break;
                    case "AccountMandate":
                        if (web.Groups["VAccMandate"].ContainsCurrentUser)
                        {
                            Result = true;
                        }
                        else
                        {
                            Result = false;
                        }
                        break;
                    case "HighQualityStatement":
                        if (web.Groups["VHighQualityStatement"].ContainsCurrentUser)
                        {
                            Result =true;
                        }
                        else
                        {
                            Result =false;
                        }
                        break;
                    case "TransactionHistory":
                        if (web.Groups["VTransactionHistory"].ContainsCurrentUser)
                        {
                            Result = true;
                        }
                        else
                        {
                            Result = false;
                        }
                        break;
                    case "DevelopementGroup":
                        if (web.Groups["DevelopementGroup"].ContainsCurrentUser)
                        {
                            Result = true;
                        }
                        else
                        {
                            Result = false;
                        }
                        break;
                    default:
                        Result = false;
                        break;

                }
            }
            catch (Exception)
            {
                
                throw;
            }

            return Result;
        }

    }
}
