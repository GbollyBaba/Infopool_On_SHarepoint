﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Linq;
using NewInfoPool;
using InfoPool.NewMainMenu;

namespace NewInfoPool.NewAccessMasterPage
{
    public class AccessMaster : MasterPage
    {
        protected Literal topliteralmenu;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                topliteralmenu.Text = GetMenuitems();
  
            }

        }


        StringBuilder strBuilder = new StringBuilder();
        public string GetMenuitems()
        {
            SPSite site = SPContext.Current.Site;
            SPSecurity.RunWithElevatedPrivileges(delegate
                {


                    using (NewMainMenuEntity menuContext = new NewMainMenuEntity(site.RootWeb.Url))
                    {
                        var menuitem = from menu in menuContext.NewMainMenu
                                       where menu.ParentIDId.Value == null
                                       select new { ID = menu.Id, Title = menu.Title, URL = menu.URL };
                        foreach (var item in menuitem)
                        {

                            //TopMenu
                            string menutitle = (item.Title == null) ? "" : item.Title;
                            strBuilder.AppendLine("     <li>                                                                            ");
                            strBuilder.AppendLine("         <a href=\"" + item.URL + "\">" + menutitle + "</a>                                         ");
                            //SubMenu
                            strBuilder.AppendLine("<ul>");
                            strBuilder.AppendLine(this.SubLevelMenuItems(item.ID));

                            strBuilder.AppendLine("     </li>                                                                           ");
                        }

                    }
                   
                });
            return strBuilder.ToString();
        }
        public string SubLevelMenuItems(int? item)
        {
            SPSite site = SPContext.Current.Site;
            StringBuilder strsubBuilder = new StringBuilder();
            SPSecurity.RunWithElevatedPrivileges(delegate
            {


                using (NewMainMenuEntity menuContext = new NewMainMenuEntity(site.RootWeb.Url))
            {
                var menuitem = from menu in menuContext.NewMainMenu
                               where menu.ParentIDId.Value == item
                               select new { Title = menu.Title, Url = menu.URL, NewWindow = menu.NewWindow };
                foreach (var subitem in menuitem)
                {
                    strsubBuilder.AppendLine("     <li>                                                                            ");
                    if (subitem.NewWindow == true)
                    {
                        strsubBuilder.AppendLine("         <a href=\"" + subitem.Url + "\"+ target=\"_blank\">" + subitem.Title + "</a>                                         ");
                    }
                    else
                    {
                        if (subitem.Title == "AuditLog")
                        {
                            if (CheckUserPermission.Ispermitted("DevelopementGroup"))
                            {
                                strsubBuilder.AppendLine("         <a href=\"" + subitem.Url + "\">" + subitem.Title + "</a>                                         ");
                            }
                           
                        }
                        else
                        {
                            strsubBuilder.AppendLine("         <a href=\"" + subitem.Url + "\">" + subitem.Title + "</a>                                         ");
                        }
                    }
                    strsubBuilder.AppendLine("     </li>                                                                           ");
                }
                strsubBuilder.AppendLine("     </ul>                                                                            ");

            }
           
        });
            return strsubBuilder.ToString();
        }

    }
}
