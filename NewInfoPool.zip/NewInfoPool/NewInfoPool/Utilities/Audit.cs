﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Net;
using System.Web;
using AuditSpace;

namespace NewInfoPool.Utilities
{
    public class Audit
    {
        //public static void LogTransaction(string Balance,string CurrentUser,string AccountName, string AccountNumber,string ActionPerform)
        //{
        //    string ip; 

        //    string[] currentuser = CurrentUser.Split('\\');
        //    CurrentUser = currentuser[1];
        //    string hostname = Dns.GetHostName();
        //    IPHostEntry ipEntry = Dns.GetHostEntry(hostname);
        //    System.Net.IPAddress addr = ipEntry.AddressList[0];

        //    var IPAddress = (from a in Dns.GetHostEntry(Dns.GetHostName()).AddressList
        //              where a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork
        //              select a).First().ToString();



        //    SPSecurity.RunWithElevatedPrivileges(delegate
        //    {
        //    //Call 
        //    SPSite root = new SPSite(SPContext.Current.Web.Url);
        //    SPWeb web = root.OpenWeb();
        //    web.AllowUnsafeUpdates = true;
        //    SPList AudList = web.Lists["AuditLog"];

        //    SPListItem item = AudList.Items.Add();
        //    item["Current User"] = CurrentUser;//Sharepoint User
        //    item["IP Address"] = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];

        //    item["Server IP Address"] = addr;
        //    item["Account Name"] = AccountName;
        //    item["Account Number"] = AccountNumber;
        //    item["Balance"] = Balance;
        //    item["ActionPerformed"] = ActionPerform;
        //    item["DateModified"] = DateTime.Now.ToString();
        //    item["Server Name"] = HttpContext.Current.Request.ServerVariables["SERVER_NAME"].ToString();
        //    item["MachineName"] = System.Environment.MachineName;
        //    item["UserDomainName"] = System.Environment.UserDomainName;
        //    item["MachineUserName"] = System.Environment.UserName;//Machine User
        //    item.Update();
        //    web.AllowUnsafeUpdates = false;
        //    if (web != null)
        //        web.Dispose();
        //    if (root != null)
        //        root.Dispose();
        //    });
        //}


        public static void LogTransaction(string Balance, string CurrentUser, string AccountName, string AccountNumber, string ActionPerform)
        {
            //string ip;

            string[] currentuser = CurrentUser.Split('\\');
            CurrentUser = currentuser[1];
            string hostname = Dns.GetHostName();
            IPHostEntry ipEntry = Dns.GetHostEntry(hostname);
            System.Net.IPAddress addr = ipEntry.AddressList[0];

            var IPAddress = (from a in Dns.GetHostEntry(Dns.GetHostName()).AddressList
                             where a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork
                             select a).First().ToString();

            AccountAudit item = new AccountAudit();
            string IppAdress=HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            string ServerName=HttpContext.Current.Request.ServerVariables["SERVER_NAME"].ToString();
            string MachineName= System.Environment.MachineName;
            string UserDomainName= System.Environment.UserDomainName;
            string MachineUserName= System.Environment.UserName;
            string b= item.getInsertAuditLog(CurrentUser,IppAdress,AccountName, AccountNumber, Balance, addr.ToString(),ServerName,MachineName,UserDomainName,MachineUserName, ActionPerform);
            
        }

    }
}
