﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Web.UI.HtmlControls;
using System.Web;
using NewInfoPool.Layouts.NewInfoPool;
using Microsoft.SharePoint;

namespace NewInfoPool.Utilities
{
    public class PrintStatement1
    {
        public void GetHighQualityStatement(string AccountNumber, string startdate, string enddate)
        {
           
            string acctbranch = string.Empty;
            string Date = string.Empty;
            string TransactionDetails = string.Empty;
            string Reference = string.Empty;
            string ValueDate = string.Empty;
            string Withdrawl = string.Empty;
            string Lodgements = string.Empty;
            string Balance = string.Empty;
            string AccountNumberHolder = string.Empty;
            string openingbalanceholder = string.Empty;
            string SummaryStatementholder = string.Empty;
            string UClearedBalanceHolder = string.Empty;
            string CurrencyHolder = string.Empty;
            string Totalwitdrawlholder = string.Empty;
            string ClearedBalanceHolders = string.Empty;

            AccountEnquiryGhana AccEnq = new AccountEnquiryGhana();
           
            AccEnq.Timeout = 90000000;
            CustomerAcctsWithTransactionInfo cusTransBranch = AccEnq.getAccountSummaryANDTransactions(AccountNumber, startdate, enddate);

            string customerToken = cusTransBranch.customerID;
            string[] cusToken = customerToken.Split('~');//To get Customer ID
            ClientDetails1 clientdetail = AccEnq.getCustomerDetails(cusToken[1]);
            TranDetails[] transdetail = cusTransBranch.acctsumm[0].tranDetails;
            CustomerAcctsInfo customerAccInfo = AccEnq.getAccountSummaryByCustomerID(cusToken[1].ToString());



            // Create a Document object
            iTextSharp.text.Rectangle pageSize = new iTextSharp.text.Rectangle(PageSize.A3);
            BaseColor basecolor = new BaseColor(222, 235, 249);
            pageSize.BackgroundColor = basecolor;

            var document = new Document(pageSize, 50, 5, 50, 25);
            // Create a new PdfWrite object, writing the output to a MemoryStream
            var output = new MemoryStream();
            PdfWriter writer = PdfWriter.GetInstance(document, output);
            WaterMark watermark = new WaterMark();

            // Open the Document for writing
            document.Open();
             watermark.onEndPage(writer, document);
             watermark.onEndPage(writer, document);
            PdfPTable table = new PdfPTable(4);
            table.HeaderRows = 8;
            table.FooterRows = 1;
            //After setting the HeaderRows property to a value n, the next n rows you add to your
            //table will be considered header rows, and will be repeated on each new page.
            table.SplitLate = false;//allow table not to split
            var branchfont = FontFactory.GetFont("Arial", 8, iTextSharp.text.Font.BOLD);

            PdfPCell header = new PdfPCell(new Phrase(""));
            Phrase headerphrase = new Phrase();
            //Use this to add Address
            StringBuilder builder = new StringBuilder();
            string[] clientdetails = clientdetail.addressline.Split('~');
            for (int m = 0; m < clientdetails.Length; m++)
            {
                if (clientdetails[m].ToString() == "Y")
                {
                    continue;
                }
                if (clientdetails[m].ToString().Contains(",,"))
                {
                    clientdetails[m].Replace(",,", ",");
                }

                builder.AppendLine(clientdetails[m]);

            }


            headerphrase.Add(builder.ToString());
            headerphrase.Font = branchfont;
            header.PaddingBottom = 1;
            header.AddElement(headerphrase);
            header.Border = 0;
            header.Colspan = 3;
            table.AddCell(header);


            PdfPCell header3 = new PdfPCell(new Phrase(""));
            header3.Border = 0;
            iTextSharp.text.Image image = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/images/AccessBankBACP/accessbank_logo.png");
            image.Alignment = iTextSharp.text.Image.ALIGN_LEFT;
            header3.AddElement(image);
            table.AddCell(header3);

            #region Font Region
            BaseFont bfTimes = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
            iTextSharp.text.Font times = new iTextSharp.text.Font(bfTimes, 10, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);

            BaseFont cellbasefont = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
            iTextSharp.text.Font cellcolor = new iTextSharp.text.Font(cellbasefont, 8, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);

            BaseFont summaryCellFont = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
            iTextSharp.text.Font summarycellcolor = new iTextSharp.text.Font(cellbasefont, 8, iTextSharp.text.Font.BOLD, BaseColor.BLACK);

            BaseFont bfTimes2 = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);//main table cell
            iTextSharp.text.Font times2 = new iTextSharp.text.Font(bfTimes2, 10, iTextSharp.text.Font.NORMAL, BaseColor.WHITE);

            var titleFont = FontFactory.GetFont("Arial", 8, iTextSharp.text.Font.BOLD);

            #endregion

            PdfPCell secondrow = new PdfPCell(new Phrase("Account Statement", times));//main table cell
            secondrow.Colspan = 2;
            secondrow.FixedHeight = 18f;
            secondrow.BorderColor = BaseColor.WHITE;
            secondrow.BorderWidthRight = 3;
            secondrow.BorderWidthLeft = 0;
            secondrow.BorderWidthTop = 0;
            secondrow.PaddingBottom = 5;
            secondrow.PaddingRight = 5;
            secondrow.BorderColorRight = basecolor;
            secondrow.BorderColorBottom = basecolor;
            secondrow.BackgroundColor = BaseColor.LIGHT_GRAY;
            table.AddCell(secondrow);



            PdfPCell thirdrow = new PdfPCell(new Phrase("Summary Details", times));
            thirdrow.Colspan = 2;
            thirdrow.FixedHeight = 18f;
            thirdrow.BorderColor = BaseColor.WHITE;
            thirdrow.BorderWidthRight = 0;
            thirdrow.BorderWidthTop = 0;
            thirdrow.PaddingBottom = 5;
            thirdrow.PaddingLeft = 5;
            thirdrow.BorderColorLeft = basecolor;
            thirdrow.BorderColorBottom = basecolor;
            thirdrow.BackgroundColor = BaseColor.LIGHT_GRAY;
            thirdrow.BorderWidthLeft = 3;
            table.AddCell(thirdrow);

            //To create Empty Space
            PdfPCell emptyCellsummary = new PdfPCell();
            emptyCellsummary.Colspan = 4;
            emptyCellsummary.FixedHeight = 2.5f;
            emptyCellsummary.BackgroundColor = basecolor;
            emptyCellsummary.Border = 0;
            emptyCellsummary.BorderWidthBottom = 0;
            table.AddCell(emptyCellsummary);

            PdfPTable nested = new PdfPTable(2);//inner table 1 for left hand mAIN CELL
            PdfPCell NestedRow1 = new PdfPCell(new Phrase("Summary Statement for", cellcolor)); //inner table cell
            NestedRow1.BorderColorBottom = basecolor;
            NestedRow1.BorderColorRight = basecolor;
            NestedRow1.BorderColorRight = basecolor;
            NestedRow1.BorderWidthRight = 1;
            NestedRow1.PaddingBottom = 2;
            nested.AddCell(NestedRow1);


            PdfPCell NestedRow2 = new PdfPCell(new Phrase(startdate + " To " + enddate, cellcolor));//inner table cell
            NestedRow2.BorderColorBottom = basecolor;
            NestedRow2.BorderWidthRight = 2;
            NestedRow2.PaddingBottom = 2;
            NestedRow2.BorderColorRight = basecolor;
            NestedRow2.BorderColorLeft = basecolor;
            nested.AddCell(NestedRow2);

            PdfPCell NestedRow11 = new PdfPCell(new Phrase("Currency", cellcolor));//inner table cell
            NestedRow11.BorderColorTop = basecolor;
            NestedRow11.BorderColorBottom = basecolor;
            NestedRow11.BorderColorRight = basecolor;
            NestedRow11.BorderWidthRight = 0;
            NestedRow11.PaddingBottom = 2;
            nested.AddCell(NestedRow11);


            PdfPCell NestedRow22 = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].accountcurrency, cellcolor));//inner table cell
            NestedRow22.BorderColorTop = basecolor;
            NestedRow22.BorderWidthRight = 1;
            NestedRow22.PaddingBottom = 2;
            NestedRow22.BorderColorRight = basecolor;
            NestedRow22.BorderColorLeft = basecolor;
            NestedRow22.BorderWidthRight = 2;
            NestedRow22.BorderColorBottom = basecolor;
            nested.AddCell(NestedRow22);

            PdfPCell AccountNameRow = new PdfPCell(new Phrase("Account Name", cellcolor));//inner table cell
            AccountNameRow.BorderColorTop = basecolor;
            AccountNameRow.BorderColorBottom = basecolor;
            AccountNameRow.BorderColorRight = basecolor;
            AccountNameRow.BorderWidthRight = 0;
            AccountNameRow.PaddingBottom = 2;
            AccountNameRow.BorderColorRight = basecolor;
            AccountNameRow.Colspan = 2;
            nested.AddCell(AccountNameRow);

            PdfPCell AccountAddressRow = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].accountname + "\n" + clientdetail.addressline, cellcolor));//inner table cell
            AccountAddressRow.BorderColorTop = basecolor;
            AccountAddressRow.BorderColorBottom = basecolor;
            AccountAddressRow.BorderColorRight = basecolor;
            AccountAddressRow.BorderWidthRight = 0;
            AccountAddressRow.PaddingBottom = 2;
            AccountAddressRow.Colspan = 2;
            AccountAddressRow.Rowspan = 4;
            AccountAddressRow.BorderColorRight = basecolor;
            AccountAddressRow.BorderColorBottom = basecolor;
            nested.AddCell(AccountAddressRow);

            PdfPCell nesthousing = new PdfPCell(nested);//main table cell  that hold inner table

            nesthousing.Padding = 0f;
            nesthousing.Colspan = 2;
            nesthousing.BorderWidthRight = 1;
            nesthousing.BorderColorRight = basecolor;
            table.AddCell(nesthousing);


            PdfPTable nested2 = new PdfPTable(2);//Inner table right for right hand main cell


            PdfPCell Nested2Row1 = new PdfPCell(new Phrase("ACCOUNT NO.", summarycellcolor));
            Nested2Row1.BorderColorBottom = basecolor;
            Nested2Row1.BorderColorRight = basecolor;
            Nested2Row1.BorderColorLeft = basecolor;
            Nested2Row1.BorderWidthLeft = 3;
            Nested2Row1.PaddingBottom = 2;
            Nested2Row1.PaddingLeft = 4;
            nested2.AddCell(Nested2Row1);


            PdfPCell Nested2Row2 = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].accountNo, cellcolor));
            Nested2Row2.BorderColorBottom = basecolor;
            Nested2Row2.BorderWidthLeft = 2;
            Nested2Row2.PaddingBottom = 2;
            Nested2Row2.BorderColorLeft = basecolor;
            nested2.AddCell(Nested2Row2);

            PdfPCell Nested2Row11 = new PdfPCell(new Phrase("OPENING BALANCE", summarycellcolor));
            Nested2Row11.BorderColorTop = basecolor;
            Nested2Row11.BorderColorBottom = basecolor;
            Nested2Row11.BorderColorRight = basecolor;
            Nested2Row11.BorderColorLeft = basecolor;
            Nested2Row11.BorderWidthLeft = 1;
            Nested2Row11.PaddingBottom = 2;
            Nested2Row11.PaddingLeft = 4;
            nested2.AddCell(Nested2Row11);


            PdfPCell Nested2Row22 = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].openingBalance, cellcolor));
            Nested2Row22.BorderColorTop = basecolor;
            Nested2Row22.BorderColorBottom = basecolor;
            Nested2Row22.BorderWidthLeft = 2;
            Nested2Row22.PaddingBottom = 2;
            Nested2Row22.BorderColorLeft = basecolor;
            nested2.AddCell(Nested2Row22);

            ////
            PdfPCell toalwithdralw = new PdfPCell(new Phrase("TOTALWITHDRAWLS", summarycellcolor));
            toalwithdralw.BorderColorTop = basecolor;
            toalwithdralw.BorderColorBottom = basecolor;
            toalwithdralw.BorderColorRight = basecolor;
            toalwithdralw.BorderColorLeft = basecolor;
            toalwithdralw.BorderWidthLeft = 1;
            toalwithdralw.PaddingBottom = 2;
            toalwithdralw.PaddingLeft = 4;
            nested2.AddCell(toalwithdralw);


            PdfPCell Totalwidralholder = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].withdrawals, cellcolor));
            Totalwidralholder.BorderColorTop = basecolor;
            Totalwidralholder.BorderColorBottom = basecolor;
            Totalwidralholder.BorderWidthLeft = 2;
            Totalwidralholder.PaddingBottom = 2;
            Totalwidralholder.BorderColorLeft = basecolor;
            nested2.AddCell(Totalwidralholder);

            PdfPCell totallodgement = new PdfPCell(new Phrase("TOTAL LODGEMENTS", summarycellcolor));
            totallodgement.BorderColorTop = basecolor;
            totallodgement.BorderColorBottom = basecolor;
            totallodgement.BorderColorRight = basecolor;
            totallodgement.BorderColorLeft = basecolor;
            totallodgement.BorderWidthLeft = 1;
            totallodgement.PaddingBottom = 2;
            totallodgement.PaddingLeft = 4;
            nested2.AddCell(totallodgement);


            PdfPCell TotalLodgementsHolder = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].lodgements, cellcolor));
            TotalLodgementsHolder.BorderColorTop = basecolor;
            TotalLodgementsHolder.BorderColorBottom = basecolor;
            TotalLodgementsHolder.BorderWidthLeft = 2;
            TotalLodgementsHolder.PaddingBottom = 2;
            TotalLodgementsHolder.BorderColorLeft = basecolor;
            nested2.AddCell(TotalLodgementsHolder);

            PdfPCell closingbalance = new PdfPCell(new Phrase("CLOSING BALANCE", summarycellcolor));
            closingbalance.BorderColorTop = basecolor;
            closingbalance.BorderColorBottom = basecolor;
            closingbalance.BorderColorRight = basecolor;
            closingbalance.BorderColorLeft = basecolor;
            closingbalance.BorderWidthLeft = 1;
            closingbalance.PaddingBottom = 2;
            closingbalance.PaddingLeft = 4;
            nested2.AddCell(closingbalance);


            PdfPCell ClosingBalanceholder = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].closingBalance, cellcolor));
            ClosingBalanceholder.BorderColorTop = basecolor;
            ClosingBalanceholder.BorderColorBottom = basecolor;
            ClosingBalanceholder.BorderWidthLeft = 2;
            ClosingBalanceholder.PaddingBottom = 2;
            ClosingBalanceholder.BorderColorLeft = basecolor;
            nested2.AddCell(ClosingBalanceholder);

            PdfPCell ClearedBalace = new PdfPCell(new Phrase("CLEARED BALANCE", summarycellcolor));
            ClearedBalace.BorderColorTop = basecolor;
            ClearedBalace.BorderColorBottom = basecolor;
            ClearedBalace.BorderColorRight = basecolor;
            ClearedBalace.BorderColorLeft = basecolor;
            ClearedBalace.BorderWidthLeft = 1;
            ClearedBalace.PaddingBottom = 2;
            ClearedBalace.PaddingLeft = 4;
            nested2.AddCell(ClearedBalace);


            PdfPCell ClearedBalanceHolder = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].clearedBalance, cellcolor));
            ClearedBalanceHolder.BorderColorTop = basecolor;
            ClearedBalanceHolder.BorderColorBottom = basecolor;
            ClearedBalanceHolder.BorderWidthLeft = 2;
            ClearedBalanceHolder.PaddingBottom = 2;
            ClearedBalanceHolder.BorderColorLeft = basecolor;
            nested2.AddCell(ClearedBalanceHolder);

            PdfPCell unClearedBalance = new PdfPCell(new Phrase("UNCLEARED BALANCE", summarycellcolor));
            unClearedBalance.BorderColorTop = basecolor;
            unClearedBalance.BorderColorBottom = BaseColor.BLACK;
            unClearedBalance.BorderColorRight = basecolor;
            unClearedBalance.BorderColorLeft = basecolor;
            unClearedBalance.BorderWidthLeft = 2;
            unClearedBalance.PaddingBottom = 2;
            unClearedBalance.BorderWidthBottom = 0;
            unClearedBalance.PaddingLeft = 4;
            nested2.AddCell(unClearedBalance);


            PdfPCell UnClearedBalanceHolder = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].unclearedBalance, cellcolor));
            UnClearedBalanceHolder.BorderColorTop = basecolor;
            UnClearedBalanceHolder.BorderColorBottom = BaseColor.BLACK;
            UnClearedBalanceHolder.BorderWidthLeft = 2;
            UnClearedBalanceHolder.PaddingBottom = 2;
            UnClearedBalanceHolder.BorderColorLeft = basecolor;
            nested2.AddCell(UnClearedBalanceHolder);
            //nested2.SpacingBefore = 10f;

            PdfPCell nesthousing2 = new PdfPCell(nested2);

            nesthousing2.Padding = 0f;
            nesthousing2.Colspan = 2;
            nesthousing2.BorderWidthLeft = 1;
            nesthousing2.BorderColorLeft = BaseColor.WHITE;
            table.AddCell(nesthousing2);

            //To create Empty Space
            PdfPCell emptyCell = new PdfPCell();
            emptyCell.Colspan = 4;
            emptyCell.FixedHeight = 2.5f;
            emptyCell.BackgroundColor = basecolor;
            emptyCell.Border = 0;
            table.AddCell(emptyCell);

            PdfPCell tabrow = new PdfPCell(new Phrase("PRIVATE & CONFIDENTIAL", times));//main table cell
            tabrow.Colspan = 2;
            tabrow.FixedHeight = 18f;
            tabrow.BorderColor = BaseColor.WHITE;
            tabrow.BorderWidthRight = 3;
            tabrow.BorderWidthLeft = 0;
            tabrow.BorderWidthTop = 0;
            tabrow.PaddingBottom = 5;
            tabrow.PaddingRight = 5;
            tabrow.BorderColorRight = basecolor;
            tabrow.BorderColorBottom = basecolor;
            tabrow.BackgroundColor = BaseColor.LIGHT_GRAY;
            table.AddCell(tabrow);

            PdfPCell tabrow2 = new PdfPCell(new Phrase(cusTransBranch.acctsumm[0].accountproduct, times));
            tabrow2.Colspan = 2;
            tabrow2.FixedHeight = 18f;
            tabrow2.BorderColor = BaseColor.WHITE;
            tabrow2.BorderWidthRight = 0;
            tabrow2.BorderWidthTop = 0;
            tabrow2.PaddingBottom = 5;
            tabrow2.PaddingLeft = 5;
            tabrow2.BorderColorLeft = basecolor;
            tabrow2.BorderColorBottom = basecolor;
            tabrow2.BackgroundColor = BaseColor.LIGHT_GRAY;
            tabrow2.BorderWidthLeft = 3;
            table.AddCell(tabrow2);

            //26-09-2014
            #region
            PdfPTable b4lasttablenested = new PdfPTable(10);//last inner table 



            b4lasttablenested.AddCell(new Phrase("Date", titleFont));

            PdfPCell b4TransCell2 = new PdfPCell();
            Phrase b4Transphrase = new Phrase();
            b4Transphrase.Font = titleFont;
            b4TransCell2.Colspan = 3;
            b4Transphrase.Add("Transaction Details");
            b4TransCell2.VerticalAlignment = 1;
            b4TransCell2.AddElement(b4Transphrase);
            b4lasttablenested.AddCell(b4TransCell2);

            PdfPCell b4TransCell2r = new PdfPCell();
            Phrase b4Transphrase2r = new Phrase();
            b4Transphrase2r.Font = titleFont;
            b4TransCell2r.Colspan = 2;
            b4Transphrase2r.Add("Refence");
            b4TransCell2r.VerticalAlignment = 1;
            b4TransCell2r.AddElement(b4Transphrase2r);

            b4lasttablenested.AddCell(b4TransCell2r);



            //lasttablenested.AddCell(new Phrase("Refence", titleFont));
            b4lasttablenested.AddCell(new Phrase("Value Date", titleFont));
            b4lasttablenested.AddCell(new Phrase("Withdrawals", titleFont));
            b4lasttablenested.AddCell(new Phrase("Lodgements", titleFont));
            b4lasttablenested.AddCell(new Phrase("Balance", titleFont));


            PdfPCell b4LastCell = new PdfPCell(b4lasttablenested);

            b4LastCell.Padding = 0f;
            b4LastCell.Colspan = 4;
            b4LastCell.BorderWidthRight = 1;
            b4LastCell.BorderColorRight = BaseColor.WHITE;
            b4LastCell.BorderColorTop = basecolor;
            table.AddCell(b4LastCell);

            #endregion


            //To create Empty Space
            PdfPCell emptyCell2 = new PdfPCell();
            emptyCell2.Colspan = 4;
            emptyCell2.FixedHeight = 2.5f;
            emptyCell2.BackgroundColor = basecolor;
            emptyCell2.Border = 0;
            table.AddCell(emptyCell2);


            //Last Table should be  
            //Create another mian cell that going to hold our last table here
            //First create the table and add it later to the main cell.
            //float[] colsWidth = { 1f, 2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f }; // Code 1
            //PdfPTable lasttablenested = new PdfPTable(colsWidth);
            //lasttablenested.SetWidthPercentage(colsWidth,PageSize.A4); 
            PdfPTable lasttablenested = new PdfPTable(10);//last inner table 



            //lasttablenested.AddCell(new Phrase("Date", titleFont));

            //PdfPCell TransCell2 = new PdfPCell();
            //Phrase Transphrase = new Phrase();
            //Transphrase.Font = titleFont;
            //TransCell2.Colspan = 3;
            //Transphrase.Add("Transaction Details");
            //TransCell2.VerticalAlignment = 1;
            //TransCell2.AddElement(Transphrase);

            //lasttablenested.AddCell(TransCell2);

            //PdfPCell TransCell2r = new PdfPCell();
            //Phrase Transphrase2r = new Phrase();
            //Transphrase2r.Font = titleFont;
            //TransCell2r.Colspan = 2;
            //Transphrase2r.Add("Refence");
            //TransCell2r.VerticalAlignment = 1;
            //TransCell2r.AddElement(Transphrase2r);

            //lasttablenested.AddCell(TransCell2r);

            ////lasttablenested.AddCell(new Phrase("Refence", titleFont));
            //lasttablenested.AddCell(new Phrase("Value Date", titleFont));
            //lasttablenested.AddCell(new Phrase("Withdrawals", titleFont));
            //lasttablenested.AddCell(new Phrase("Lodgements", titleFont));
            //lasttablenested.AddCell(new Phrase("Balance", titleFont));

            if (transdetail.Length > 0)
            {
                if (transdetail[0] != null)
                {
                    int transdetailCount = transdetail.Length;
                    int i = 0;
                    foreach (var transdetailwithbranch in transdetail)
                    {
                        i++;
                        //Date
                        Date = transdetailwithbranch.tDate;
                        PdfPCell DateColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            DateColCell.BorderColorBottom = basecolor;
                            DateColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            DateColCell.BorderWidthTop = 0;
                        }


                        Phrase Datephrase = new Phrase();
                        Datephrase.Font = titleFont;
                        Datephrase.Add(Date);
                        DateColCell.AddElement(Datephrase);
                        lasttablenested.AddCell(DateColCell);

                        //TrancsactionDetails
                        TransactionDetails = transdetailwithbranch.desc;
                        PdfPCell TrancsactionDetailsColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            TrancsactionDetailsColCell.BorderColorBottom = basecolor;
                            TrancsactionDetailsColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            TrancsactionDetailsColCell.BorderWidthTop = 0;
                        }
                        Phrase TrancsactionDetailsphrase = new Phrase();
                        TrancsactionDetailsphrase.Font = titleFont;
                        TrancsactionDetailsColCell.Colspan = 3;
                        TrancsactionDetailsphrase.Add(TransactionDetails);
                        TrancsactionDetailsColCell.VerticalAlignment = 1;
                        TrancsactionDetailsColCell.AddElement(TrancsactionDetailsphrase);
                        lasttablenested.AddCell(TrancsactionDetailsColCell);


                        //Reference
                        Reference = transdetailwithbranch.refNo;
                        PdfPCell ReferenceColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            ReferenceColCell.BorderColorBottom = basecolor;
                            ReferenceColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            ReferenceColCell.BorderWidthTop = 0;
                        }

                        Phrase Referencephrase = new Phrase();
                        ReferenceColCell.Colspan = 2;
                        Referencephrase.Font = titleFont;
                        Referencephrase.Add(Reference);
                        ReferenceColCell.AddElement(Referencephrase);
                        lasttablenested.AddCell(ReferenceColCell);

                        //ValueDate
                        ValueDate = transdetailwithbranch.valueDate;
                        PdfPCell ValueDateColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            ValueDateColCell.BorderColorBottom = basecolor;
                            ValueDateColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            ValueDateColCell.BorderWidthTop = 0;
                        }
                        Phrase ValueDatephrase = new Phrase();
                        ValueDatephrase.Font = titleFont;
                        ValueDatephrase.Add(ValueDate);
                        ValueDateColCell.AddElement(ValueDatephrase);
                        lasttablenested.AddCell(ValueDateColCell);

                        //WithDrawl
                        Withdrawl = transdetailwithbranch.withdraw;
                        PdfPCell WithDrawlColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            WithDrawlColCell.BorderColorBottom = basecolor;
                            WithDrawlColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            WithDrawlColCell.BorderWidthTop = 0;
                        }

                        Phrase WithDrawlphrase = new Phrase();
                        WithDrawlphrase.Font = titleFont;
                        WithDrawlphrase.Add(Withdrawl);
                        WithDrawlColCell.AddElement(WithDrawlphrase);
                        lasttablenested.AddCell(WithDrawlColCell);

                        //Lodgment
                        Lodgements = transdetailwithbranch.lodgement;
                        PdfPCell LodgementColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            LodgementColCell.BorderColorBottom = basecolor;
                            LodgementColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            LodgementColCell.BorderWidthTop = 0;
                        }
                        Phrase Lodgementphrase = new Phrase();
                        Lodgementphrase.Font = titleFont;
                        Lodgementphrase.Add(Lodgements);
                        LodgementColCell.AddElement(Lodgementphrase);
                        lasttablenested.AddCell(LodgementColCell);

                        //Balance
                        Balance = transdetailwithbranch.xybalance;
                        PdfPCell BalanceColCell = new PdfPCell();
                        if (i < transdetailCount)
                        {
                            BalanceColCell.BorderColorBottom = basecolor;
                            BalanceColCell.BorderWidthTop = 0;
                        }
                        else if (i == transdetailCount)
                        {
                            BalanceColCell.BorderWidthTop = 0;
                        }

                        Phrase Balancephrase = new Phrase();
                        Balancephrase.Font = titleFont;
                        Balancephrase.Add(Balance);
                        BalanceColCell.AddElement(Balancephrase);
                        lasttablenested.AddCell(BalanceColCell);
                    }
                }
            }


            //create the last cell of the main table and add this table to it
            PdfPCell LastCell = new PdfPCell(lasttablenested);

            LastCell.Padding = 0f;
            LastCell.Colspan = 4;
            LastCell.BorderWidthRight = 1;
            LastCell.BorderColorRight = BaseColor.WHITE;
            LastCell.BorderColorTop = basecolor;
            table.AddCell(LastCell);


            document.Add(table);
            document.Close();
            HttpContext.Current.Response.ContentType = "application/pdf";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename= PrintStatement.pdf");
            HttpContext.Current.Response.BinaryWrite(output.ToArray());
            Audit.LogTransaction(customerAccInfo.acctsumm[0].totalbalance == "" || customerAccInfo.acctsumm[0].totalbalance == null ? "0.00" : customerAccInfo.acctsumm[0].totalbalance, SPContext.Current.Web.CurrentUser.LoginName, customerAccInfo.acctsumm[0].accountname, customerAccInfo.acctsumm[0].accountNo, "HightQualityStatement");

        }

    }
}

public class WaterMark : PdfPageEventHelper
{
    iTextSharp.text.Font FONT = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 100, iTextSharp.text.Font.BOLD, BaseColor.RED);
    iTextSharp.text.Font smallFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 50, iTextSharp.text.Font.BOLD, BaseColor.RED);
  
    //public bool showPageCount { get; set; }

    //protected Font footer
    //{
    //    get
    //    {
    //        // create a basecolor to use for the footer font, if needed.
    //        BaseColor grey = new BaseColor(128, 128, 128);
    //        Font font = FontFactory.GetFont("Arial", 9, Font.NORMAL, grey);
    //        return font;
    //    }
    //}


    public void onEndPage(PdfWriter writer, Document document)
    {
        BaseColor color = new BaseColor(255, 171, 171);
        var titleFont = FontFactory.GetFont("Arial ROUNDED MT BOLD", 100, iTextSharp.text.Font.BOLD, color);
        var titleFont1 = FontFactory.GetFont("Arial ROUNDED MT BOLD", 40, iTextSharp.text.Font.BOLD, color);
        ColumnText.ShowTextAligned(writer.DirectContent, Element.ALIGN_CENTER, new Phrase("VOID ", titleFont), 350f, 700, 45);
        ColumnText.ShowTextAligned(writer.DirectContent, Element.ALIGN_CENTER, new Phrase("NOT FOR PRESENTATION", titleFont1), 350f, 600, 45);

        #region
        ////I use a PdfPtable with 2 columns to position my footer where I want it
        //PdfPTable footerTbl = new PdfPTable(2);

        ////set the width of the table to be the same as the document
        //footerTbl.TotalWidth = document.PageSize.Width;

        ////Center the table on the page
        //footerTbl.HorizontalAlignment = Element.ALIGN_CENTER;

        ////Create a paragraph that contains the footer text
        ////Paragraph para = new Paragraph("Some footer text", footer);
        //if (showPageCount)
        //{
        //    // Add in the current page number using the "footer" font
        //    Paragraph para = new Paragraph("Page " + document.PageNumber, footer);
        

        //// When setting the bottom margin, I just add 5 to it if we are showing page numbers
        //float botMarg = document.BottomMargin + 10;
        //if (showPageCount) botMarg += 5;


        ////create a cell instance to hold the text
        //PdfPCell cell = new PdfPCell(para);

        ////set cell border to 0
        //cell.Border = 0;

        ////add some padding to bring away from the edge
        //cell.PaddingLeft = 10;

        ////add cell to table
        //footerTbl.AddCell(cell);

        ////create new instance of Paragraph for 2nd cell text
        //para = new Paragraph("Some text for the second cell", footer);

        ////create new instance of cell to hold the text
        //cell = new PdfPCell(para);

        ////align the text to the right of the cell
        //cell.HorizontalAlignment = Element.ALIGN_RIGHT;
        ////set border to 0
        //cell.Border = 0;

        //// add some padding to take away from the edge of the page
        //cell.PaddingRight = 10;

        ////add the cell to the table
        //footerTbl.AddCell(cell);

        ////write the rows out to the PDF output stream.
        //footerTbl.WriteSelectedRows(0, -1, 0, (document.BottomMargin + 10), writer.DirectContent);

       // }

#endregion
    }

}
