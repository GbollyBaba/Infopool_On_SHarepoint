﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using Utilities.ActiveDirectory;
using NewInfoPool.Utilities;
using NewInfoPool.Layouts.NewInfoPool;
using System.Web;
using System.DirectoryServices;
namespace NewInfoPool.Utilities
{
    public class GetCurrentUserActiveDirectoryInfo
    {

        //public static int GetActiveDirectoryInfo(string LoginName)
        //{
        //    int result = 0;
        //    try
        //    {

        //        ADHelper helper = new ADHelper();
        //        helper.ADPath = "LDAP://abp-hq-s001.accessbankplc.com";
        //        helper.ADUser = "autoarchive";
        //        helper.ADPassword = "password10$";
        //        helper.ADServer = "LDAP://abp-hq-s001.accessbankplc.com";
        //        helper.ADAuthenticationtype = AuthenticationTypes.Secure;

        //        System.DirectoryServices.DirectoryEntry entry1 = helper.GetUser(ADAttributes.sAMAccountName, LoginName);
        //        //System.DirectoryServices.DirectoryEntry entry1 = helper.GetUser(ADAttributes.sAMAccountName, "fisayoa");
        //        if (entry1 != null)
        //        {
        //            // Log(entry1.Name);
        //            string CurrentStaffAccountnumber = helper.GetProperty(entry1, "extensionattribute3");
        //            if (!string.IsNullOrEmpty(CurrentStaffAccountnumber))
        //            {
        //                //Get the accountifo attribute here
        //                //Use this acc number to get the customer id and store in session
        //                AccountEnquiryGH en = new AccountEnquiryGH();
        //                AccountEnquiryGH1 enqAccMemo = new AccountEnquiryGH1();
        //                //CustomerAcctsInfo info = en.getAccountSummary("Accountnumber From AD");
        //                CustomerAcctsInfo info = en.getAccountSummary(CurrentStaffAccountnumber);
        //                //Obtain Customer ID Here
        //                string customerToken = info.customerID;
        //                //find the index of '~'
        //                string[] cusToken = customerToken.Split('~');//To get Customer ID
        //                HttpContext.Current.Session["MyStaffCustomerId"] = "";// cusToken[1].ToString();

        //                return result = 1;
        //            }
        //            else
        //            {
        //                return result = 0;
        //            }

        //        }

        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        if (ex.Message.Contains("The server is not operational."))
        //        {
        //            string message = ex.Message;

        //            return result = -1;
        //        }        

        //    }
        //    return result;
        //}

        public static int GetActiveDirectoryInfo(string LoginName, AccountEnquiryGhana en)
        {
            int result = 0;
            try
            {
                //Get the accountifo attribute here
                //Use this acc number to get the customer id and store in session
                en = new AccountEnquiryGhana();

                string accountNumber = en.getStaffAccounfromoutlookUsername(LoginName);
                //Response.Write("accountNumber ::::" + accountNumber + "\n");
                if (accountNumber.Length == 13)//


                {

                   // Response.Write("ENTERE EGEEHERERERE ::::"  + "\n");
                    string MyStaffCustomerId = en.getCustomerID(accountNumber);

                    //Response.Write("MyStaffCustomerId MyStaffCustomerId ::::" +MyStaffCustomerId + "\n");
                   //ssssssHttpContext.Current.Session["MyStaffCustomerId"] =  MyStaffCustomerId;
                   // en.Dispose();
                    return result = 1;

                    
                }
                else
                {
                    return result = 0;
                }
                //HttpContext.Current.Session["MyStaffCustomerId"] = "134886";
                //return result = 1;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("The server is not operational."))
                {
                    string message = ex.Message;

                    return result = -1;
                }

            }
            return result;
        }


        public enum LoginStatus
        {
            successful = 0,
            notExits,
            inACTIVE
        }

        public static void Log(string str)
        {
            System.IO.StreamWriter wrt = new System.IO.StreamWriter("c:\\ADLog.txt", true);
            wrt.WriteLine(str);
            wrt.Flush();
            wrt.Close();
        }
    }

}
