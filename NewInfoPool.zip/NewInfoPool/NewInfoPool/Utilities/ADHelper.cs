﻿using System;
using System.DirectoryServices;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Utilities.ActiveDirectory
{
    /// <summary>
    /// This is an Active Directory helper class.
    /// NOTE: to use this class you have to set the values of the (ADPath , ADUser , ADPassword , ADServer) static properties.
    /// 
    /// Example:
    /// ADHelper.ADHelper.ADPath = "LDAP://DevLab01";
    /// ADHelper.ADHelper.ADUser = "Administrator";
    /// ADHelper.ADHelper.ADPassword = "P@ssw0rd";
    /// ADHelper.ADHelper.ADServer = "SOFTWARE.COM";
    /// 
    /// OU : Organization Unit.
    /// DC : Domain Controller.
    /// CN : Container Name.
    /// </summary>
    public class ADHelper
    {
        #region Private Variables
        private string _ADPath = "";// Configuration.ADFullPath;
        private string _ADUser = "";// Configuration.ADAdminUser;
        private string _ADPassword = "";// Configuration.ADAdminPassword;
        private string _ADServer = "";// Configuration.ADServer
        private AuthenticationTypes _ADAuthenticationtype = AuthenticationTypes.Secure;

        #endregion

        #region Public Properties
        /// <summary>
        /// Gets / Sets the Active Directory Path.
        /// EXAMPLE : LDAP://DC1/OU=MyUsers,DC=Steve,DC=Schofield,DC=com
        /// </summary>
        public string ADPath
        {
            get { return this._ADPath; }
            set { this._ADPath = value; }
        }
        /// <summary>
        /// Gets / Sets the Active Directory Administrator User.
        /// </summary>
        public string ADUser
        {
            get { return this._ADUser; }
            set { this._ADUser = value; }
        }
        /// <summary>
        /// Gets / Sets the Active Directory Password.
        /// </summary>
        public string ADPassword
        {
            get { return this._ADPassword; }
            set { this._ADPassword = value; }
        }
        /// <summary>
        /// Gets / Sets the Active Directory Server.
        /// EXAMPLE : Schofield.com
        /// </summary>
        public string ADServer
        {
            get { return this._ADServer; }
            set { this._ADServer = value; }
        }
        /// <summary>
        /// Gets / Sets the authentication type to access the AD.
        /// </summary>
        public AuthenticationTypes ADAuthenticationtype
        {
            get { return _ADAuthenticationtype; }
            set { _ADAuthenticationtype = value; }
        }

        #endregion

        #region Constructor / Destructors
        /// <summary>
        /// Creates a Active Directory Helper object.
        /// </summary>
        public ADHelper()
        {

        }
        /// <summary>
        /// Creates a Active Directory Helper object.
        /// </summary>
        /// <param name="path">The LDAP path (ex LDAP://abp-hq-s001.accessbankplc.com)</param>
        /// <param name="username">The username used to access AD.</param>
        /// <param name="password">The password used to access AD.</param>
        /// <param name="server">The server, based on this property the LDAP path generated.</param>
        /// <param name="authenticationtype">The authentication type of the user on AD.</param>
        public ADHelper(string path, string username, string password, string server, AuthenticationTypes authenticationtype)
        {
            this.ADPath = path;
            this.ADUser = username;
            this.ADPassword = password;
            this.ADServer = server;
            this.ADAuthenticationtype = authenticationtype;
        }

        #endregion

        #region Enumerations
        /// <summary>
        /// 
        /// </summary>
        public enum ADAccountOptions
        {
            UF_TEMP_DUPLICATE_ACCOUNT = 0x0100,
            UF_NORMAL_ACCOUNT = 0x0200,
            UF_INTERDOMAIN_TRUST_ACCOUNT = 0x0800,
            UF_WORKSTATION_TRUST_ACCOUNT = 0x1000,
            UF_SERVER_TRUST_ACCOUNT = 0x2000,
            UF_DONT_EXPIRE_PASSWD = 0x10000,
            UF_SCRIPT = 0x0001,
            UF_ACCOUNTDISABLE = 0x0002,
            UF_HOMEDIR_REQUIRED = 0x0008,
            UF_LOCKOUT = 0x0010,
            UF_PASSWD_NOTREQD = 0x0020,
            UF_PASSWD_CANT_CHANGE = 0x0040,
            UF_ACCOUNT_LOCKOUT = 0X0010,
            UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED = 0X0080,
        }
        /// <summary>
        /// Represents the login results for a logging user.
        /// </summary>
        public enum LoginResult
        {
            LOGIN_OK = 0,
            LOGIN_USER_DOESNT_EXIST,
            LOGIN_USER_ACCOUNT_INACTIVE
        }

        #endregion

        #region Validation
        /// <summary>
        /// This function is validating the important data required to connect to Active Directory
        /// and returns true if data provided by the user, otherwise returns false.
        /// </summary>
        /// <returns>true if data is valid, otherwise returns false.</returns>
        private bool IsDataValid()
        {
            if (string.IsNullOrEmpty(this._ADPath))
            {
                throw new Exception("'ADPath' property can not be empty or null.");
            }
            else if (string.IsNullOrEmpty(this._ADUser))
            {
                throw new Exception("'ADUser' property can not be empty or null.");
            }
            else if (string.IsNullOrEmpty(this._ADPassword))
            {
                throw new Exception("'ADPassword' property can not be empty or null.");
            }
            else if (string.IsNullOrEmpty(this._ADServer))
            {
                throw new Exception("'ADServer' property can not be empty or null.");
            }

            return true;
        }

        #endregion

        #region " Check Account "
        /// <summary>
        /// This is used mainy for the logon process to ensure that the username and password match
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public DirectoryEntry UserExists(string UserName, string Password)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject();//UserName,Password);
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();
            //set the search filter
            deSearch.SearchRoot = de;
            deSearch.Filter = "((objectClass=user)(cn=" + UserName + ")(userPassword=" + Password + "))";
            deSearch.SearchScope = SearchScope.Subtree;
            //set the property to return
            //deSearch.PropertiesToLoad.Add("givenName");

            //find the first instance
            SearchResult results = deSearch.FindOne();

            //if the username and password do match, then this implies a valid login
            //if so then return the DirectoryEntry object
            de = new DirectoryEntry(results.Path, _ADUser, _ADPassword);
            return de;
        }
        /// <summary>
        /// Checks if a username exists in the AD or not.
        /// </summary>
        /// <param name="UserName">The DISPLAY NAME of the user to be checked.</param>
        /// <returns></returns>
        public bool UserExists(string UserName)
        {
            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();
            //set the search filter
            deSearch.SearchRoot = de;
            deSearch.Filter = "(&(objectClass=user)(cn=" + UserName + "))";

            //find the first instance
            SearchResultCollection results = deSearch.FindAll();
            //if the username and password do match, then this implies a valid login
            //if so then return the DirectoryEntry object
            if (results.Count == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// Checks if the user of the given attribute values exists or not.
        /// </summary>
        /// <param name="Attribute">The attribute to search with.</param>
        /// <param name="AttributeValue">The value of the given attribute.</param>
        /// <returns>true if user exists otherwise returns false.</returns>
        public bool UserExists(ADAttributes AttributeName, string AttributeValue)
        {
            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();
            //set the search filter
            deSearch.SearchRoot = de;
            deSearch.Filter = "(&(objectClass=user) (" + AttributeName.ToString() + "=" + AttributeValue + "))";

            //find the first instance
            SearchResultCollection results = deSearch.FindAll();
            //if the username and password do match, then this implies a valid login
            //if so then return the DirectoryEntry object
            if (results.Count == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// This method will not actually log a user in, but will perform tests to ensure
        /// that the user account exists (matched by both the username and password), and also
        /// checks if the account is active.
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public ADHelper.LoginResult Login(string UserName, string Password)
        {
            //first, check if the logon exists based on the username and password
            //DirectoryEntry de = GetUser(UserName,Password);

            if (IsUserValid(UserName, Password))
            {
                DirectoryEntry de = GetUser(UserName);
                if (de != null)
                {
                    //convert the accountControl value so that a logical operation can be performed
                    //to check of the Disabled option exists.
                    int userAccountControl = Convert.ToInt32(de.Properties["userAccountControl"][0]);
                    de.Close();
                    //if the disabled item does not exist then the account is active
                    if (!IsAccountActive(userAccountControl))
                    {
                        return LoginResult.LOGIN_USER_ACCOUNT_INACTIVE;
                    }
                    else
                    {
                        return LoginResult.LOGIN_OK;
                    }
                }
                else
                {
                    return LoginResult.LOGIN_USER_DOESNT_EXIST;
                }
            }
            else
            {
                return LoginResult.LOGIN_USER_DOESNT_EXIST;
            }
        }
        /// <summary>
        /// This will perfrom a logical operation on the userAccountControl values
        /// to see if the user account is enabled or disabled.  The flag for determining if the
        /// account is active is a bitwise value (decimal =2)
        /// </summary>
        /// <param name="userAccountControl"></param>
        /// <returns></returns>
        public bool IsAccountActive(int userAccountControl)
        {
            int userAccountControl_Disabled = Convert.ToInt32(ADAccountOptions.UF_ACCOUNTDISABLE);
            int flagExists = userAccountControl & userAccountControl_Disabled;
            //if a match is found, then the disabled flag exists within the control flags
            if (flagExists > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// This method will attempt to log in a user based on the username and password
        /// to ensure that they have been set up within the Active Directory.  This is the basic UserName, Password
        /// check.
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        public bool IsUserValid(string UserName, string Password)
        {
            try
            {
                //if the object can be created then return true
                DirectoryEntry deUser = GetUser(UserName, Password);
                if (deUser != null)
                {
                    deUser.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                string e = ex.Message;
            }
            return false;
        }

        /// <summary>
        /// This will query the user (by using the administrator role) and will set the new password
        /// This will not validate the existing password, as it will be assumed that if there logged in then
        /// the password can be changed.
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="OldPassword"></param>
        /// <param name="NewPassword"></param>
        public void SetUserPassword(string UserName, string NewPassword)
        {
            //get reference to user
            string LDAPDomain = "/CN=" + UserName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oUser = GetDirectoryObject(LDAPDomain);//,UserName,OldPassword);
            oUser.Invoke("SetPassword", new Object[] { NewPassword });
            oUser.Close();
        }
        /// <summary>
        /// This method will be used by the admin query screen, and is a method
        /// to return users based on a possible combination of lastname, email address or corporate
        /// </summary>
        /// <param name="Lastname"></param>
        /// <param name="EmailAddress"></param>
        /// <returns></returns>
        public DataSet GetUsersByNameEmailCorporate(string LastName, string EmailAddress)
        {
            StringBuilder SQLWhere = new StringBuilder();
            //if the LastName is present, then include in the where clause
            if (LastName != string.Empty)
            {
                SQLWhere.Append("(sn=" + LastName + ")");
            }

            //if the emailaddress is present, then include in the where clause
            if (EmailAddress != string.Empty)
            {
                SQLWhere.Append("(mail=" + EmailAddress + ")");
            }

            return GetUsersDataSet(SQLWhere.ToString());
        }

        #endregion

        #region Search Methods
        /// <summary>
        /// This will return a DirectoryEntry object if the user does exist
        /// </summary>
        /// <param name="UserName"></param>
        /// <returns></returns>
        public DirectoryEntry GetUser(string UserName)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(cn=" + UserName + "))";
            deSearch.SearchScope = SearchScope.Subtree;

            // add them to the search object  
            string[] requiredProperties = new string[] { "cn", "extensionattribute3", "mail" };

            foreach (String property in requiredProperties)
                deSearch.PropertiesToLoad.Add(property);

            //find the first instance
            SearchResult results = deSearch.FindOne();
            //if found then return, otherwise return Null
            if (results != null)
            {
                de = new DirectoryEntry(results.Path, _ADUser, _ADPassword);
                //if so then return the DirectoryEntry object
                return de;
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// Override method which will perfrom query based on combination of username and password
        /// This is used with the login process to validate the user credentials and return a user
        /// object for further validation.  This is slightly different from the other GetUser... methods as this
        /// will use the UserName and Password supplied as the authentication to check if the user exists, if so then
        /// the users object will be queried using these credentials.s
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public DirectoryEntry GetUser(ADAttributes AttributeName, string AttributeValue)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject(this.ADUser, this.ADPassword);
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(" + AttributeName.ToString() + "=" + AttributeValue + "))";
            deSearch.SearchScope = SearchScope.Subtree;
            //set the property to return
            //deSearch.PropertiesToLoad.Add("givenName");

            //find the first instance
            SearchResult results = deSearch.FindOne();

            //if a match is found, then create directiry object and return, otherwise return Null
            if (results != null)
            {
                //create the user object based on the admin priv.
                de = new DirectoryEntry(results.Path, this.ADUser, this.ADPassword);
                return de;
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// Override method which will perfrom query based on combination of username and password
        /// This is used with the login process to validate the user credentials and return a user
        /// object for further validation.  This is slightly different from the other GetUser... methods as this
        /// will use the UserName and Password supplied as the authentication to check if the user exists, if so then
        /// the users object will be queried using these credentials.s
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private DirectoryEntry GetUser(string UserName, string Password)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            //create an instance of the DirectoryEntry
            DirectoryEntry de = GetDirectoryObject(UserName, Password);
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(cn=" + UserName + "))";
            deSearch.SearchScope = SearchScope.Subtree;
            //set the property to return
            //deSearch.PropertiesToLoad.Add("givenName");

            //find the first instance
            SearchResult results = deSearch.FindOne();

            //if a match is found, then create directiry object and return, otherwise return Null
            if (results != null)
            {
                //create the user object based on the admin priv.
                de = new DirectoryEntry(results.Path, UserName, Password);
                return de;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// This will take a username and query the AD for the user.  When found it will transform
        /// the results from the poperty collection into a Dataset which can be used by the client
        /// </summary>
        /// <param name="UserName"></param>
        /// <returns></returns>
        public DataSet GetUserDataSet(string UserName)
        {
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(cn=" + UserName + "))";
            deSearch.SearchScope = SearchScope.Subtree;

            //find the first instance
            SearchResult results = deSearch.FindOne();
            //get Empty user dataset
            DataSet dsUser = CreateUserDataSet();
            //If no user record returned, then dont do anything, otherwise
            //populate
            if (results != null)
            {
                //populate the dataset with the values from the results
                dsUser.Tables["User"].Rows.Add(PopulateUserDataSet(results, dsUser.Tables["User"]));

            }
            de.Close();

            return dsUser;
        }
        /// <summary>
        /// Gets a dataset contains a datatable of all info about the user matches.
        /// </summary>
        /// <param name="Attribute">The attribute the want to specify the user with (example: cn , userprinciplename , ... ).</param>
        /// <param name="AttributeValue">The value of the attribute to specify the user with.</param>
        /// <returns>a dataset contains a datatable of all info about the user matches given criteria.</returns>
        public DataSet GetUserDataSet(ADAttributes Attribute , string AttributeValue)
        {
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(" + Attribute + "=" + AttributeValue + "))";
            deSearch.SearchScope = SearchScope.Subtree;

            //find the first instance
            SearchResult results = deSearch.FindOne();
            //get Empty user dataset
            DataSet dsUser = CreateUserDataSet();
            //If no user record returned, then dont do anything, otherwise
            //populate
            if (results != null)
            {
                //populate the dataset with the values from the results
                dsUser.Tables["User"].Rows.Add(PopulateUserDataSet(results, dsUser.Tables["User"]));

            }
            de.Close();

            return dsUser;
        }
        /// <summary>
        /// This method will return a dataset of user details based on criteria
        /// passed to the query.  The criteria is in the LDAP format ie
        /// (cn='xxx')(sn='eee') etc
        /// </summary>
        /// <param name="Criteria">the criteria to search with (EXAMPLE: (cn=Bishoy F. Meantias) )</param>
        /// <returns>a dataset contains a datatable of all info about the user matches given criteria.</returns>
        public DataSet GetUsersDataSet(string Criteria)
        {
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(&(objectClass=user)(objectCategory=person)" + Criteria + ")";
            deSearch.SearchScope = SearchScope.Subtree;

            //find the first instance
            SearchResultCollection results = deSearch.FindAll();
            //get Empty user dataset
            DataSet dsUser = CreateUserDataSet();
            //If no user record returned, then dont do anything, otherwise
            //populate
            if (results.Count > 0)
            {
                foreach (SearchResult result in results)
                {
                    //populate the dataset with the values from the results
                    dsUser.Tables["User"].Rows.Add(PopulateUserDataSet(result, dsUser.Tables["User"]));
                }
            }
            de.Close();
            return dsUser;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllUsers()
        {
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = de;
            //set the search filter
            deSearch.Filter = "(objectCategory=user)";
            deSearch.SearchScope = SearchScope.Subtree;

            //find the first instance
            SearchResult results = deSearch.FindOne();
            //get Empty user dataset
            DataSet dsUser = CreateUserDataSet();
            //If no user record returned, then dont do anything, otherwise
            //populate
            if (results != null)
            {
                //populate the dataset with the values from the results
                dsUser.Tables["User"].Rows.Add(PopulateUserDataSet(results, dsUser.Tables["User"]));
            }
            de.Close();

            return dsUser.Tables[0];
        }

        /// <summary>
        /// This method will query all of the defined AD groups
        /// and will turn the results into a dataset to be returned
        /// </summary>
        /// <returns></returns>
        public DataSet GetGroups()
        {
            DataSet dsGroup = new DataSet();
            DirectoryEntry de = GetDirectoryObject();
            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();
            //set the search filter
            deSearch.SearchRoot = de;
            //deSearch.PropertiesToLoad.Add("cn");
            deSearch.Filter = "(&(objectClass=group)(cn=*))";

            //find the first instance
            SearchResultCollection results = deSearch.FindAll();
            //Create a new table object within the dataset
            DataTable tbGroup = dsGroup.Tables.Add("Groups");
            tbGroup.Columns.Add("GroupName");
            //if there are results (there should be some!!), then convert the results
            //into a dataset to be returned.
            if (results.Count > 0)
            {
                //iterate through collection and populate the table with
                //the Group Name
                foreach (SearchResult Result in results)
                {
                    //set a new empty row
                    DataRow rwGroup = tbGroup.NewRow();

                    //populate the column
                    rwGroup["GroupName"] = Result.Properties["cn"][0];
                    //append the row to the table of the dataset
                    tbGroup.Rows.Add(rwGroup);
                }
            }
            return dsGroup;
        }
        /// <summary>
        /// This method will return all users for the specified group in a dataset
        /// </summary>
        /// <param name="GroupName"></param>
        /// <returns></returns>
        public DataSet GetUsersForGroup(string GroupName)
        {
            DataSet dsUser = new DataSet();
            DirectoryEntry de = GetDirectoryObject();

            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();
            //set the search filter
            deSearch.SearchRoot = de;
            //deSearch.PropertiesToLoad.Add("cn");
            deSearch.Filter = "(&(objectClass=group)(cn=" + GroupName + "))";

            //get the group result
            SearchResult results = deSearch.FindOne();
            //Create a new table object within the dataset
            DataTable tbUser = dsUser.Tables.Add("Users");
            tbUser.Columns.Add("UserName");
            tbUser.Columns.Add("DisplayName");
            tbUser.Columns.Add("EMailAddress");

            ////Create default row
            //DataRow rwDefaultUser = tbUser.NewRow();
            //rwDefaultUser["UserName"] = "0";
            //rwDefaultUser["DisplayName"] = "(Not Specified)";
            //rwDefaultUser["EMailAddress"] = "(Not Specified)";
            //tbUser.Rows.Add(rwDefaultUser);

            //if the group is valid, then continue, otherwise return a blank dataset
            if (results != null)
            {
                //create a link to the group object, so we can get the list of members
                //within the group
                DirectoryEntry deGroup = new DirectoryEntry(this.ADPath, _ADUser, _ADPassword);
                //assign a property collection
                System.DirectoryServices.PropertyCollection pcoll = deGroup.Properties;
                int n = pcoll["member"].Count;

                //if there are members fo the group, then get the details and assign to the table
                for (int l = 0; l < n; l++)
                {
                    //create a link to the user object so that the FirstName, LastName and Username can be gotten
                    //DirectoryEntry deUser = new DirectoryEntry("LDAP://DevLab01" + "/" + pcoll["member"][l].ToString(), _ADUser, _ADPassword, AuthenticationTypes.Secure);
                    DirectoryEntry deUser = new DirectoryEntry(_ADPath + "/" + pcoll["member"][l].ToString(), _ADUser, _ADPassword);

                    //set a new empty row
                    DataRow rwUser = tbUser.NewRow();

                    //populate the column
                    rwUser["UserName"] = GetProperty(deUser, "cn");
                    rwUser["DisplayName"] = GetProperty(deUser, "givenName") + " " + GetProperty(deUser, "sn");
                    rwUser["EMailAddress"] = GetProperty(deUser, "mail");
                    //append the row to the table of the dataset
                    tbUser.Rows.Add(rwUser);
                    //close the directory entry object
                    deUser.Close();

                }
                de.Close();
                deGroup.Close();
            }

            return dsUser;
        }

        #endregion

        #region Set User Details Methods
        /// <summary>
        /// Set the user password
        /// </summary>
        /// <param name="oDE">The user object to set its password.</param>
        /// <param name="Password">The new password.</param>
        public void SetUserPassword(DirectoryEntry oDE, string Password)
        {
            oDE.Invoke("SetPassword", new Object[] { Password });
            //string[] yourpw={Password};
            //oDE.Invoke("SetPassword", yourpw);
            //oDE.CommitChanges();

            //object[] password = new object[] {Password};
            //object ret = oDE.Invoke("SetPassword", password );
            //oDE.CommitChanges();
        }
        /// <summary>
        /// This will enable a user account based on the username
        /// </summary>
        /// <param name="UserName">The cn of the user to enable.</param>
        public void EnableUserAccount(string UserName)
        {
            //get the directory entry fot eh user and enable the password
            EnableUserAccount(GetUser(UserName));
        }
        /// <summary>
        /// Enables a user account.
        /// </summary>
        /// <param name="oDE">The user object to enable.</param>
        public void EnableUserAccount(DirectoryEntry oDE)
        {
            //we enable the account by resetting all the account options excluding the disable flag
            oDE.Properties["userAccountControl"][0] = ADHelper.ADAccountOptions.UF_NORMAL_ACCOUNT | ADHelper.ADAccountOptions.UF_DONT_EXPIRE_PASSWD;
            oDE.CommitChanges();
            //oDE.Invoke("accountDisabled",new Object[]{"false"});
            oDE.Close();
        }

        /// <summary>
        /// This will disable the user account based on the username passed to it
        /// </summary>
        /// <param name="Username">The cn of the user to disable.</param>
        public void DisableUserAccount(string UserName)
        {
            //get the directory entry fot eh user and enable the password
            DisableUserAccount(GetUser(UserName));
        }
        /// <summary>
        /// Enable the user account based on the DirectoryEntry object passed to it
        /// </summary>
        /// <param name="oDE">The user object to disable.</param>
        public void DisableUserAccount(DirectoryEntry oDE)
        {
            //we disable the account by resetting all the default properties
            oDE.Properties["userAccountControl"][0] = ADHelper.ADAccountOptions.UF_NORMAL_ACCOUNT | ADHelper.ADAccountOptions.UF_DONT_EXPIRE_PASSWD | ADHelper.ADAccountOptions.UF_ACCOUNTDISABLE;
            oDE.CommitChanges();
            //   oDE.Invoke("accountDisabled",new Object[]{"true"});
            oDE.Close();
        }

        /// <summary>
        /// Override method for adding a user to a group.  The group will be specified
        /// so that a group object can be located, then the user will be queried and added to the group
        /// </summary>
        /// <param name="UserName">cn (Display Name) of the user</param>
        /// <param name="GroupName">cn (Display Name) of the group</param>
        public void AddUserToGroup(string UserName, string GroupName)
        {
            string LDAPDomain = string.Empty;
            //get reference to group
            LDAPDomain = "/CN=" + GroupName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oGroup = GetDirectoryObject(LDAPDomain);
            //get reference to user
            LDAPDomain = "/CN=" + UserName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oUser = GetDirectoryObject(LDAPDomain);

            //Add the user to the group via the invoke method
            oGroup.Invoke("Add", new Object[] { oUser.Path.ToString() });
            oGroup.Close();
            oUser.Close();
        }
        /// <summary>
        /// Override method for adding a user to a group.  The group will be specified
        /// so that a group object can be located, then the user will be queried and added to the group
        /// </summary>
        /// <param name="AttributeToSpecifyUser">The attribute the want to specify the user with (example: cn , userprinciplename , ... ).</param>
        /// <param name="AttributeValue">The value of the attribute to specify the user with.</param>
        /// <param name="GroupName">The cn (Display Name) of the group.</param>
        public void AddUserToGroup(ADAttributes AttributeToSpecifyUser, string AttributeValue, string GroupName)
        {
            string LDAPDomain = string.Empty;
            //get reference to group
            LDAPDomain = "/CN=" + GroupName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oGroup = GetDirectoryObject(LDAPDomain);

            //get reference to user
            LDAPDomain = "/CN=" + GetUserDataSet(AttributeToSpecifyUser, AttributeValue).Tables[0].Rows[0]["LoginName"] + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oUser = GetDirectoryObject(LDAPDomain);

            //Add the user to the group via the invoke method
            oGroup.Invoke("Add", new Object[] { oUser.Path.ToString() });
            oGroup.Close();
            oUser.Close();
        }

        /// <summary>
        /// Removes a user from a group.
        /// </summary>
        /// <param name="UserName">The cn (Display Name) of the user.</param>
        /// <param name="GroupName">The name of the group.</param>
        public void RemoveUserFromGroup(string UserName, string GroupName)
        {
            string LDAPDomain = string.Empty;
            //get reference to group
            LDAPDomain = "/CN=" + GroupName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oGroup = GetDirectoryObject(LDAPDomain);

            //get reference to user
            LDAPDomain = "/CN=" + UserName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oUser = GetDirectoryObject(LDAPDomain);

            //Add the user to the group via the invoke method
            oGroup.Invoke("Remove", new Object[] { oUser.Path.ToString() });
            oGroup.Close();
            oUser.Close();
        }
        /// <summary>
        /// Removes a user from a group.
        /// </summary>
        /// <param name="AttributeToSpecifyUser">The attribute the want to specify the user with (example: cn , userprinciplename , ... ).</param>
        /// <param name="AttributeValue">The value of the attribute to specify the user with.</param>
        /// <param name="GroupName">The cn (Display Name) of the group.</param>
        public void RemoveUserFromGroup(ADAttributes AttributeToSpecifyUser, string AttributeValue, string GroupName)
        {
            string LDAPDomain = string.Empty;
            //get reference to group
            LDAPDomain = "/CN=" + GroupName + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oGroup = GetDirectoryObject(LDAPDomain);

            //get reference to user
            LDAPDomain = "/CN=" + GetUserDataSet(AttributeToSpecifyUser, AttributeValue).Tables[0].Rows[0]["LoginName"] + ",CN=Users," + GetLDAPDomain();
            DirectoryEntry oUser = GetDirectoryObject(LDAPDomain);

            //Add the user to the group via the invoke method
            oGroup.Invoke("Remove", new Object[] { oUser.Path.ToString() });
            oGroup.Close();
            oUser.Close();
        }

        #endregion

        #region Helper Methods
        /// <summary>
        /// This will retreive the specified poperty value from the DirectoryEntry object (if the property exists)
        /// </summary>
        /// <param name="oDE"></param>
        /// <param name="PropertyName"></param>
        /// <returns></returns>
        public string GetProperty(DirectoryEntry oDE, string PropertyName)
        {
            if (oDE.Properties.Contains(PropertyName))
            {
                return oDE.Properties[PropertyName][0].ToString();
            }
            else
            {
                return string.Empty;
            }
        }
        /// <summary>
        /// This is an override that will allow a property to be extracted directly from
        /// a searchresult object
        /// </summary>
        /// <param name="searchResult"></param>
        /// <param name="PropertyName"></param>
        /// <returns></returns>
        public string GetProperty(SearchResult searchResult, string PropertyName)
        {
            if (searchResult.Properties.Contains(PropertyName))
            {
                return searchResult.Properties[PropertyName][0].ToString();
            }
            else
            {
                return string.Empty;
            }
        }
        /// <summary>
        /// This will test the value of the propertyvalue and if empty will not set the property
        /// as AD is particular about being sent blank values
        /// </summary>
        /// <param name="oDE"></param>
        /// <param name="PropertyName"></param>
        /// <param name="PropertyValue"></param>
        public void SetProperty(DirectoryEntry oDE, string PropertyName, string PropertyValue)
        {
            //check if the value is valid, otherwise dont update
            if (PropertyValue != string.Empty)
            {
                //check if the property exists before adding it to the list
                if (oDE.Properties.Contains(PropertyName))
                {
                    oDE.Properties[PropertyName][0] = PropertyValue;
                }
                else
                {
                    oDE.Properties[PropertyName].Add(PropertyValue);
                }
                oDE.CommitChanges();
            }
        }
        /// <summary>
        /// This is an internal method for retreiving a new directoryentry object
        /// </summary>
        /// <returns></returns>
        private DirectoryEntry GetDirectoryObject()
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            DirectoryEntry oDE;
            oDE = new DirectoryEntry(this.ADPath, this.ADUser, this.ADPassword, this.ADAuthenticationtype);
            return oDE;
        }
        /// <summary>
        /// Override function that that will attempt a logon based on the users credentials
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        private DirectoryEntry GetDirectoryObject(string UserName, string Password)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            DirectoryEntry oDE;
            oDE = new DirectoryEntry(_ADPath, UserName, Password);
            return oDE;
        }
        /// <summary>
        /// This will create the directory entry based on the domain object to return
        /// The DomainReference will contain the qualified syntax for returning an entry
        /// at the location rather than returning the root.  
        /// i.e. /CN=Users,DC=creditsights, DC=cyberelves, DC=Com
        /// </summary>
        /// <param name="DomainReference"></param>
        /// <returns></returns>
        private DirectoryEntry GetDirectoryObject(string DomainReference)
        {
            // Validating before begin the operation
            if (!this.IsDataValid()) return null;

            DirectoryEntry oDE;
            oDE = new DirectoryEntry(_ADPath + DomainReference, _ADUser, _ADPassword);
            return oDE;
        }
        /// <summary>
        /// Addition override that will allow ovject to be created based on the users credentials.
        /// This is useful for instances such as setting password etc.
        /// </summary>
        /// <param name="DomainReference"></param>
        /// <param name="UserName"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        private DirectoryEntry GetDirectoryObject(string DomainReference, string UserName, string Password)
        {
            DirectoryEntry oDE;

            oDE = new DirectoryEntry(_ADPath + DomainReference, UserName, Password);
            return oDE;
        }

        #endregion

        #region Internal Methods
        /// <summary>
        /// This method will create a new directory object and pass it back so that
        /// it can be populated
        /// </summary>
        /// <param name="cn">The cn of the user.</param>
        /// <returns>The user entry created.</returns>
        public DirectoryEntry CreateNewUser(string cn)
        {
            //set the LDAP qualification so that the user will be created under the Users
            //container
            string LDAPDomain = "/CN=Users," + GetLDAPDomain();
            DirectoryEntry oDE = GetDirectoryObject(LDAPDomain);
            DirectoryEntry oDEC = oDE.Children.Add("CN=" + cn, "User");
            oDEC.CommitChanges();
            oDE.Close();
            return oDEC;
        }
        /// <summary>
        /// This will read in the ADServer value from the web.config and will return it
        /// as an LDAP path ie DC=creditsights, DC=cyberelves, DC=com.
        /// This is required when creating directoryentry other than the root.
        /// </summary>
        /// <returns></returns>
        private string GetLDAPDomain()
        {
            StringBuilder LDAPDomain = new StringBuilder();
            string[] LDAPDC = _ADServer.Split('.');

            for (int i = 0; i < LDAPDC.GetUpperBound(0) + 1; i++)
            {
                LDAPDomain.Append("DC=" + LDAPDC[i]);
                if (i < LDAPDC.GetUpperBound(0))
                {
                    LDAPDomain.Append(",");
                }
            }
            return LDAPDomain.ToString();
        }
        /// <summary>
        /// This method will create a Dataset stucture containing all relevant fields
        /// that match to a user.
        /// </summary>
        /// <returns></returns>
        private DataSet CreateUserDataSet()
        {
            DataSet ds = new DataSet();
            //Create a new table object within the dataset
            DataTable tb = ds.Tables.Add("User");
            //Create all the columns
            tb.Columns.Add("LoginName");
            tb.Columns.Add("FirstName");
            tb.Columns.Add("MiddleInitial");
            tb.Columns.Add("LastName");
            tb.Columns.Add("Address1");
            tb.Columns.Add("Address2");
            tb.Columns.Add("Title");
            tb.Columns.Add("Company");
            tb.Columns.Add("City");
            tb.Columns.Add("State");
            tb.Columns.Add("Country");
            tb.Columns.Add("Zip");
            tb.Columns.Add("Phone");
            tb.Columns.Add("Extension");
            tb.Columns.Add("Fax");
            tb.Columns.Add("EmailAddress");
            tb.Columns.Add("ChallengeQuestion");
            tb.Columns.Add("ChallengeResponse");
            tb.Columns.Add("MemberCompany");
            tb.Columns.Add("CompanyRelationShipExists");
            tb.Columns.Add("Status");
            tb.Columns.Add("AssignedSalesPerson");
            tb.Columns.Add("AcceptTAndC");
            tb.Columns.Add("Jobs");
            tb.Columns.Add("Email_Overnight");
            tb.Columns.Add("Email_DailyEmergingMarkets");
            tb.Columns.Add("Email_DailyCorporateAlerts");
            tb.Columns.Add("AssetMgtRange");
            tb.Columns.Add("ReferralCompany");
            tb.Columns.Add("CorporateAffiliation");
            tb.Columns.Add("DateCreated");
            tb.Columns.Add("DateLastModified");
            tb.Columns.Add("DateOfExpiry");
            tb.Columns.Add("AccountIsActive");

            return ds;
        }
        /// <summary>
        /// This method will return a DataRow object which will be added to the userdataset object
        /// This will also allow the iteration of multiple rows
        /// </summary>
        /// <param name="userSearchResult"></param>
        /// <returns></returns>
        private DataRow PopulateUserDataSet(SearchResult userSearchResult, DataTable userTable)
        {
            //set a new empty row
            DataRow rwUser = userTable.NewRow();
            rwUser["LoginName"] = GetProperty(userSearchResult, "cn");
            rwUser["FirstName"] = GetProperty(userSearchResult, "givenName");
            rwUser["MiddleInitial"] = GetProperty(userSearchResult, "initials");
            rwUser["LastName"] = GetProperty(userSearchResult, "sn");
            string tempAddress = GetProperty(userSearchResult, "homePostalAddress");
            //if the address does not exist, then default to blank fields
            if (tempAddress != string.Empty)
            {
                string[] addressArray = tempAddress.Split(';');
                rwUser["Address1"] = addressArray[0];
                rwUser["Address2"] = addressArray[1];
            }
            else
            {
                rwUser["Address1"] = string.Empty;
                rwUser["Address2"] = string.Empty;
            }
            rwUser["Title"] = GetProperty(userSearchResult, "title");
            rwUser["Company"] = GetProperty(userSearchResult, "company");
            rwUser["State"] = GetProperty(userSearchResult, "st");
            rwUser["City"] = GetProperty(userSearchResult, "l");
            rwUser["Country"] = GetProperty(userSearchResult, "co");
            rwUser["Zip"] = GetProperty(userSearchResult, "postalCode");
            rwUser["Phone"] = GetProperty(userSearchResult, "telephoneNumber");
            rwUser["Extension"] = GetProperty(userSearchResult, "otherTelephone");
            rwUser["Fax"] = GetProperty(userSearchResult, "facsimileTelephoneNumber");
            rwUser["EmailAddress"] = GetProperty(userSearchResult, "mail");
            rwUser["ChallengeQuestion"] = GetProperty(userSearchResult, "extensionAttribute1");
            rwUser["ChallengeResponse"] = GetProperty(userSearchResult, "extensionAttribute2");
            rwUser["MemberCompany"] = GetProperty(userSearchResult, "extensionAttribute3");
            rwUser["CompanyRelationShipExists"] = GetProperty(userSearchResult, "extensionAttribute4");
            rwUser["Status"] = GetProperty(userSearchResult, "extensionAttribute5");
            rwUser["AssignedSalesPerson"] = GetProperty(userSearchResult, "extensionAttribute6");
            rwUser["AcceptTAndC"] = GetProperty(userSearchResult, "extensionAttribute7");
            rwUser["Jobs"] = GetProperty(userSearchResult, "extensionAttribute8");

            //handle the split of the email options
            string tempTempEmail = GetProperty(userSearchResult, "extensionAttribute9");

            //if no email address are present, then default to blank
            if (tempTempEmail != string.Empty)
            {
                string[] emailArray = tempTempEmail.Split(';');
                rwUser["Email_Overnight"] = emailArray[0];
                rwUser["Email_DailyEmergingMarkets"] = emailArray[1];
                rwUser["Email_DailyCorporateAlerts"] = emailArray[2];
            }
            else
            {
                rwUser["Email_Overnight"] = "false";
                rwUser["Email_DailyEmergingMarkets"] = "false";
                rwUser["Email_DailyCorporateAlerts"] = "false";
            }
            rwUser["AssetMgtRange"] = GetProperty(userSearchResult, "extensionAttribute10");
            rwUser["ReferralCompany"] = GetProperty(userSearchResult, "extensionAttribute11");
            rwUser["CorporateAffiliation"] = GetProperty(userSearchResult, "extensionAttribute12");
            rwUser["DateCreated"] = GetProperty(userSearchResult, "whenCreated");
            rwUser["DateLastModified"] = GetProperty(userSearchResult, "whenChanged");
            rwUser["DateOfExpiry"] = GetProperty(userSearchResult, "extensionAttribute12");
            rwUser["AccountIsActive"] = IsAccountActive(Convert.ToInt32(GetProperty(userSearchResult, "userAccountControl")));
            return rwUser;

        }

        #endregion
    }

    /// <summary>
    /// Represents the attributes of active directory that can search with.
    /// </summary>
    public enum ADAttributes
    {
        cn,
        SN,
        name,
        sAMAccountName
    }
}
