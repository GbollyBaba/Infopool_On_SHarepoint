﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections;


namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class CustomerDetails : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["CusNum"] != null)
            {
                string CustmerID = Page.Request.QueryString["CusNum"].ToString();
                AccountEnquiryGhana AccEnq = new AccountEnquiryGhana();
                ClientDetails1 cusDetail = AccEnq.getCustomerDetails(CustmerID);
                
                lblCustomerFullName.Text = cusDetail.customer_name1;
                lblCustomerNO.Text = cusDetail.customer_no;
                lblAddress.Text = cusDetail.addressline;
                lblFax.Text = cusDetail.fax_number;
                lblClassification.Text = cusDetail.cust_classification;
                lblCategory.Text = cusDetail.customer_category;
                lblDefaultMedia.Text = cusDetail.default_media;

                string[] expDob = cusDetail.exposure_category.Split('~');
                lblExposureCategory.Text = expDob[0];
                lblDob.Text = expDob[1];
                //lblExposureCategory.Text = cusDetail.exposure_category;


                lblExpCountry.Text = cusDetail.country;
                lblFrozen.Text = cusDetail.frozen;
                
               
                //lblCustomerType.Text = cusDetail.flgCustType;

                //string[] StaffToken = cusDetail.branchName.Split('~');
                //lblDateOfBirth.Text = cusDetail.dateOfBirth;
                //lblEmail.Text = cusDetail.custEmail;
                //lblFax.Text = cusDetail.custFax;
                //lblHomeBranch.Text = StaffToken[0];
                //lblMailAddress.Text = cusDetail.maillingAddress;
                //lblMaritalStatus.Text = cusDetail.maritalStatus;
                //lblNationality.Text = cusDetail.custNationality;
                //lblPermanentAddress.Text = cusDetail.permanentAddress;
                //lblPhone.Text = cusDetail.custPhone;
                //lblProfitCenter.Text = cusDetail.;                
                //lblBuisnessGroup.Text =cusDetail.;



                //if (cusDetail.MISCODE5 != null && cusDetail.MISCODE5 != "")
                //{
                //    lblAccountOfficer.Text = cusDetail.MISCODE5;
                //    if (cusDetail.MISCODE4 != null && cusDetail.MISCODE4 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE4;
                //        if (cusDetail.MISCODE3 != null && cusDetail.MISCODE3 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE3;
                //        }
                //    }
                //    else if (cusDetail.MISCODE3 != null && cusDetail.MISCODE3 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE3;
                //        if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE2;
                //        }
                //    }
                //    else if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE2;
                //        if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE1;
                //        }
                //    }
                //    else if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE1;
                //    }
                //}
                //else if (cusDetail.MISCODE4 != null && cusDetail.MISCODE4 != "")
                //{
                //    lblAccountOfficer.Text = cusDetail.MISCODE4;
                //    if (cusDetail.MISCODE3 != null && cusDetail.MISCODE3 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE3;
                //        if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE2;
                //        }
                //    }
                //    else if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE2;
                //        if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE1;
                //        }
                //    }
                //    else if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE1;
                //    }

                //}
                //else if (cusDetail.MISCODE3 != null && cusDetail.MISCODE3 != "")
                //{
                //    lblAccountOfficer.Text = cusDetail.MISCODE3;
                //    if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE2;
                //        if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE1;
                //        }
                //    }
                //    else if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE2;
                //        if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //        {
                //            lblBuisnessGroup.Text = cusDetail.MISCODE1;
                //        }
                //    }
                //    else if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE1;
                //    }

                //}
                //else if (cusDetail.MISCODE2 != null && cusDetail.MISCODE2 != "")
                //{
                //    lblAccountOfficer.Text = cusDetail.MISCODE2;
                //    if (cusDetail.MISCODE1 != null && cusDetail.MISCODE1 != "")
                //    {
                //        lblProfitCenter.Text = cusDetail.MISCODE1;
                        
                //    }
                    

                //}
                //if (cusDetail.flgCustType == "I" || cusDetail.flgCustType == "F")//This is individual Account
                //{
                //    lblSex.Text = cusDetail.gender;
                //    lblMaritalStatus.Text = cusDetail.maritalStatus;
                //    lblDateOfBirth.Text = cusDetail.dateOfBirth;

                //    lblStaff.Text = StaffToken[1]; //branch
                //}
                //else //This is Corporate Account
                //{
                //    tblstatus.Visible = false;
                //    tblDirectInfo.Visible = true;
                //    tblSigInfo.Visible = true;
                //    tblRCNumber.Visible = true;

                //    lblRCNumber.Text = cusDetail.businessRegNo;
                //    lblBusCategory.Text = cusDetail.businessCategory;
                //    lblDateIncorporation.Text = cusDetail.dateIncoporated;
                //}

            }

        }
    }
}
