﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Utilities.MyTop;
using System.Linq;
using Microsoft.SharePoint.Linq;
using System.Web.UI.WebControls;
using AccountReportSpace;
using NewInfoPool.Utilities;
using System.Collections.Generic;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class MyTopSearch : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // btnMyTop20.Attributes.Add("onclick", "document.getElementById('" + txtAccountNumber.ClientID + "').removeAttribute('readonly')");

            if (!Page.IsPostBack)
            {
                txtAccountNumber.Attributes.Add("readonly", "readonly");
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenSrchPopup()");

                

                //GetMyTop20(loginname[1].ToString(), en);
            }
        }

        private void GetMyTop20(string loginname, AccountEnquiryGhana en)
        {

            string accountNumber = en.getStaffAccounfromoutlookUsername(loginname);


            AccountReport accReport = new AccountReport();
            accReport.insertMyAccount(loginname, accountNumber);

        }

        protected void btnGetInvestment_Click(object sender, EventArgs e)
        {
            AccountReport accreport = new AccountReport();

            if (!string.IsNullOrEmpty(txtAccountNumber.Text))
            {
                

            }
        }

        protected void btnMySearch_Click(object sender, EventArgs e)
        {
            //if (txtAccountNumber.Text == "")
            //{
            //    return;
            //}
            //AccountEnquiryGH en = new AccountEnquiryGH();
            //CustomerAcctsInfo info = en.getAccountSummary(txtAccountNumber.Text);
            //string loginName = SPContext.Current.Web.CurrentUser.LoginName;
            //string[] LoginToken = loginName.Split('\\');//To get Customer ID
            ////Obtain Customer ID Here
            //string customerToken = info.customerID;
            ////find the index of '~'
            //string[] cusToken = customerToken.Split('~');//To get Customer ID
            //CustomerAcctsInfo customerAccInfo = en.getAccountSummaryByCustomerID(cusToken[1].ToString());

            //try
            //{
            //    if (info.acctsumm == null)
            //    {

            //    }
            //    string url = SPContext.Current.Web.Url;

            //    SPSecurity.RunWithElevatedPrivileges(delegate
            //    {
            //        SPSite root = new SPSite(url);
            //        SPWeb web = root.OpenWeb();
            //        web.AllowUnsafeUpdates = true;
            //        SPList selectedList = web.Lists["MyTop20"];

            //        SPListItem item = selectedList.Items.Add();
            //        item["AccountNumber"] = info.acctsumm[0].accountNo;
            //        if (info.acctsumm[0].clearedBalance == "")
            //        {
            //            item["Cleared"] = "0";
            //        }
            //        else
            //            item["Cleared"] = info.acctsumm[0].clearedBalance;

            //        if (info.acctsumm[0].unclearedBalance == "")
            //        {
            //            item["UnCleared"] = "0";
            //        }
            //        else
            //            item["UnCleared"] = info.acctsumm[0].unclearedBalance;
            //        item["HoldAmount"] = info.acctsumm[0].amountHold;
            //        item["Balance"] = info.acctsumm[0].netbalance;
            //        item["Title"] = info.acctsumm[0].accountname;
            //        item["ModifiedBy"] = LoginToken[1].ToString();
            //        item.Update();
            //        web.AllowUnsafeUpdates = false;
            //        if (web != null)
            //            web.Dispose();
            //        if (root != null)
            //            root.Dispose();

            //    });
            //    //GetMyTop20();
            //    txtAccountNumber.Text = "";
            //}
            //catch (Exception)
            //{
            //    //LBL_Message.Visible = true;
            //    //LBL_Message.Text = ex.Message;
            //}

            SPUser Currentuser = SPContext.Current.Web.CurrentUser;
            string[] loginname = Currentuser.LoginName.Split('\\');
            AccountEnquiryGhana en = new AccountEnquiryGhana();
            AccountReport report = new AccountReport();
            if (!string.IsNullOrEmpty(txtAccountNumber.Text))
            {
                //
                string reportRes = report.insertMyAccount(loginname[1], txtAccountNumber.Text);
                if (reportRes == "00")//Success
                {
                    CustomerAcctsInfo cusInfo = en.getAccountSummary(txtAccountNumber.Text);
                    if (cusInfo != null)
                    {
                        //Our object is a single object,create collection object and and it into it
                        //this we allow us to bind to gridview
                        List<CustomerAcctsInfo> custDetail = new List<CustomerAcctsInfo>();
                        custDetail.Add(cusInfo);
                        grdMyTop.DataSource = cusInfo.acctsumm;
                        grdMyTop.DataBind();

                        if (cusInfo.acctsumm.Count() > 0)
                            tblTop.Style["display"] = "block";
                    }
                }
                else
                {
                    MessagePrompt.ShowMessage(this, "Invalid Account");
                }
            }
        }

        protected void grdMyTop_Rowcommand(object sender, GridViewCommandEventArgs e)
        {

            Int64 id = Int64.Parse(e.CommandArgument.ToString());
            int xx = Convert.ToInt32(id);
            SPUser Currentuser = SPContext.Current.Web.CurrentUser;
            string[] loginname = Currentuser.LoginName.Split('\\');
            AccountReport report = new AccountReport();
                   switch (e.CommandName.ToLower())
                   {
                       case "delete":
                           GridView linkrow = sender as GridView;
                           GridViewRow row = linkrow.Rows[xx];
                           //Int32 modifiedID = Convert.ToInt32(linkrow.DataKeys[row.RowIndex].Value);
                           string accountNo = row.Cells[3].Text;
                           report.deleteMyAccount(loginname[1], accountNo);
                           Response.Redirect(Request.RawUrl);
                           break;

                   }
              
        }
        protected void grdMyTop_Deletingcommand(Object sender, GridViewDeleteEventArgs e)
        {

        }
        protected void grdMyTop_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[1].Text.Length < 10)
                {
                    if (e.Row.Cells[1].Text.Length == 5)
                    {
                        e.Row.Cells[1].Text = "00000" + e.Row.Cells[1].Text;
                    }
                    else if (e.Row.Cells[1].Text.Length == 6)
                    {
                        e.Row.Cells[1].Text = "0000" + e.Row.Cells[1].Text;
                    }
                    else if (e.Row.Cells[1].Text.Length == 7)
                    {
                        e.Row.Cells[1].Text = "000" + e.Row.Cells[1].Text;
                    }
                    else if (e.Row.Cells[1].Text.Length == 8)
                    {
                        e.Row.Cells[1].Text = "00" + e.Row.Cells[1].Text;
                    }
                    else if (e.Row.Cells[1].Text.Length == 9)
                    {
                        e.Row.Cells[1].Text = "0" + e.Row.Cells[1].Text;
                    }

                }
                if (e.Row.Cells[1].Text.Contains("-"))
                {
                    double clearCol = double.Parse(e.Row.Cells[3].Text.Remove(0, 1));
                    e.Row.Cells[3].Text = "(" + clearCol + ")";
                }
                if (e.Row.Cells[6].Text.Contains("-"))
                {
                    double netBalance = double.Parse(e.Row.Cells[6].Text.Remove(0, 1));
                    e.Row.Cells[6].Text = "(" + netBalance + ")";
                }
            }
        }
    }
}
