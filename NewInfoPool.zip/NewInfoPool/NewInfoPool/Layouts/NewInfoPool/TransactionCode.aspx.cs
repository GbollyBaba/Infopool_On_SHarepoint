﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class TransactionCode : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadTransactionScope();
            }
        }

        public void LoadTransactionScope()
        {
            AccountReport report = new AccountReport();

            TranCodesInfo traInfo = report.getTranCodes("");
            TranCodes[] tcodes = traInfo.tranCodes;
            grdTransactionScope.DataSource = tcodes;
            grdTransactionScope.DataBind();


        }
    }
}
