﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Collections;
using NewInfoPool.Utilities;
using System.Linq;
using Microsoft.SharePoint.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Drawing;
using System.IO;
using Utilities.ActiveDirectory;
using System.Text;
using System.Xml.Linq;
using InvestEnqSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class TransactionHistory : LayoutsPageBase
    {
        public string StartDateServertValue = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).Date.ToString("dd/MM/yyyy");
        public string EndDateServertValue = DateTime.Today.ToString("dd/MM/yyyy");
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
               
                SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                string[] loginname = Currentuser.LoginName.Split('\\');
                //1-6-11 
                //AccountEnquiryGhana en = new AccountEnquiryGhana();
                //int result =  GetCurrentUserActiveDirectoryInfo.GetActiveDirectoryInfo(loginname[1].ToString(), en);
                //result = 1;//please remove this before you redeploye

                ////////////////////////////////////////////////////////////////////////////////////////////

                AccountEnquiryGhana en = new AccountEnquiryGhana();
              //  Response.Write("loginname[1].ToString() ::::" + loginname[1].ToString() + "\n");
                // int result = GetCurrentUserActiveDirectoryInfo.GetActiveDirectoryInfo(loginname[1].ToString(), en);
                String loginName = loginname[1].ToString().Trim();
             //   Response.Write("lloginNameloginNameloginName::::" + loginName + "\n");
               

                int result = 0;
                try
                {


                    string accountNumber = en.getStaffAccounfromoutlookUsername(loginName);
                  if (accountNumber.Length == 13)//
                    {

                        // Response.Write("ENTERE EGEEHERERERE ::::"  + "\n");
                        string MyStaffCustomerId = en.getCustomerID(accountNumber);


                        result = 1;
                    }
                    else
                    {
                        result = 0;
                    }
                    //HttpContext.Current.Session["MyStaffCustomerId"] = "134886";
                    //return result = 1;
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("The server is not operational."))
                    {
                        string message = ex.Message;

                        result = -1;
                    }

                }

                //////////////////////////////////////////////////////////////////////////////////////////////



                if (result == 1)//
                {

                    //User can proceed on 
                }
                else if (result == 0)
                {
                    //Register Staff Account Info to Active Directory
                    Response.Redirect("AccNumber.aspx");
                }
                else if (result == -1)
                {
                    HttpContext.Current.Response.Redirect("HomePage.aspx");
                }

                //
                //int spandate = DateTime.Today.Day - 1;
                //dtcStartDate.SelectedDate = DateTime.Today.AddDays(-spandate);
                lblMessage.Visible = false;
                lblMessage.Text = "";
                //dtcStartDate.SelectedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                //dtcEndDate.SelectedDate = DateTime.Today;
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenSrchPopup()");
            }
        }

        static bool EnumerateValue(String Operand)
        {
            IEnumerator OperandEnum = Operand.GetEnumerator();
            int CharCount = 0;
            bool ans = false;
            while (OperandEnum.MoveNext())
            {
                CharCount++;
                char t = (char)OperandEnum.Current;
                if (char.IsNumber(t))//Check for AccountNumber
                {
                    ans = true;
                }
                else if (char.IsLetter(t))//Check for AccountName
                {
                    ans = false;
                }

                return ans;
            }
            return ans;

        }

        protected void btnSearchTransHistory_Click(object sender, EventArgs e)
        {
            #region
            //Check to see that the user enter value to the box
            if (string.IsNullOrEmpty(txtAccountNumber.Text))
            {
                //Prompt the user to type something
            }
            else
            {
                string AccountNumber = txtAccountNumber.Text.Trim();


                string StatrtDate = Page.Request.Form["startinput"].ToString();
                string EndDate = Page.Request.Form["endinput"].ToString();
                StartDateServertValue = StatrtDate;
                EndDateServertValue = EndDate;
                if (StatrtDate == "" || EndDate == "")
                {
                    return;
                }
                if (StatrtDate == null || EndDate == null)
                {
                    return;
                }

                int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
                int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
                int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
                DateTime dstart = new DateTime(Year, Month, Day);
                string startdate = dstart.ToString("dd-MMM-yyyy");

                int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
                int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
                int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
                DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
                string enddate = dend.ToString("dd-MMM-yyyy");

                //tbltransHist.Style["display"] = "block";
               
                tbltransHist1.Visible = true;
                tbltransHist1.Style["display"] = "block";


                GetAccountSummary(AccountNumber, startdate, enddate);
            }
            #endregion
        }

        private void GetAccountSummary(string AccountNumber, string StartDate, string EndDate)
        {
            //To get COT, Pass AccountNumber to the cotdetails
            //if it returns 0 dont show COT
            try
            {



                AccountEnquiryGhana tempAccEnq = new AccountEnquiryGhana();
                AccountEnquiryGhana2 enqAccMemo = new AccountEnquiryGhana2();
                tempAccEnq.Timeout = 360000;

          

               CustomerAcctsWithTransactionInfo cusAccTrans = tempAccEnq.getAccountSummaryANDTransactions(AccountNumber, StartDate, EndDate);
          
                CustomerAcctsInfo info = tempAccEnq.getAccountSummary(AccountNumber);
                string customerToken = info.customerID;
                //find the index of '~'
                string[] cusToken = customerToken.Split('~');//To get Customer ID
                bool CanView = false;
                if (cusAccTrans != null)
                {
                    #region
                    if (cusAccTrans.acctsumm == null || cusAccTrans.acctsumm[0] == null)
                    {
                        //tbltransHist.Style["display"] = "none";
                        divPrint.Style["display"] = "none";
                        relatedAcc.Style["display"] = "none";
                        tblAccSummary.Visible = false;
                        lblRelcustomerid.Visible = false;
                        lblMessage.Visible = true;
                        if (cusAccTrans.acctsumm == null || cusAccTrans.acctsumm[0] == null)
                        {
                            lblMessage.Text = "Account Number does not exist";
                            lblMessage.ForeColor = Color.Red;
                        }

                        return;
                    }
                    //Compare the customerId in the session with Customer id u ve here
                    SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                    string[] loginname = Currentuser.LoginName.Split('\\');
                    string loginName = loginname[1];
                    string accountNumber = tempAccEnq.getStaffAccounfromoutlookUsername(loginName);
                    string MyStaffCustomerId = tempAccEnq.getCustomerID(accountNumber);

                   if (MyStaffCustomerId != null)
                    {
                     
                        string customerid = MyStaffCustomerId.ToString();
                        int retval = string.Compare(customerid, cusToken[1].ToString());
                         if (retval == 0)
                        {
                            //It shows that the current logging staff owns the account 
                            GetAccountTransactionHistoryView(cusAccTrans, AccountNumber, cusToken, true, tempAccEnq, StartDate, EndDate, enqAccMemo);
                        }
                        else //Validate the User permission here
                        {
                            //Check to see if the user can view this account
                            if (cusAccTrans.acctsumm[0].flgempacct == "Y" && cusAccTrans.acctsumm[0].flgstaff == "N")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (cusAccTrans.acctsumm[0].flgempacct == "Y" && cusAccTrans.acctsumm[0].flgstaff == "Y")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (cusAccTrans.acctsumm[0].flgempacct == "N" && cusAccTrans.acctsumm[0].flgstaff == "Y")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (cusAccTrans.acctsumm[0].flgempacct == "N" && cusAccTrans.acctsumm[0].flgstaff == "N")
                            {

                                //04-Sep-2015
                                //check to see if it is a restricted account
                                CanView = GetrestrictedLevel(AccountNumber);

                              
                                    tbltransHist1.Visible=true;
                                    tbltransHist1.Style["display"] = "block";
                              

                               // Response.Write("SHOW HISTORY FLAG++++++=" + CanView.ToString()+"\n");

                            }
                            GetAccountTransactionHistoryView(cusAccTrans, AccountNumber, cusToken, CanView, tempAccEnq, StartDate, EndDate, enqAccMemo);
                        }
                    }

                    #endregion
                }
                else
                {
                    //tbltransHist.Style["display"] = "none";
                    divPrint.Style["display"] = "none";
                    relatedAcc.Style["display"] = "none";
                    tblAccSummary.Visible = false;
                    lblRelcustomerid.Visible = false;
                    lblMessage.Visible = true;
                    lblMessage.Text = "Account Number does not exist";
                    lblMessage.ForeColor = Color.Red;
                }
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                //tbltransHist.Style["display"] = "none";
                divPrint.Style["display"] = "none";
                relatedAcc.Style["display"] = "none";
                if (message == "Unable to connect to the remote server")
                {
                   // tbltransHist.Style["display"] = "none";
                    divPrint.Style["display"] = "none";
                    relatedAcc.Style["display"] = "none";
                    tblAccSummary.Visible = false;
                    lblRelcustomerid.Visible = false;
                    lblMessage.Visible = true;
                    lblMessage.Text = "Unable to connect to the remote server";
                    lblMessage.ForeColor = Color.Red;
                    string script = "<script language='javascript'>alert('" + "Unable to connect to the remote server" + "')</script>";
                    Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
                }
                else if (message == "The request failed with HTTP status 404: Not Found")
                {
                    //tbltransHist.Style["display"] = "none";
                    divPrint.Style["display"] = "none";
                    relatedAcc.Style["display"] = "none";
                    tblAccSummary.Visible = false;
                    lblRelcustomerid.Visible = false;
                    lblMessage.Visible = true;
                    lblMessage.Text = "Network Issue";
                    lblMessage.ForeColor = Color.Red;
                    string script = "<script language='javascript'>alert('" + "Network Problem:Contact your Network Administrator." + "')</script>";
                    Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
                }
            }
        }
        public bool GetrestrictedLevel(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);

            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);



                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                string my_groupname = web.Groups[result1].Name;
                if (result1 == "0000000000")
                {
                    Result = true;
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                }
                else
                {
                    // MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact " + my_groupname + " . ");
                }

            }
            else
            {
                //result\
                string distMemo = result;
                if (distMemo.Trim() == "RMEM0")
                {
                    MessagePrompt.ShowMessage(this, " Attention: Incomplete account opening documentation.!!!!");
                    Result = true;
                    


                }
                else
                {
                    string[] distMemoList = distMemo.Split(',');
                    SPWeb web = SPContext.Current.Web;
                    if (distMemoList.Length > 0)
                    {
                        foreach (string distMemoElement in distMemoList)
                        {
                            if (web.Groups[distMemoElement].ContainsCurrentUser)
                            {
                                Result = true;
                                //break;
                            }
                            //test for new memo 
                            if (distMemoElement.Trim() == "RMEM0"  )
                            {
                                Result = true;
                                MessagePrompt.ShowMessage(this, " Attention: Incomplete account opening documentation.!!!!");
                            }

                        }
                        if (Result == false)
                        {
                            MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                        }
                    }



                }

            }
            return Result;
        }

        public bool GetrestrictedLevel_BEFORE(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);
            
        //Response.Write("result from GET RESTRICTED ACCT =" + result.ToString()+"\n");

            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);



                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                string my_groupname = web.Groups[result1].Name;
                if (result1 == "0000000000")
                {
                    Result = true;
                    
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                    //break;
                }
                else
                {
                    // MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact " + my_groupname + " . ");
                }

            }
            else
            {
                //result\
                string distMemo = result;
                string[] distMemoList = distMemo.Split(',');
                SPWeb web = SPContext.Current.Web;
                if (distMemoList.Length > 0)
                {
                    foreach (string distMemoElement in distMemoList)
                    {
                        if (web.Groups[distMemoElement].ContainsCurrentUser)
                        {
                            Result = true;
                            //break;
                        }
                        //test for new memo 
                        if (distMemoElement.Trim() == "RMEM0")
                        {
                            MessagePrompt.ShowMessage(this, " Attention: Incomplete account opening documentation.!!!!");
                            Result = true;
                            break;
                        }

                    }
                    if (Result == false)
                    {
                        MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                    }
                }





            }
            return Result;
        }

        public bool GetrestrictedLevelOLD_01(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);
            
            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);



                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                string my_groupname = web.Groups[result1].Name;
                if (result1 == "0000000000")
                {
                    Result = true;
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                }
                else
                {
                    // MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact " + my_groupname + " . ");
                }

            }

            else
            {
                SPWeb web = SPContext.Current.Web;
                string[] grp = result.Split(',');
                for (int i = 0; i < grp.Length; i++)
                {

                      //test for new memo 
                    if (grp[i].Trim() == "RMEM0")
                        {
                            MessagePrompt.ShowMessage(this, "Attention: Incomplete account opening documentation.!!!");
                            Result = true;
                            break;
                        }
                    if (web.Groups[grp[i]].ContainsCurrentUser)
                    {
                        Result = true;
                      
                      
                    }
                }
                if (Result == false)
                {
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                }
            }

            return Result;
        }

        public bool GetrestrictedLevelOLD(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);

            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);
                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                if (result1 == "0000000000")
                {
                    Result = true;
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                }
                else
                {
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                }

            }
            else
            {
                SPWeb web = SPContext.Current.Web;
                string[] grp = result.Split(',');
                for (int i = 0; i < grp.Length; i++)
                {
                    if (web.Groups[grp[i]].ContainsCurrentUser)
                    {
                        Result = true;
                        break;
                    }
                }
                if (Result == false)
                {
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                }
            }
            return Result;
        }
        protected void grdCustomerAccSummary_Rowcommand(object sender, GridViewCommandEventArgs e)
        {

            bool AccCus = true;
            if (e.CommandName == "checkAccount")
            {
                //this get the text of ur link button
                LinkButton lnkAccountNo = (LinkButton)e.CommandSource;
                if (!string.IsNullOrEmpty(lnkAccountNo.Text))
                {

                    AccCus = EnumerateValue(lnkAccountNo.Text);
                    if (AccCus == true)//AccountDetails by clicking on Customer Number
                    {
                        txtAccountNumber.Text = lnkAccountNo.Text;
                        //Clear controls.
                        tblAccSummary.Visible = false;
                        tblAccSummary.Style["display"] = "none";
                        tbltransHist1.Style["display"] = "none";
                        divPrint.Style["display"] = "none";
                        relatedAcc.Style["display"] = "none";
                        grdTransDetails.Visible = false;
                    }
                    else if (AccCus == false)//CustomerDetails by clicking on Customer Name
                    {


                    }
                }
            }


        }

        protected void lblExportToExcel_onClick(object sender, EventArgs e)
        {

            try
            {

                AccountEnquiryGhana AccEnq = new AccountEnquiryGhana();
                AccEnq.Timeout = 90000000;
                string AccountNumber = txtAccountNumber.Text.Trim();

                string StatrtDate = Page.Request.Form["startinput"].ToString();
                string EndDate = Page.Request.Form["endinput"].ToString();
                StartDateServertValue = StatrtDate;
                EndDateServertValue = EndDate;
                if (StatrtDate == "" || EndDate == "")
                {
                    return;
                }
                if (StatrtDate == null || EndDate == null)
                {
                    return;
                }

                int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
                int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
                int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
                DateTime dstart = new DateTime(Year, Month, Day);
                string startdate = dstart.ToString("dd-MMM-yyyy");

                int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
                int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
                int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
                DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
                string enddate = dend.ToString("dd-MMM-yyyy");





                CustomerAcctsWithTransactionInfo cusTransBranch = AccEnq.getAccountSummaryANDTransactions(AccountNumber, startdate, enddate);
                string customerToken = cusTransBranch.customerID;
                string[] cusToken = customerToken.Split('~');//To get Customer ID

                TranDetails[] transdetail = cusTransBranch.acctsumm[0].tranDetails;

                DataSet ds = new DataSet();
                DataTable dt = ds.Tables.Add("Access Bank Plc RC 125384");
                DataColumn dc = dt.Columns.Add("Txn Date", typeof(string));
                dt.Columns.Add("Ref No.", typeof(string));
                dt.Columns.Add("Description", typeof(string));
                dt.Columns.Add("Value Date", typeof(string));
                dt.Columns.Add("Withdrawals", typeof(string));
                dt.Columns.Add("Lodgments", typeof(string));
                dt.Columns.Add("Balance", typeof(string));
                dt.Columns.Add("BranchName", typeof(string));
                DataRow row1;
                row1 = dt.NewRow();
                row1["Txn Date"] = "Opening Balance...";
                row1["Balance"] = cusTransBranch.acctsumm[0].openingBalance;
                dt.Rows.Add(row1);
                foreach (var transdetailwithbranch in transdetail)
                {
                    DataRow row;

                    row = dt.NewRow();
                    row["Txn Date"] = transdetailwithbranch.tDate;
                    row["Ref No."] = transdetailwithbranch.refNo;
                    row["Description"] = transdetailwithbranch.desc;
                    row["Value Date"] = transdetailwithbranch.valueDate;
                    row["Withdrawals"] = transdetailwithbranch.withdraw;
                    row["Lodgments"] = transdetailwithbranch.lodgement;
                    row["Balance"] = transdetailwithbranch.xybalance;

                    dt.Rows.Add(row);


                }
                DataRow row2;
                row2 = dt.NewRow();
                row2["Txn Date"] = "Closing Balance ...";
                row2["Balance"] = cusTransBranch.acctsumm[0].openingBalance;
                dt.Rows.Add(row2);

                DataRow AccNumrow;
                AccNumrow = dt.NewRow();
                AccNumrow["Txn Date"] = "Account No";
                AccNumrow["Ref No."] = txtAccountNumber.Text;
                dt.Rows.Add(AccNumrow);

                DataRow AccNamerow;
                AccNamerow = dt.NewRow();
                AccNamerow["Txn Date"] = "Account Name";
                AccNamerow["Ref No."] = cusTransBranch.acctsumm[0].accountname;
                dt.Rows.Add(AccNamerow);

                DataRow ClearBalancerow;
                ClearBalancerow = dt.NewRow();
                ClearBalancerow["Txn Date"] = "Cleared Balance";
                ClearBalancerow["Ref No."] = cusTransBranch.acctsumm[0].clearedBalance;
                dt.Rows.Add(ClearBalancerow);

                DataRow UnClearBalancerow;
                UnClearBalancerow = dt.NewRow();
                UnClearBalancerow["Txn Date"] = "Uncleared Balance";
                UnClearBalancerow["Ref No."] = cusTransBranch.acctsumm[0].unclearedBalance;
                dt.Rows.Add(UnClearBalancerow);

                string filename = "MS" + "_" + cusToken[1] + ".xls";
                ExportDataSetToExcel(ds, filename);
            }
            catch (Exception ex)
            {
                string message = ex.Message;
            }

        }

        protected void LblLinkPrint_onClick(object sender, EventArgs e)
        {

            PrintStatement highquality = new PrintStatement();
            string AccountNumber = txtAccountNumber.Text.Trim();
            string StatrtDate = Page.Request.Form["startinput"].ToString();
            string EndDate = Page.Request.Form["endinput"].ToString();
            StartDateServertValue = StatrtDate;
            EndDateServertValue = EndDate;
            if (StatrtDate == "" || EndDate == "")
            {
                return;
            }
            if (StatrtDate == null || EndDate == null)
            {
                return;
            }

            int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
            int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
            int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
            DateTime dstart = new DateTime(Year, Month, Day);
            string startdate = dstart.ToString("dd-MMM-yyyy");

            int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
            int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
            int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
            DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
            string enddate = dend.ToString("dd-MMM-yyyy");

            highquality.GetHighQualityStatement(AccountNumber, startdate, enddate);
        }

        protected void LblHighQualityPDF_onClick(object sender, EventArgs e)
        {
            PrintHighQualityStatement();
        }

        protected void PrintHighQualityStatement()
        {
            //Can the user print           

            if (CheckUserPermission.Ispermitted("HighQualityStatement"))
            {
                HighQualityStatement highquality = new HighQualityStatement();
                string AccountNumber = txtAccountNumber.Text.Trim();

                string StatrtDate = Page.Request.Form["startinput"].ToString();
                string EndDate = Page.Request.Form["endinput"].ToString();
                StartDateServertValue = StatrtDate;
                EndDateServertValue = EndDate;
                if (StatrtDate == "" || EndDate == "")
                {
                    return;
                }
                if (StatrtDate == null || EndDate == null)
                {
                    return;
                }

                int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
                int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
                int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
                DateTime dstart = new DateTime(Year, Month, Day);
                string startdate = dstart.ToString("dd-MMM-yyyy");

                int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
                int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
                int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
                DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
                string enddate = dend.ToString("dd-MMM-yyyy");
                highquality.GetHighQualityStatement(AccountNumber, startdate, enddate);

            }
            else
            {
                //show message here               
                //tbltransHist.Style["display"] = "none";
                tblAccSummary.Visible = false;
                lblRelcustomerid.Visible = false;
                string script = "<script language='javascript'>alert('" + "You are not allowed to print this statement." + "This is however open to Branch Services staff(Ops Heads,CCOs & Tellers)and requires user logs in." + "')</script>";
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);

            }
        }

        #region Export Dataset
        public static void ExportDataSetToExcel(DataSet oInputData, string filename)
        {
            HttpResponse oResponse = HttpContext.Current.Response;

            // Initializing oResponse Object
            oResponse.Clear();
            oResponse.Charset = "";

            // Set the Response Mime type to Excel
            oResponse.ContentType = "application/ms-excel";
            oResponse.AddHeader("Content-Disposition", "attachment;filename=\"" + filename + "\"");

            using (StringWriter oStringWriter = new StringWriter())
            {
                using (HtmlTextWriter oOutputData = new HtmlTextWriter(oStringWriter))
                {
                    DataGrid dgToExport = new DataGrid();
                    dgToExport.DataSource = oInputData.Tables[0];
                    dgToExport.DataBind();
                    dgToExport.RenderControl(oOutputData);
                    oResponse.Write(oStringWriter.ToString());
                    oResponse.End();
                }
            }
        }

        private bool AccountVerificationType(string Accountnumber, string UserName, string Currenturl)
        {
            bool validuser = false;

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                //using (StaffSalaryAccountEntity AccSalaryContext = new StaffSalaryAccountEntity("http://congo"))
                using (StaffSalaryAccountEntity AccSalaryContext = new StaffSalaryAccountEntity(Currenturl))
                {
                    string[] usernameToken = UserName.Split('\\');
                    var menuitem = (from accSalary in AccSalaryContext.StaffSalaryAccount
                                    where accSalary.Title == usernameToken[1] && accSalary.SalaryAccountNumber == Accountnumber
                                    select new { Valid = "true" }).FirstOrDefault();
                    if (menuitem != null && menuitem.Valid == "true")
                    {
                        Session["UserAccount"] = Accountnumber;
                        validuser = true;
                    }
                    else if (menuitem == null)
                        validuser = false;

                }

            });
            return validuser;
        }
        #endregion

        protected void grdTransDetails_Rowcommand(object sender, GridViewCommandEventArgs e)
        {
            #region
            //GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            //int rowindex = row.RowIndex;
            //object myDataKey = grdTransDetails.DataKeys[rowindex]["xrownumber"];
            ////Pass your parameter here and call trans details method
            //string rowkey = myDataKey.ToString();
            //AccountEnquiryGH accenq = new AccountEnquiryGH();
            //string transDate = row.Cells[0].Text;

            //LinkButton lblTextValue = (LinkButton)row.FindControl("lnkDescription");
            //lblTextValue.Attributes.Add("onclick", "window.open('TransactionDetails.aspx?AccNum=" + txtAccountNumber.Text + "&" + "transDate=" + transDate + "&" + "rowKey=" + rowkey + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

            //SingleTransactionDetails transDetails = accenq.getSingleTransactionDetails(txtAccountNumber.Text, transDate, rowkey);
            #endregion
        }
        protected void grdTransDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //suppose you have a link button column 
                //LinkButton l = (LinkButton)e.Row.FindControl("lnkDescription");
                //object myDataKey = grdTransDetails.DataKeys[e.Row.RowIndex]["xrownumber"];
                ////Pass your parameter here and call trans details method
                //string rowkey = myDataKey.ToString();
                //string transDate = e.Row.Cells[1].Text;
                //l.Attributes.Add("onclick", "window.open('TransactionDetails.aspx?AccNum=" + txtAccountNumber.Text + "&" + "transDate=" + transDate + "&" + "rowKey=" + rowkey + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                if (e.Row.Cells[5].Text.Contains("-"))
                {
                    //double clearCol = double.Parse(e.Row.Cells[5].Text.Remove(0, 1));
                    //e.Row.Cells[5].Text = "(" + clearCol + ")";
                    e.Row.Cells[5].Text = "(" + e.Row.Cells[5].Text.Remove(0, 1) + ")";
                }
                if (e.Row.Cells[6].Text.Contains("-"))
                {
                    //double clearCol = double.Parse(e.Row.Cells[6].Text.Remove(0, 1));
                    //e.Row.Cells[6].Text = "(" + clearCol + ")";
                    e.Row.Cells[6].Text = "(" + e.Row.Cells[6].Text.Remove(0, 1) + ")";
                }
                if (e.Row.Cells[7].Text.Contains("-"))
                {
                    //double clearCol = double.Parse(e.Row.Cells[7].Text.Remove(0, 1));
                    e.Row.Cells[7].Text = "(" + e.Row.Cells[7].Text.Remove(0, 1) + ")";
                }
            }
        }
        public string GetCusID()
        {
            string custId = lblRelcustomerid.Text;
            return custId;
        }
        protected void grdCustomerAccSummary_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                if (e.Row.Cells[3].Text.Contains("-"))
                {
                    //double clearCol = double.Parse(e.Row.Cells[3].Text.Remove(0, 1));
                    e.Row.Cells[3].Text = "(" + e.Row.Cells[3].Text.Remove(0, 1) + ")";
                }
                if (e.Row.Cells[6].Text.Contains("-"))
                {
                    //double clearCol = double.Parse(e.Row.Cells[6].Text.Remove(0, 1));
                    e.Row.Cells[6].Text = "(" + e.Row.Cells[6].Text.Remove(0, 1) + ")";

                }
            }
        }

        private void GetAccountTransactionHistoryView(CustomerAcctsWithTransactionInfo cusAccTrans, string AccountNumber, string[] cusToken, bool CanView, AccountEnquiryGhana AccEnq, string StartDate, string EndDate, AccountEnquiryGhana2 enqAccMemo)
        {
            String memobuilder = "\\n";
            if (CanView)
            {
               
                AccountMemoInfo memoinfo = enqAccMemo.getAccounMemoInfo(cusToken[1].ToString());//Pass CustomerID Here
               

                lblMemo.Visible = true;
                lblMemo.Attributes.Add("onclick", "window.open('AccountMemo.aspx?Memo=" + cusToken[1].ToString() + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                lblMessage.Visible = false;

                if (cusAccTrans.acctsumm[0] != null)
                {
                    tbltransHist1.Visible = true;
                    tblTRANDETAILs.Visible = true;
                
                    tblAccSummary.Visible = true;
                    lblRelcustomerid.Visible = true;

                    tbltransHist1.Style["display"] = "block";
                    relatedAcc.Style["display"] = "block";
                    divPrint.Style["display"] = "block";
                  
                    //tbltransHist.Style["display"] = "block";
                    tblTRANDETAILs.Style["display"] = "block";

                    Response.Write("********GOTEHERE      ******" + "\n");

                    Response.End();

                    //lblAccoName.Text = cusAccTrans.acctsumm[0].accountname;
                    if (cusAccTrans.acctsumm[0].accountNo != null)
                    {
                        lblAccoName.Text = cusAccTrans.acctsumm[0].accountname;
                    }
                    // lblAccountNumber.Text = cusAccTrans.acctsumm[0].accountNo;
                    if (cusAccTrans.acctsumm[0].accountNo != null)
                    {
                        lblAccountNumber.Text = cusAccTrans.acctsumm[0].accountNo;
                        lblAccountNumber.Attributes.Add("onclick", "window.open('AccountDetails.aspx?accountNo=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                    }

                    lnkMandate.Visible = true;
                    lnkMandate.Attributes.Add("onclick", "window.open('AccountMandate.aspx?AccMandate=" + cusToken[1].ToString() + "&AccNumber=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                    lblAccounttype.Text = cusAccTrans.acctsumm[0].accountproduct;
                    if (cusAccTrans.acctsumm[0].openingBalance != null && cusAccTrans.acctsumm[0].openingBalance != "")
                    {
                        if (cusAccTrans.acctsumm[0].openingBalance.Contains("-"))
                        {
                            lblOpenBalance.Text = "(" + cusAccTrans.acctsumm[0].openingBalance.Remove(0, 1) + ")";
                        }
                        else
                            lblOpenBalance.Text = cusAccTrans.acctsumm[0].openingBalance;
                    }
                    else
                        lblOpenBalance.Text = "0.00";
                    if (cusAccTrans.acctsumm[0].noofLodgements != null && cusAccTrans.acctsumm[0].noofLodgements != "")
                    {
                        if (cusAccTrans.acctsumm[0].noofLodgements.Contains("-"))
                        {
                            lblNFLodgement.Text = "(" + cusAccTrans.acctsumm[0].noofLodgements.Remove(0, 1) + ")";
                        }
                        else
                            lblNFLodgement.Text = cusAccTrans.acctsumm[0].noofLodgements;
                    }
                    else
                        lblNFLodgement.Text = "0.00";

                    //lblNFLodgement.Text = cusAccTrans.acctsumm[0].noofLodgements;
                    if (cusAccTrans.acctsumm[0].noofWithdrawals != null && cusAccTrans.acctsumm[0].noofWithdrawals != "")
                    {
                        if (cusAccTrans.acctsumm[0].noofWithdrawals.Contains("-"))
                        {
                            lblNfWithdrawal.Text = "(" + cusAccTrans.acctsumm[0].noofWithdrawals.Remove(0, 1) + ")";
                        }
                        else
                            lblNfWithdrawal.Text = cusAccTrans.acctsumm[0].noofWithdrawals;
                    }
                    else
                        lblNfWithdrawal.Text = "0.00";

                    if (cusAccTrans.acctsumm[0].lodgements != null && cusAccTrans.acctsumm[0].lodgements != "")
                    {
                        if (cusAccTrans.acctsumm[0].lodgements.Contains("-"))
                        {
                            lblLodgment.Text = "(" + cusAccTrans.acctsumm[0].lodgements.Remove(0, 1) + ")";
                        }
                        else
                            lblLodgment.Text = cusAccTrans.acctsumm[0].lodgements;
                    }
                    else
                        lblLodgment.Text = "0.00";

                    if (cusAccTrans.acctsumm[0].withdrawals != null && cusAccTrans.acctsumm[0].withdrawals != "")
                    {
                        if (cusAccTrans.acctsumm[0].withdrawals.Contains("-"))
                        {
                            lblWithDrawal.Text = "(" + cusAccTrans.acctsumm[0].withdrawals.Remove(0, 1) + ")";
                        }
                        else
                            lblWithDrawal.Text = cusAccTrans.acctsumm[0].withdrawals;
                    }
                    else
                        lblWithDrawal.Text = "0.00";

                    if (cusAccTrans.acctsumm[0].closingBalance != null && cusAccTrans.acctsumm[0].closingBalance != "")
                    {
                        if (cusAccTrans.acctsumm[0].closingBalance.Contains("-"))
                        {
                            lblClosingBalance.Text = "(" + cusAccTrans.acctsumm[0].closingBalance.Remove(0, 1) + ")";
                        }
                        else
                            lblClosingBalance.Text = cusAccTrans.acctsumm[0].closingBalance;
                    }
                    else
                        lblClosingBalance.Text = "0.00";
                    lblDatePeriod.Text = StartDate + " to " + EndDate; //"April 01 2011 to April 11 2011"; //Date Period 

                    //23rd June
                    if (cusAccTrans.acctsumm[0].accountcurrency != null && cusAccTrans.acctsumm[0].accountcurrency != "")
                    {
                        lblAccountCurrency.Text = cusAccTrans.acctsumm[0].accountcurrency;
                    }
                    if (cusAccTrans.acctsumm[0].hasCOT != null && cusAccTrans.acctsumm[0].hasCOT != "")
                    {
                        lblAccountOfficer.Text = cusAccTrans.acctsumm[0].hasCOT;
                    }
                }
     
               
                
                if (cusAccTrans.acctsumm[0].tranDetails[0].desc == "NEW")
                {
                    TranDetails[] tranNull = new TranDetails[0];
                    ViewState["TranDetail"] = tranNull;
                    grdTransDetails.DataSource = tranNull;
                    grdTransDetails.DataBind();
                }
                else
                {

                    //Response.Write("ABOUT TO BIND DATA TOI  GRIDVIEW and set the OBJECT to VISIBLE and BLOCK!!!!!!!" + "\n");

                    //tbltransHist.Visible = true;
                    tblTRANDETAILs.Visible = true;
                    //tbltransHist.Visible = true;
                    tblAccSummary.Visible = true;
                    lblRelcustomerid.Visible = true;

                    tblAccSummary.Style["display"] = "block";
                    //tbltransHist.Style["display"] = "block";
                    relatedAcc.Style["display"] = "block";
                    divPrint.Style["display"] = "block";
                    //tbltransHist.Style["display"] = "block";
                    tblTRANDETAILs.Style["display"] = "block";


                    ViewState["TranDetail"] = cusAccTrans.acctsumm[0].tranDetails;
                    grdTransDetails.DataSource = cusAccTrans.acctsumm[0].tranDetails;
                    grdTransDetails.DataBind();
                    
                    //Response.Write(" SIZE AGAIN" + "\n" + cusAccTrans.acctsumm[0].tranDetails.Length);
                }
              
                ////find the index of '~'
                //string[] cusToken = customerToken.Split('~');
                CustomerAcctsInfo customerAccInfo = AccEnq.getAccountSummaryByCustomerID(cusToken[1].ToString());
                //Get the summary of the customer Account,if there is any
                if (customerAccInfo.acctsumm[0] == null)
                {
                    relatedAcc.Style["display"] = "none";
                }
                else if (customerAccInfo.acctsumm[0] != null)
                {
                    //Response.Write("DONEDONEDONEDONEDONEDONEDONEDONEDONE" + "\n");
                    //tbltransHist.Visible = true;
                    tblTRANDETAILs.Visible = true;
                    tbltransHist1.Visible = true;
                    tblAccSummary.Visible = true;
                    lblRelcustomerid.Visible = true;

                    tblAccSummary.Style["display"] = "block";
                    //tbltransHist.Style["display"] = "block";
                    relatedAcc.Style["display"] = "block";
                    divPrint.Style["display"] = "block";
                    //tbltransHist.Style["display"] = "block";
                    tblTRANDETAILs.Style["display"] = "block";
                    tbltransHist1.Style["display"] = "block";
                    Table1.Style["display"] = "block";
                    //Response.Write("EXECUTEEXECUTEEXECUTEEXECUTEEXECUTEEXECUTEEXECUTE" + "\n");

                    CustomerAccts[] customerRelatedAccountSummary = customerAccInfo.acctsumm;
                    if (customerRelatedAccountSummary.Length > 0)
                    {
                        lblRelcustomerid.Text = cusToken[1].ToString();
                        lblAccoName.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + lblRelcustomerid.Text + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                        ViewState["CustomerAccSummary"] = customerRelatedAccountSummary;
                        grdCustomerAccSummary.DataSource = customerRelatedAccountSummary;
                        grdCustomerAccSummary.DataBind();
                    }
                }
                // Audit.LogTransaction(customerAccInfo.acctsumm[0].totalbalance == "" || customerAccInfo.acctsumm[0].totalbalance == null ? "0.00" : customerAccInfo.acctsumm[0].totalbalance, SPContext.Current.Web.CurrentUser.LoginName, customerAccInfo.acctsumm[0].accountname, customerAccInfo.acctsumm[0].accountNo, "Transaction History");

                Audit.LogTransaction(customerAccInfo.acctsumm[0].totalbalance == "" || customerAccInfo.acctsumm[0].totalbalance == null ? "0.00" : customerAccInfo.acctsumm[0].totalbalance, "LoginName", customerAccInfo.acctsumm[0].accountname, customerAccInfo.acctsumm[0].accountNo, "Transaction History");

            }
            else
            {
                //tbltransHist.Style["display"] = "none";
                divPrint.Style["display"] = "none";
                relatedAcc.Style["display"] = "none";
            }
        }

        protected void grdTransDetails_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdTransDetails.PageIndex = e.NewPageIndex;

            grdTransDetails.DataSource = (TranDetails[])ViewState["TranDetail"];
            grdTransDetails.DataBind();
        }

        protected void grdCustomerAccSummary_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCustomerAccSummary.PageIndex = e.NewPageIndex;

            grdCustomerAccSummary.DataSource = (CustomerAccts[])ViewState["CustomerAccSummary"];
            grdCustomerAccSummary.DataBind();
        }
        #region
        public bool VerifyUser()
        {
            bool verifyuserIsTrue = false;

            if (CheckUserPermission.Ispermitted("TransactionHistory"))
            {
                verifyuserIsTrue = true;
            }
            else
            {
                //show message here
                verifyuserIsTrue = false;
                //tbltransHist.Style["display"] = "none";
                tblAccSummary.Visible = false;
                lblRelcustomerid.Visible = false;
                string script = "<script language='javascript'>alert('" + "You are not allowed to view other staff accounts other than yours." + "This is however open to Branch Services staff(Ops Heads,CCOs & Tellers)and requires user logs in." + "')</script>";
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);

            }
            return verifyuserIsTrue;
        }
        #endregion
    }
}
