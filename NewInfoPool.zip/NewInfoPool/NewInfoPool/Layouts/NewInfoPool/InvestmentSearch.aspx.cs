﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using InvestSpace;
using System.Web.UI.WebControls;
using System.Collections.Generic;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class InvestmentSearch : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenInvestSrchPopup()");
            }
        }

        protected void btnGetInvestment_Click(object sender, EventArgs e)

        {
            InvestmentReport invest = new InvestmentReport();
            if (!string.IsNullOrEmpty(txtCustomer.Text))
            {
               InvestmentInfo invsInfo = invest.getInvestmentInfoByCUSTOMERID(txtCustomer.Text);
               Investment[] invest_Info = invsInfo.investment;
               if (invest_Info[0] != null)
               {
                   tblInvest.Style["display"] = "block";
                   lblInvestmentName.Text = invest_Info[0].cname;
                   grdInvestment.DataSource = invest_Info;
                   grdInvestment.DataBind();
               }
               else
               {
                   tblInvest.Style["display"] = "block";
                   
                   grdInvestment.DataSource =new List<string>();
                   grdInvestment.DataBind();
               }
               //invest.getInvestmentDetailsByREFNO("");
            }
        }

        protected void grdInvestment_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //suppose you have a link button column 
                LinkButton l = (LinkButton)e.Row.FindControl("lnkInvestmentRef");
                object myDataKey = grdInvestment.DataKeys[e.Row.RowIndex]["refno"];
                //Pass your parameter here and call trans details method
                string rowkey = myDataKey.ToString();
                string transDate = e.Row.Cells[1].Text;
                //l.Attributes.Add("onclick", "window.open('InvestementDetail.aspx?RefNum=" + rowkey + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                l.Attributes.Add("onclick", "window.open('InvestementDetail.aspx?RefNum=" + rowkey + "&" + "cid=" + txtCustomer.Text.TrimEnd() + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

            }
        }

    }
}
