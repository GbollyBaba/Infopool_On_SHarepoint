﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class TransactionDetails : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["AccNum"] != null && Page.Request.QueryString["transDate"] != null && Page.Request.QueryString["rowKey"] != null)
            {
                string AccNum = Page.Request.QueryString["AccNum"].ToString();
                string transDate = Page.Request.QueryString["transDate"].ToString();
                string rowkey = Page.Request.QueryString["rowKey"].ToString();
                AccountEnquiryGhana accenq = new AccountEnquiryGhana();
                SingleTransactionDetails transDetails = accenq.getSingleTransactionDetails(AccNum, transDate, rowkey);
                if (transDetails != null)
                {
                    lblAccountNumber.Text = transDetails.accountNumber;
                    lblAmount.Text = transDetails.amount;
                    lblAutorisedBy.Text = transDetails.transactionOfficerAuthorizer;
                    lblBatchNumber.Text = transDetails.controlBatchNumber;
                    lblCurrency.Text = transDetails.currency; 
                    lblDebCrd.Text = transDetails.transactionType;
                    lblTransactionType.Text = transDetails.transactionName;
                    lblNarration.Text = transDetails.trnasactionDescription;
                    lblPostedBy.Text = transDetails.transactionOfficerInputter;
                    lblPostingDate.Text = transDetails.datePost;
                    lblReference.Text = transDetails.referenceNo;
                    lblTransactionBranch.Text = transDetails.branchName;
                    lblTransactionDescription.Text = transDetails.transactionNameDesc;
                    lblValueDate.Text = transDetails.valueDate;
                }
            }
        }
    }
}
