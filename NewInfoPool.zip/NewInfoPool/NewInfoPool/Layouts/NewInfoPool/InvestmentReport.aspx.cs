﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class InvestmentReport : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
