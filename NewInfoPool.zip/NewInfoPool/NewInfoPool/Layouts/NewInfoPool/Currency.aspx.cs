﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class Currency : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCurrency();
            }
        }

        

        public void LoadCurrency()
        {
            AccountReport report = new AccountReport();

            CurrencyCodesInfo curInfo = report.getCurrencyCodes("");
            CurrencyCodes[] Currencycodes = curInfo.currencyCodes;
            grdCurrency.DataSource = Currencycodes;
            grdCurrency.DataBind();
           
        }
    }
}
