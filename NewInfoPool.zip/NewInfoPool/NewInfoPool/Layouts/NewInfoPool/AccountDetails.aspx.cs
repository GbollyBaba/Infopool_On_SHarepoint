﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccountDetails : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Page.Request.QueryString["accountNo"] != null)
                {
                    AccountEnquiryGhana account = new AccountEnquiryGhana();
                    CustomerAcctsDetail info = account.getCustomerAcctsDetail(Page.Request.QueryString["accountNo"].ToString());
                    if (info != null)
                    {
                        LBL_AccountName.Text = info.ac_desc;
                        LBL_AccountNumber.Text = info.cust_ac_no;
                        LBL_CustomerID.Text = info.cust_no;
                        lbl_AccountType.Text = info.description;
                        lblAccountOpenDate.Text = info.ac_open_date;
                        lblAccountStatus.Text = info.record_stat;
                        lblBlockedStatus.Text = info.ac_stat_bloc;
                        lblDormantStatus.Text = info.ac_stat_dormant;
                        lblNoCreditStatus.Text = info.ac_stat_no_cr;
                        lblNoDebitStatus.Text = info.ac_stat_no_dr;
                        lblStopPayStatus.Text = info.ac_stat_stop_pay;
                        lblChequeBookFacility.Text = info.cheque_book_facility;
                        lblATMFacility.Text = info.atm_facility;
                        lblJointAccountIndicator.Text = info.joint_ac_indicator;
                        lblDateLastCredit.Text = info.date_last_cr;
                        lblDateLastDebit.Text = info.date_last_dr;
                        lblCustomerOverallLimit.Text=info.overall_limit;
                        lblLimitCurrency.Text=info.limit_ccy;
                        lblLimitRevisionDate.Text=info.revision_date;
                        lblLimitUtilized.Text=info.util_amt;
                        lblAvailableAmount.Text=info.acy_avl_bal;
                        lblBlockedAmount.Text=info.acy_blocked_amount;
                        lblCurrentBalance.Text=info.acy_curr_balance;
                        lblCreditTurnOverToday.Text=info.acy_today_tover_cr;
                        lblDebitTurnOverToday.Text=info.acy_today_tover_dr;
                        lblCreditTurnOverMTD.Text=info.acy_mtd_tover_cr;
                        lblDebitTurnOverMTD.Text=info.acy_mtd_tover_dr;
                        lblCreditTurnOver.Text = info.acy_tover_cr;




                        //LBL_Branch.Text = info.branchName;
                        //LBL_Currency.Text = info.currency;
                        //LBL_AccountStatus.Text = info.accountStatus;
                        //LBL_ATMStatus.Text = info.ATMStatus;
                        //LBL_LastSerialCheque.Text = info.lastSerialofCheque;
                        //LBL_lastUsedChequeNo.Text = info.lastUsedChequeNo;
                        //LBL_DateOpened.Text = info.dateOpened;
                        //LBL_lastMainainedBy.Text = info.lastMaintainedBy;
                        //LBL_MaintenanceAuthBy.Text = info.maintenanceAuthorizedBy;
                        //LBL_ProfitCenter.Text = info.profitCenter;
                        //LBL_AccountOfficer.Text = info.accountOfficer;
                        //LBL_BookBalance.Text = info.bookBalance;
                        //LBL_BalanceAvailable.Text = info.availableBalance;
                        //LBL_UnclearedBalance.Text = info.unavailableBalance;
                        //LBL_HoldBalance.Text = info.amountHold;
                        //LBL_AmountDebitMTD.Text = info.amountDebitMTD;
                        //LBL_AmountCreditMTD.Text = info.amountCreditMTD;
                        //LBL_AmountDebitYTD.Text=info.amountDebitYTD;
                        //LBL_AmountCreditYTD.Text = info.amountCreditYTD;
                        //LBL_AmountLastDebit.Text = info.amountLastDebit +" on "+info.lastDebitDate;
                        //LBL_AmountLastCredit.Text = info.amountLastCredit+ " on " +info.lastCreditDate;
                        //LBL_InterestPaidYTD.Text = info.interestPaidYTD;
                        //LBL_interestReceivedYTD.Text = info.interestReceivedYTD;
                        //LBL_ServiceChargeYTD.Text = info.serviceChargeYTD;
                        //LBL_LastCreditInterestAccrued.Text = info.lastCreditInterestAccrued;
                        //LBL_LastDebitInterestAccrued.Text = info.lastDebitInterestAccrued;
                        //LBL_OverDraftLimit.Text = info.ODLimit;
                        //LBL_DaueLimit.Text = info.DAUELimit;
                        //LBL_TaxAccured.Text = info.taxAccrued;


                    }
                }
                else
                {
                    Page.Response.Write("Null");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}
