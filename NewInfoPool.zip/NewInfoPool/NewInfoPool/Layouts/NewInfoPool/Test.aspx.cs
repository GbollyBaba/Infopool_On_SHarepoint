﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Web;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class Test : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnGetInvestment_Click(object sender, EventArgs e)
        {
            //AccountEnquiryGhana accEnq = new AccountEnquiryGhana();


            //string refnumber = Request.QueryString["RefNum"].ToString();
            //string cid = Request.QueryString["cid"].ToString();
            //ClientDetails1 cdetail = accEnq.getCustomerDetails(cid);

            var document = new Document(PageSize.A4, 50, 50, 25, 25);
            var output = new MemoryStream();
            var writer = PdfWriter.GetInstance(document, output);
            document.Open();

            ////var logo = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/images/AccessBankBACP/accessbank_logo.png");
            //iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/NewInfoPool/Advise/accessbank_logo.png");
            //logo.SetAbsolutePosition(380, 790);
            //document.Add(logo);

            var logo = iTextSharp.text.Image.GetInstance(Server.MapPath("~/_layouts/NewInfoPool/images/accesslogo.jpg"));
            logo.SetAbsolutePosition(380, 790);
            document.Add(logo);

            string contents = File.ReadAllText(Server.MapPath("~/_layouts/NewInfoPool/Advise/InvestmentTemp.htm"));
            contents = contents.Replace("[ValueDate]", "09-11-2015");
            contents = contents.Replace("[MaturityDate]", "09-05-2015");
            contents = contents.Replace("[Tenor]", "4");
            contents = contents.Replace("[Date]", DateTime.Now.ToString("dd,MMMM yyyy"));
            contents = contents.Replace("[InterestRate]", "25");
            contents = contents.Replace("[FaceValue]", "30,000");
            contents = contents.Replace("[InterestAmount]", "2300");
            contents = contents.Replace("[AmountMaturity]", "2300");
            contents = contents.Replace("[Issuer]", "This is testing for you guys to see");
            contents = contents.Replace("[refNo]", "1234567");

            contents = contents.Replace("[CompanyName]", "Taiwo Ojo");
            contents = contents.Replace("[address1]", "No 77A Ajose ");
            contents = contents.Replace("[address2]", "Maryland,Mende");
            contents = contents.Replace("[cur]", "GHN");
            var parseLegalHtmlElements = HTMLWorker.ParseToList(new StringReader(contents), null);
            foreach (var htmlElement in parseLegalHtmlElements)
                document.Add(htmlElement as IElement);
            document.Close();
            HttpContext.Current.Response.ContentType = "application/pdf";
            HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename=InvestmentAdvice-{0}.pdf", "Taiwo Ojo"));
            HttpContext.Current.Response.BinaryWrite(output.ToArray());
        }

    }
}
