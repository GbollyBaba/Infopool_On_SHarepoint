﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;
using System.Web.UI.WebControls;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class MyAccountList : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                string[] loginname = Currentuser.LoginName.Split('\\');
                if (loginname[1] != null)
                {
                    MyTopAccount(loginname[1]);
                }
            }
        }

        public void MyTopAccount(string username)
        {
            
            AccountReport areport = new AccountReport();
           AccountReportSpace.CustomerAcctsInfo custInfo= areport.getAccountSummaryByOutLookUserName(username);
           grdMyTop.DataSource = custInfo.acctsumm;
           grdMyTop.DataBind();
        }

        protected void grdMyTop_Rowcommand(object sender, GridViewCommandEventArgs e)
        {
            Int64 id = Int64.Parse(e.CommandArgument.ToString());
            int xx = Convert.ToInt32(id);
            SPUser Currentuser = SPContext.Current.Web.CurrentUser;
            string[] loginname = Currentuser.LoginName.Split('\\');
            AccountReport report = new AccountReport();
            switch (e.CommandName.ToLower())
            {
                case "delete":
                    GridView linkrow = sender as GridView;
                    GridViewRow row = linkrow.Rows[xx];
                    //Int32 modifiedID = Convert.ToInt32(linkrow.DataKeys[row.RowIndex].Value);
                    string accountNo = row.Cells[3].Text;
                    report.deleteMyAccount(loginname[1], accountNo);
                    Response.Redirect(Request.RawUrl);
                    break;

            }
              
        }

        protected void grdMyTop_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
    }
}
