﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;
using System.Linq;
using System.Web.UI.WebControls;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class ExchangeRateReport : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadExchange();
            }
        }


        public void LoadExchange()
        {
            AccountReport report = new AccountReport();

            ExchangeRateInfo exInfo = report.getExchangeRate("");
            ExchangeRate[] Exchangecodes = exInfo.exchangeRate;
           
            grdExchangeRate.DataSource = Exchangecodes;
            grdExchangeRate.DataBind();



            //var projectsByApp = (from p in Exchangecodes
            //                     from a in p.branch_name
            //                     group p by a into g
            //                     select new
            //                     {
            //                         Application = g.Key,
            //                         Projects = g.ToList()
            //                     }).ToList();
            //var t = projectsByApp;
        }

        protected void grdExchangeRate_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label myLabel = (Label)grdExchangeRate.FindControl("buyspread");
                if(myLabel!=null)
                myLabel.Text = myLabel.Text.Substring(0,8);
            }
        }
    }
}
