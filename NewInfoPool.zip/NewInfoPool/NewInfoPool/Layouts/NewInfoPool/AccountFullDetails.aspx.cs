﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;


namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccountFullDetails : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["AccNumber"] != null)
            {
                string AccName = Page.Request.QueryString["AccNumber"].ToString();
                AccountEnquiryGhana AccEnq = new AccountEnquiryGhana();
                CustomerAcctsDetail cusDetail = AccEnq.getCustomerAcctsDetail(AccName);
                                
            }
        }
    }
}
