﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using InvestSpace;
using InvestEnqSpace;
using System.IO;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Web;
using System.Collections.Generic;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class InvestementDetail : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Page.Request.QueryString["RefNum"] != null)
                {
                    string refnumber = Request.QueryString["RefNum"].ToString();
                    InvestmentReport invest = new InvestmentReport();
                    InvestmentDetails idetail = invest.getInvestmentDetailsByREFNO(refnumber);
                    InvestEnq inv = new InvestEnq();
                    lblAmountMaturity.Text = String.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.discountAmount));
                    lblBooking.Text = idetail.booking_date;
                    lblAddress.Text = idetail.aDDRESS_LINE4;
                    lblContractStatus.Text = idetail.contract_status;
                    lblContractNumber.Text = idetail.refno;
                    lblCurrency.Text = idetail.currency;
                    lblCustomerName.Text = idetail.customer_name1;
                    lblFaceValue.Text = String.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.amount));
                    lblInterestAmount.Text = String.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.amount_due));
                    lblInterestRate.Text = idetail.rate + "%"; //
                    lblIssuer.Text = idetail.remarks;
                    lblMaturityDate.Text = idetail.maturity_date;
                    lblMISCOde.Text = idetail.comp_mis_2;
                    lblProduct.Text = idetail.product;
                    lblSettlementAccount.Text = idetail.dr_setl_ac;
                    lblTenor.Text = idetail.tenor + " " + "day(s)";
                    lblValueDate.Text = idetail.booking_date;

                    InvestmentTransactionHistoryInfo invHistory = inv.getInvestmentTransactions(refnumber);
                    List<InvDetails> historylist = new List<InvDetails>();
                    foreach (var rowitem in invHistory.invDetails)
                    {
                        if (rowitem.desc.Length > 1)
                        {
                            historylist.Add(rowitem);
                        }
                    }
                    grdInvestmentRef.DataSource = historylist;
                    //grdInvestmentRef.DataSource = invHistory.invDetails;
                    grdInvestmentRef.DataBind();
                }
            }
        }

        protected void btnGetInvestment_Click(object sender, EventArgs e)
        {
            AccountEnquiryGhana accEnq = new AccountEnquiryGhana();


            string refnumber = Request.QueryString["RefNum"].ToString();
            string cid = Request.QueryString["cid"].ToString();
            InvestmentReport invest = new InvestmentReport();
            InvestmentDetails idetail = invest.getInvestmentDetailsByREFNO(refnumber);
            ClientDetails1 cdetail = accEnq.getCustomerDetails(cid);

            InvestEnq inv = new InvestEnq();
            InvestmentTransactionHistoryInfo invHistory = inv.getInvestmentTransactions(refnumber);
            int lenght=invHistory.invDetails.Length-1;

            var document = new Document(PageSize.A4, 50, 50, 25, 25);
            var output = new MemoryStream();
            var writer = PdfWriter.GetInstance(document, output);
            document.Open();

            //var logo = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/NewInfoPool/images/accessbank_logo.png");
            //iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/NewInfoPool/images/accessbank_logo.png");

            //iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(SPContext.Current.Web.Url + "/_layouts/images/AccessBankBACP/accessbank_logo.png");
            var logo = iTextSharp.text.Image.GetInstance(Server.MapPath("~/_layouts/NewInfoPool/images/accessbank_logo.png"));
            logo.SetAbsolutePosition(380, 790);
            document.Add(logo);

            string contents = File.ReadAllText(Server.MapPath("~/_layouts/NewInfoPool/Advise/InvestmentTemp.htm"));
            contents = contents.Replace("[ValueDate]", idetail.booking_date);
            contents = contents.Replace("[MaturityDate]", idetail.maturity_date);
            if (idetail.tenor != "1")
                contents = contents.Replace("[Tenor]", idetail.tenor + " " + " days");
            else
                contents = contents.Replace("[Tenor]", idetail.tenor + "" + "day");
            contents = contents.Replace("[contract]", idetail.refno.Substring(3,4));
            contents = contents.Replace("[InterestRate]", idetail.rate + "%");
            //contents = contents.Replace("[FaceValue]", string.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.amount)));
            contents = contents.Replace("[FaceValue]", invHistory.invDetails[lenght].xybalance);

            contents = contents.Replace("[InterestAmount]", string.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.amount_due)));
            contents = contents.Replace("[AmountMaturity]", string.Format("{0:#0,00.00}", Convert.ToDecimal(idetail.discountAmount)));
            contents = contents.Replace("[Issuer]", idetail.remarks); 
            contents = contents.Replace("[refNo]", idetail.refno);
            contents = contents.Replace("[Date]", DateTime.Now.ToString("dd,MMMM yyyy"));
            contents = contents.Replace("[CompanyName]", cdetail.customer_name1);
            contents = contents.Replace("[address1]", idetail.aDDRESS_LINE1);
            contents = contents.Replace("[address2]", idetail.aDDRESS_LINE2);
            contents = contents.Replace("[cur]",idetail.currency);

            var parseLegalHtmlElements = HTMLWorker.ParseToList(new StringReader(contents), null);
            foreach (var htmlElement in parseLegalHtmlElements)
                document.Add(htmlElement as IElement);
            document.Close();
            HttpContext.Current.Response.ContentType = "application/pdf";
            HttpContext.Current.Response.AddHeader("Content-Disposition", string.Format("attachment;filename=InvestmentAdvice-{0}.pdf", cdetail.customer_name1));
            HttpContext.Current.Response.BinaryWrite(output.ToArray());
        }
    }
}
