﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using InfoPool.Audit;
using System.Linq;
using System.Web.UI.WebControls;
using InfoPool.AuditBK;
using System.Globalization;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AuditLog : LayoutsPageBase
    {
        
        public string StartDateServertValue = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).Date.ToString("dd/MM/yyyy");
        public string EndDateServertValue = DateTime.Today.ToString("dd/MM/yyyy");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        protected void btnGetList_Click(object o, EventArgs e)//Month/Day/Year
        {
            
            int optionvalue = rdoAudit.SelectedIndex;

            string StatrtDate = Page.Request.Form["startinput"].ToString();
            string EndDate = Page.Request.Form["endinput"].ToString();

            

            int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
            int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
            int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
            DateTime dstart = new DateTime(Year, Month, Day);
            string startdate = dstart.ToString("MM/dd/yyyy");

            int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
            int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
            int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
            DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
            string enddate = dend.ToString("MM/dd/yyyy");


            if (startdate == null || startdate == "")
            {
                return;
            }
            if (enddate == null || enddate == "")
            {
                return;
            }
            if (rdoAudit.SelectedIndex == 0)
            {
            
                GetAuditRecord(startdate, enddate, txtLoginName.Text, optionvalue);
            }
            else
            {          
                GetAuditRecordBK(startdate, enddate, txtLoginName.Text, optionvalue);
            }
            StartDateServertValue = StatrtDate;
            EndDateServertValue = EndDate;
        }

        public void GetAuditRecord(string StartDate, string EndDate, string loginName, int optionValue)
        {

            DateTime startdate = DateTime.Parse(StartDate);
            DateTime enddate = DateTime.Parse(EndDate);
            if (startdate == null || enddate == null)
            {
                return;
            }
            //if option is old value
            SPWeb web = SPContext.Current.Web;
            string CurrentUser = web.CurrentUser.LoginName;
            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (AuditLogEntity AuditContext = new AuditLogEntity(SPContext.Current.Web.Url))
                {
                    if (!string.IsNullOrEmpty(loginName) && optionValue == 0)//You are looking at new record here
                    {
                        var Audit = (from audlog in AuditContext.AuditLog
                                     where ((audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date) && audlog.Title == loginName)
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (string.IsNullOrEmpty(loginName) && optionValue == 0)
                    {
                        var Audit = (from audlog in AuditContext.AuditLog
                                     where audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (!string.IsNullOrEmpty(loginName) && optionValue == 1)//You are to check old backup AuditList
                    {
                        var Audit = (from audlog in AuditContext.AuditLog
                                     where ((audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date) && audlog.Title == loginName)
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (string.IsNullOrEmpty(loginName) && optionValue == 1)//You are to check old backup AuditList ,load by Selected Date here
                    {
                        var Audit = (from audlog in AuditContext.AuditLog
                                     where audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            Session["Audit"] = Audit;
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }


                }

            });
        }

        public void GetAuditRecordBK(string StartDate, string EndDate, string loginName, int optionValue)
        {

            DateTime startdate = DateTime.Parse(StartDate);
            DateTime enddate = DateTime.Parse(EndDate);
            if (startdate == null || enddate == null)
            {
                return;
            }
            //if option is old value
            SPWeb web = SPContext.Current.Web;
            string CurrentUser = web.CurrentUser.LoginName;
            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (AuditLogBKEntity AuditContext = new AuditLogBKEntity(SPContext.Current.Web.Url))
                {
                    if (!string.IsNullOrEmpty(loginName) && optionValue == 0)//You are looking at new record here
                    {
                        var Audit = (from audlog in AuditContext.AuditLogBK
                                     where ((audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date) && audlog.Title == loginName)
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (string.IsNullOrEmpty(loginName) && optionValue == 0)
                    {
                        var Audit = (from audlog in AuditContext.AuditLogBK
                                     where audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (!string.IsNullOrEmpty(loginName) && optionValue == 1)//You are to check old backup AuditList
                    {
                        var Audit = (from audlog in AuditContext.AuditLogBK
                                     where ((audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date) && audlog.Title == loginName)
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }
                    else if (string.IsNullOrEmpty(loginName) && optionValue == 1)//You are to check old backup AuditList ,load by Selected Date here
                    {
                        var Audit = (from audlog in AuditContext.AuditLogBK
                                     where audlog.DateModified.Value.Date >= startdate.Date && audlog.DateModified.Value.Date <= enddate.Date
                                     select new { CurrentUser = audlog.Title, AccountName = audlog.AccountName, AccountNumber = audlog.AccountNumber, ActionPerform = audlog.ActionPerformed, Balance = audlog.Balance, IPAddress = audlog.IPAddress, ServerName = audlog.ServerName, ModifiedDate = audlog.DateModified }).ToList();

                        if (Audit.Count > 0)
                        {
                            Session["Audit"] = Audit;
                            grdAuditTrail.DataSource = Audit;
                            grdAuditTrail.DataBind();
                        }
                    }


                }

            });
        }

        protected void grdAuditTrail__PageIndexChanged(object sender, EventArgs e)
        {

          
        }

        protected void grdAuditTrail_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {

                grdAuditTrail.PageIndex = e.NewPageIndex;
                int optionvalue = rdoAudit.SelectedIndex;
                string StatrtDate = Page.Request.Form["startinput"].ToString();
                string EndDate = Page.Request.Form["endinput"].ToString();

                int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
                int Month = Convert.ToInt32(EndDate.Split('/')[1]);
                int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
                DateTime dstart = new DateTime(Year, Month, Day);
                string startdate = dstart.ToString("MM/dd/yyyy");

                int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
                int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
                int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
                DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
                string enddate = dend.ToString("MM/dd/yyyy");

                StartDateServertValue = StatrtDate;
                EndDateServertValue = EndDate;
                if (optionvalue == 0)
                {
                    GetAuditRecord(startdate, enddate, txtLoginName.Text, optionvalue);
                }
                else
                {
                    GetAuditRecordBK(startdate, enddate, txtLoginName.Text, optionvalue);
                }
               
                grdAuditTrail.PageIndex = e.NewPageIndex;
                grdAuditTrail.DataBind();
               
            }
            catch (Exception ex )
            {
                string message = ex.Message;
            }

            
        }
    }
}
