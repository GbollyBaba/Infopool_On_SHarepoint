﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using NewInfoPool.Utilities;
using AuditSpace;
using System.Web;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccountMandate : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //AccNumber
            if (Page.Request.QueryString["AccMandate"] != null && Page.Request.QueryString["AccNumber"] != null)
            {
                string CustomerID = Page.Request.QueryString["AccMandate"].ToString();
                string AccountNumber = Page.Request.QueryString["AccNumber"].ToString();
                AccountEnquiryGhana2 accenq = new AccountEnquiryGhana2();
                AccounImagesCollection accountImages = accenq.getImageCollection(CustomerID);
                ///call the memo
                AccountMemoInfo memoinfo = accenq.getAccounMemoInfo(AccountNumber);

                if (memoinfo.description != null)
                {
                    grdMemo.DataSource = memoinfo.accountMemo;
                    grdMemo.DataBind();
                }


                TableCell signaturecell = null;
                TableCell Photocell = null;
                TableCell Namecell = null;
                TableCell CustomerDetailscell = null;

                
                foreach (AccountImagesDirectors accimgDtr in accountImages.accountImagesDirectors)
                {
                    
                    if (accimgDtr != null)
                    {
                        lblInstruct.Text = accimgDtr.txt_acct_oper_instrs1;
                        TableRow rowNew = new TableRow();
                        MandateTable.Controls.Add(rowNew);

                        Namecell = new TableCell();
                        Label lblname = new Label();
                        lblname.Text = accimgDtr.nam_cust_shrt ;
                        Namecell.Controls.Add(lblname);
                        rowNew.Controls.Add(Namecell);

                        signaturecell = new TableCell();
                        Image mandateSignature = new Image();
                        mandateSignature.ImageUrl = accimgDtr.cust_imageURL1;
                        if (accimgDtr.cust_imageURL1 == null || accimgDtr.cust_imageURL1 == "")
                            mandateSignature.Visible = false;
                        signaturecell.Controls.Add(mandateSignature);
                        rowNew.Controls.Add(signaturecell);

                        Photocell = new TableCell();
                        Image mandatePhoto = new Image();
                        mandatePhoto.ImageUrl = accimgDtr.cust_imageURL2;
                        if (accimgDtr.cust_imageURL2 == null || accimgDtr.cust_imageURL2 == "")
                            mandatePhoto.Visible = false;
                        Photocell.Controls.Add(mandatePhoto);
                        rowNew.Controls.Add(Photocell);

                        CustomerDetailscell = new TableCell();
                        LinkButton cusDeatilsLink = new LinkButton();
                        //cusDeatilsLink.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + accimgDtr.cod_cust_id + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                        cusDeatilsLink.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + accountImages.custID + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                        cusDeatilsLink.Text = "Customer Details";
                        CustomerDetailscell.Controls.Add(cusDeatilsLink);
                        rowNew.Controls.Add(CustomerDetailscell);

                    }
                }
                
                Audit.LogTransaction("", SPContext.Current.Web.CurrentUser.LoginName, "", "", "Account Mandate");

            }
        }
    }
}
