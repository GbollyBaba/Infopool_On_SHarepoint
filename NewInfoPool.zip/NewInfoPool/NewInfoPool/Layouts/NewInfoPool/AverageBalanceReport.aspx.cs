﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using AccountReportSpace2;
using System.Web;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Collections.Generic;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AverageBalanceReport : LayoutsPageBase
    {
        public string StartDateServertValue = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).Date.ToString("dd/MM/yyyy");
        public string EndDateServertValue = DateTime.Today.ToString("dd/MM/yyyy");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                string[] loginname = Currentuser.LoginName.Split('\\');
                AccountReport2 accReport = new AccountReport2();
                string miscode = accReport.getMISCODEByOutlookUsername(loginname[1]);
                if(miscode.Contains("invalid identifier"))
                {

                }
                else
                txtMiscode.Text = miscode;
            }

        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        protected void btnSearchTransHistory_Click(object sender, EventArgs e)
        {
            AccountReport report = new AccountReport();

            if (!string.IsNullOrEmpty(txtMiscode.Text))
            {

                string StatrtDate = Page.Request.Form["startinput"].ToString();
                string EndDate = Page.Request.Form["endinput"].ToString();
                StartDateServertValue = StatrtDate;
                EndDateServertValue = EndDate;
                if (StatrtDate == "" || EndDate == "")
                {
                    return;
                }
                if (StatrtDate == null || EndDate == null)
                {
                    return;
                }
                int Year = Convert.ToInt32(StatrtDate.Split('/')[2]);
                int Month = Convert.ToInt32(StatrtDate.Split('/')[1]);
                int Day = Convert.ToInt32(StatrtDate.Split('/')[0]);
                DateTime dstart = new DateTime(Year, Month, Day);
                string startdate = dstart.ToString("dd-MMM-yyyy");

                int YearEnd = Convert.ToInt32(EndDate.Split('/')[2]);
                int MonthEnd = Convert.ToInt32(EndDate.Split('/')[1]);
                int DayEnd = Convert.ToInt32(EndDate.Split('/')[0]);
                DateTime dend = new DateTime(YearEnd, MonthEnd, DayEnd);
                string enddate = dend.ToString("dd-MMM-yyyy");

                AverageBalanceInfo infoooop = report.getAverageBalanceInfoByMISCODE(txtMiscode.Text, startdate, enddate);
                AverageBalance[] fd = infoooop.averageBalance;

                List<AverageBalanceEntity> AverageBal = new List<AverageBalanceEntity>();
                foreach (var ab in fd)
                {
                    AverageBalanceEntity abal = new AverageBalanceEntity();
                    string[] aveBalance = ab.account.Split('~');
                    abal.ACCOUNTNO = aveBalance[0].ToString();
                    abal.ACCOUNTNAME = aveBalance[1].ToString();
                    abal.ACCOUNTCURRENCY = aveBalance[2].ToString();
                    abal.ACTUALBALANCE = aveBalance[3].ToString();
                    abal.balance_credit = ab.balance_credit;
                    abal.balance_credit_average = ab.balance_credit_average;
                    abal.balance_debit = ab.balance_debit;
                    abal.balance_debit_average = ab.balance_debit_average;
                    AverageBal.Add(abal);
                }
                 
                if (fd != null)
                {
                    tblInvest.Style["display"] = "block";
                    //ViewState["averageBalance"] = fd;
                    //grdAveBalance.DataSource = fd;
                    //grdAveBalance.DataBind();

                    ViewState["averageBalance"] = AverageBal;
                    grdAveBalance.DataSource = AverageBal;
                    grdAveBalance.DataBind();
                }
               
            }
        }

        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAveBalance.PageIndex = e.NewPageIndex;

            //grdAveBalance.DataSource = (AverageBalance[])ViewState["averageBalance"];
            grdAveBalance.DataSource = (AverageBalanceEntity[])ViewState["averageBalance"];
            grdAveBalance.DataBind();
        }

        protected void ExportToExcel(object sender, EventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=AverageBal.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                grdAveBalance.AllowPaging = false;
                //grdAveBalance.DataSource = (AverageBalance[])ViewState["averageBalance"];
                grdAveBalance.DataSource = (AverageBalanceEntity[])ViewState["averageBalance"];
                
                grdAveBalance.DataBind();

                grdAveBalance.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in grdAveBalance.HeaderRow.Cells)
                {
                    cell.BackColor = grdAveBalance.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in grdAveBalance.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = grdAveBalance.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = grdAveBalance.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                grdAveBalance.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }

        protected void btnExportPDF_Click(object sender, EventArgs e)
        {
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition","attachment;filename=AverageBal.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            grdAveBalance.AllowPaging = false;
            //grdAveBalance.DataSource = (AverageBalance[])ViewState["averageBalance"];
            grdAveBalance.DataSource = (AverageBalanceEntity[])ViewState["averageBalance"];
            grdAveBalance.DataBind();
            grdAveBalance.RenderControl(hw);
            StringReader sr = new StringReader(sw.ToString());
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
        }


    }
}

 [Serializable]
public class AverageBalanceEntity
{
    //ACCOUNTNO~ACCOUNTNAME~ACCOUNTCURRENCY~ACTUALBALANCE
   
        public string ACCOUNTNO
        {
            get;set;
        }
        public string ACCOUNTNAME
        {
            get;
            set;
        }
        public string ACCOUNTCURRENCY
        {
            get;
            set;
        }
        public string ACTUALBALANCE
        {
            get;
            set;
        }

        public string balance_credit
        {
            get;
            set;
        }

        public string balance_credit_average
        {
            get;
            set;
        }

        public string balance_debit
        {
            get;
            set;
        }

        public string balance_debit_average
        {
            get;
            set;
        }

}