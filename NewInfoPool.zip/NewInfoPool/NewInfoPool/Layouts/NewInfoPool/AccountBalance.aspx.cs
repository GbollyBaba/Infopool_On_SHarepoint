﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Linq;
using Microsoft.SharePoint.Linq;
using NewInfoPool.Utilities;
using System.Text;
using System.Drawing;
using Utilities.ActiveDirectory;
using InvestEnqSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccountBalance : LayoutsPageBase
    {
        string url = SPContext.Current.Web.Url;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check the user authentication and autorization here. 
            if (!Page.IsPostBack)
            {
                lblMessage.Visible = false;
                lblMessage.Text = "";
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenSrchPopup()");
                            
                //get to the active directory and get the ssa

                SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                string[] loginname = Currentuser.LoginName.Split('\\');
                //Fms080811$$
                //loginname[1] = "igwee";
                AccountEnquiryGhana en = new AccountEnquiryGhana();
                Response.Write("loginname[1].ToString() ::::" + loginname[1].ToString() + "\n");
                // int result = GetCurrentUserActiveDirectoryInfo.GetActiveDirectoryInfo(loginname[1].ToString(), en);
                String loginName = loginname[1].ToString().Trim();
                Response.Write("lloginNameloginNameloginName::::" + loginName + "\n");

                Response.Write("URL BASE:::::" + SPContext.Current.Web.Url);

                int result = 0;
                try
                {
                  

                    string accountNumber = en.getStaffAccounfromoutlookUsername(loginName);
                    Response.Write("accountNumber ::::" + accountNumber + "\n");
                    if (accountNumber.Length == 13)//
                    {

                        // Response.Write("ENTERE EGEEHERERERE ::::"  + "\n");
                        string MyStaffCustomerId = en.getCustomerID(accountNumber);

                        Response.Write("MyStaffCustomerId MyStaffCustomerId ::::" +MyStaffCustomerId + "\n");
                        //HttpContext.Current.Session["MyStaffCustomerId"] = MyStaffCustomerId;
                        //Session["MyStaffCustomerId"] = MyStaffCustomerId;

                         result = 1;
                    }
                    else
                    {
                         result = 0;
                    }
                    //HttpContext.Current.Session["MyStaffCustomerId"] = "134886";
                    //return result = 1;
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("The server is not operational."))
                    {
                        string message = ex.Message;

                         result = -1;
                    }

                }

                 Response.Write("result ::::" + result + "\n");
                // Response.End();
                 if (result== 1)//
                {
                    //User can proceed on 
                    StringBuilder builderinfo = new StringBuilder();
                    builderinfo.AppendLine("Current User: " + Currentuser.Name);
                    builderinfo.AppendLine("Date :" + DateTime.Now.ToString());
                    Response.Write(" Currentuser.Name ::::" + Currentuser.Name + "\n");

                }
                 else if (result == 0)
                {
               
                    Response.Redirect("AccNumber.aspx" );
                }
              

               
            }
        }


        protected void btnSearchAccountNumber_Click(object sender, EventArgs e)
        {
            Panel1.Style["display"] = "none";
            if (string.IsNullOrEmpty(txtAccountNumber.Text))
            {
                return;
            }
            string AccountNumber = txtAccountNumber.Text.Trim();
            GetAccountSummary(AccountNumber);
        }
        
        private void GetAccountSummary(string AccountNumber)
        {
            StringBuilder build = new StringBuilder();
            try
            {
                //Clear web controls first
                ResetFormControlValues();
                txtAccountNumber.Text = AccountNumber;
                AccountEnquiryGhana en = new AccountEnquiryGhana();
                AccountEnquiryGhana2 enqAccMemo = new AccountEnquiryGhana2();
                CustomerAcctsInfo info = en.getAccountSummary(AccountNumber);
                //Obtain Customer ID Here
                string customerToken = info.customerID;
                //find the index of '~'
                string[] cusToken = customerToken.Split('~');//To get Customer ID
                bool CanView = false;

               
                if (info.acctsumm == null || info.acctsumm[0] == null)
                {
                    lblMessage.Visible = true;
                    Panel1.Style["display"] = "none";
                    lblMessage.Text = "Account Number does not exist";
                    lblMessage.ForeColor = Color.Red;
                    return;
                }
                //Compare the customerId in the session with Customer id u ve here
                SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                string[] loginname = Currentuser.LoginName.Split('\\');
                string loginName = loginname[1];
                string accountNumber = en.getStaffAccounfromoutlookUsername(loginName);
                string MyStaffCustomerId = en.getCustomerID(accountNumber);

                //if (Session["MyStaffCustomerId"] != null)
                if (MyStaffCustomerId != null)
                {
                    string customerid = MyStaffCustomerId.ToString();
                    int retval = string.Compare(customerid, cusToken[1].ToString());
                    if (retval == 0)
                    {
                        //It shows that the current logging staff owns the account 
                        GetAccountView(info, AccountNumber, cusToken, true, en);
                    }
                    else //Validate the User permission here
                    {
                        if (info.acctsumm[0] != null)
                        {
                            #region
                            //Check to see if the user can view this account
                            if (info.acctsumm[0].flgempacct == "Y" && info.acctsumm[0].flgstaff == "N")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (info.acctsumm[0].flgempacct == "Y" && info.acctsumm[0].flgstaff == "Y")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (info.acctsumm[0].flgempacct == "N" && info.acctsumm[0].flgstaff == "Y")
                            {
                                //Staff or Employee Account
                                CanView = VerifyUser();
                            }
                            else if (info.acctsumm[0].flgempacct == "N" && info.acctsumm[0].flgstaff == "N")
                            {
                                //This is for individual
                              
                                CanView = GetrestrictedLevel(AccountNumber);
                            }
                            #endregion
                            GetAccountView(info, AccountNumber, cusToken, CanView, en);

                        }
                        else if (info.acctsumm == null)
                        {
                            lblMessage.Visible = true;
                            Panel1.Style["display"] = "none";
                            lblMessage.Text = "Account Number does not exist";
                            lblMessage.ForeColor = Color.Red;
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                if (message == "Unable to connect to the remote server")
                {
                    string script = "<script language='javascript'>alert('" + "Unable to connect to the remote server" + "')</script>";
                    Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
                }
            }
        }


        public bool GetrestrictedLevel(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);

            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);



                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                string my_groupname = web.Groups[result1].Name;
                if (result1 == "0000000000")
                {
                    Result = true;
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                }
                else
                {
                    // MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact " + my_groupname + " . ");
                }

            }
            else
            {
                //result\
                string distMemo = result;
                if (distMemo.Trim() == "RMEM0")
                {
                    MessagePrompt.ShowMessage(this, " Attention: Incomplete account opening documentation.!!!!");
                    Result = true;

                }
                else
                {
                    string[] distMemoList = distMemo.Split(',');
                    SPWeb web = SPContext.Current.Web;
                    if (distMemoList.Length > 0)
                    {
                        foreach (string distMemoElement in distMemoList)
                        {
                            if (web.Groups[distMemoElement].ContainsCurrentUser)
                            {
                                Result = true;
                                //break;
                            }
                            //test for new memo 
                            if (distMemoElement.Trim() == "RMEM0")
                            {
                                Result = true;
                                MessagePrompt.ShowMessage(this, " Attention: Incomplete account opening documentation.!!!!");
                            }

                        }
                        if (Result == false)
                        {
                            MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                        }
                    }



                }

            }
            return Result;
        }

        public bool GetrestrictedLevelOLD(string AccountNumber)
        {
            //bool Canview = false;
            bool Result = false;
            InvestEnq inv = new InvestEnq();
            string result = inv.getRestictionByAcct(AccountNumber);

            if (result == "0000000000")//It means not resctricted
            {
                string result1 = inv.getRestictionByCustID(AccountNumber);
                //result1 = result1.ToUpper();
                SPWeb web = SPContext.Current.Web;
                if (result1 == "0000000000")
                {
                    Result = true;
                    //MessagePrompt.ShowMessage(this, "This account belong to HNIS,You are not authorised to view this account, kindly contact administrator.");
                }
                else if (web.Groups[result1].ContainsCurrentUser)
                {
                    Result = true;  //IT MEANS IS AN HNI USER
                }
                else
                {
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact Ghana PrivateBanking Group/Wealth Management.");
                }

            }
            else
            {
                SPWeb web = SPContext.Current.Web;
                string[] grp = result.Split(',');
                for (int i = 0; i < grp.Length; i++)
                {
                    if (web.Groups[grp[i]].ContainsCurrentUser)
                    {
                        Result = true;
                        break;
                    }
                }
                if (Result == false)
                {
                    MessagePrompt.ShowMessage(this, "You are not authorised to view this account, please contact the Remedial Assest/CRM.");
                }
            }
            return Result;
        }

        private void GetAccountView(CustomerAcctsInfo info, string AccountNumber, string[] cusToken, bool CanView, AccountEnquiryGhana en)
        {
            String memobuilder = "\\n";
            if (CanView)
            {
                AccountEnquiryGhana2 enqAccMemo = new AccountEnquiryGhana2();
                CustomerAcctsInfo infoinfo = en.getAccountSummary(AccountNumber);
                //Obtain Customer ID Here
                string customerToken = infoinfo.customerID;
                //find the index of '~'
                string[] cusTokeninfo = customerToken.Split('~');//To get Customer ID

                
                #region Memo
                AccountMemoInfo memoinfo = enqAccMemo.getAccounMemoInfo(cusTokeninfo[1].ToString());//Pass CustomerID Here
                //AccountMemo[] memo = memoinfo.accountMemo;

                //if (memoinfo.description != null)
                //{

                //    for (int i = 0; i < memoinfo.accountMemo.Length; i++)
                //    {
                //        memobuilder += "\\n" + memoinfo.accountMemo[i].memotext;
                //    }
                //    string taiwo = memobuilder.Replace("/", "");
                //    string script = "<script language='javascript'>alert('" + taiwo + "')</script>";
                //    Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
                //}


                lblMemo.Visible = true;
                lblMemo.Attributes.Add("onclick", "window.open('AccountMemo.aspx?Memo=" + cusToken[1].ToString() + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,resizable=no,scrollbars=yes,top=200,left=250');return false;");


                lblMessage.Visible = false;
                Panel1.Visible = true;
                Panel1.Style["display"] = "block";
                if (info.acctsumm[0].hasCOT == "1")
                {
                    lnkCOT.Visible = true;
                    lnkCOT.Attributes.Add("onclick", "window.open('COTDetails.aspx?Cdetails=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                }

                CustomerAcctsInfo customerAccInfo = en.getAccountSummaryByCustomerID(cusToken[1].ToString());
                //if (info.acctsumm[0].hasIMAGE == "0")
                //{
                //    //Show Mandate Hyperlink 
                lnkMandate.Visible = true;
                //added the account number to take care of the account numbe specific memo by call the webservices with account Memo  INF_AccounMemo
                //lnkMandate.Attributes.Add("onclick", "window.open('AccountMandate.aspx?AccMandate=" + cusToken[1].ToString() +  "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                lnkMandate.Attributes.Add("onclick", "window.open('AccountMandate.aspx?AccMandate=" + cusToken[1].ToString() + "&AccNumber=" + AccountNumber +"&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                //}

                if (info.acctsumm[0].accountname != null)
                {
                    lkbAccountName.Text = info.acctsumm[0].accountname;
                }
                if (info.acctsumm[0].accountNo != null)
                {
                    lblAccountNumber.Text = info.acctsumm[0].accountNo;
                    lblAccountNumber.Attributes.Add("onclick", "window.open('AccountDetails.aspx?accountNo=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                }
                if (info.acctsumm[0].accountproduct != null)
                {
                    lblAccountType.Text = info.acctsumm[0].accountproduct;
                }
                //10-10
                //if (info.acctsumm[0].clearedBalance != null && info.acctsumm[0].clearedBalance != "")
                //{
                //    if (info.acctsumm[0].clearedBalance.Contains("-"))
                //    {
                //        lblClearBalance.Text = "(" + info.acctsumm[0].clearedBalance.Remove(0, 1) + ")";
                //    }
                //    else
                //        lblClearBalance.Text = info.acctsumm[0].clearedBalance;
                //}
                //else
                //{
                //    lblClearBalance.Text = "0.00";
                //}
                if (info.acctsumm[0].unclearedBalance != null && info.acctsumm[0].unclearedBalance != "")
                {
                    lblUnClearBalance.Text = info.acctsumm[0].unclearedBalance;
                }
                else
                    lblUnClearBalance.Text = "0.00";
                if (info.acctsumm[0].totalbalance != null && info.acctsumm[0].totalbalance != "")
                {
                    if (info.acctsumm[0].totalbalance.Contains("-"))
                    {
                        lblTotalBalance.Text = "(" + info.acctsumm[0].totalbalance.Remove(0, 1) + ")";
                    }
                    else
                        lblTotalBalance.Text = info.acctsumm[0].totalbalance;
                }
                else
                    lblTotalBalance.Text = "0.00";
                if (info.acctsumm[0].amountHold != null && info.acctsumm[0].amountHold != "")
                {
                    lblHoldAmount.Text = info.acctsumm[0].amountHold;
                }
                else
                    lblHoldAmount.Text = "0.00";
                //if (info.acctsumm[0].netbalance != null && info.acctsumm[0].netbalance != "")
                //{
                //    if (info.acctsumm[0].netbalance.Contains("-"))
                //    {
                //        lblNetBalance.Text = "(" + info.acctsumm[0].netbalance.Remove(0, 1) + ")";
                //    }
                //    else
                //        lblNetBalance.Text = info.acctsumm[0].netbalance;
                //}
                //else
                //    lblNetBalance.Text = "0.00";
                if (info.acctsumm[0].oDLimit != null && info.acctsumm[0].oDLimit != "")
                {
                    lblOdLimit.Text = info.acctsumm[0].oDLimit;
                }
                else
                    lblOdLimit.Text = "0.00";
                if (info.acctsumm[0].availabletowithdraw != null && info.acctsumm[0].availabletowithdraw != "")
                {
                    if (info.acctsumm[0].availabletowithdraw.Contains("-"))
                    {
                        lblAvailableToWithDraw.Text = "(" + info.acctsumm[0].availabletowithdraw.Remove(0, 1) + ")";
                    }
                    else
                        lblAvailableToWithDraw.Text = info.acctsumm[0].availabletowithdraw;
                }
                else
                    lblAvailableToWithDraw.Text = "0.00";
                //if (info.acctsumm[0].DAUE != null && info.acctsumm[0].DAUE != "")
                //{
                //    lblDAUE.Text = info.acctsumm[0].DAUE;
                //}
                //else
                //    lblDAUE.Text = "0.00";
                //Get the summary of the customer Account,if there is any
                if (customerAccInfo.acctsumm[0] == null)
                {
                    relatedDiv.Style["dislay"] = "none";
                }
                else if (customerAccInfo.acctsumm[0] != null)
                {
                    Panel1.Visible = true;
                    Panel1.Style["display"] = "block";

                    CustomerAccts[] customerRelatedAccountSummary = customerAccInfo.acctsumm;
                    if (customerRelatedAccountSummary.Length > 0)
                    {
                        customerid.Text = cusToken[1].ToString();
                        lkbAccountName.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + customerid.Text + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                        tblcustomerAccSummaryId.Visible = true;
                        grdCustomerAccSummary.DataSource = customerRelatedAccountSummary;
                        grdCustomerAccSummary.DataBind();
                    }
                }
                //23rd June
                if (info.acctsumm[0].accountcurrency != null && info.acctsumm[0].accountcurrency != "")
                {
                    lblAccountCurrency.Text = info.acctsumm[0].accountcurrency;
                }
                if (info.acctsumm[0].hasCOT != null && info.acctsumm[0].hasCOT != "")
                {
                    lblAccountOfficer.Text = info.acctsumm[0].hasCOT;
                }

                Audit.LogTransaction(info.acctsumm[0].totalbalance == "" || info.acctsumm[0].totalbalance == null ? "0.00" : info.acctsumm[0].totalbalance, SPContext.Current.Web.CurrentUser.LoginName, info.acctsumm[0].accountname, info.acctsumm[0].accountNo, "Account Balance");
            }
            else
            {
                lblMessage.Visible = true;
                Panel1.Style["display"] = "none";
            }
                #endregion
        }
      
        private void ResetFormControlValues()
        {

            lkbAccountName.Text = "";
            lblAccountNumber.Text = "";
            lblAccountType.Text = "";
            //lblClearBalance.Text = "";//10-10
            lblUnClearBalance.Text = "";
            lblTotalBalance.Text = "";
            lblHoldAmount.Text = "";
            //lblNetBalance.Text = "";
            lblOdLimit.Text = "";
            lblAvailableToWithDraw.Text = "";
            //lblDAUE.Text = "";

        }
       
        static bool EnumerateValue(String Operand)
        {
            IEnumerator OperandEnum = Operand.GetEnumerator();
            int CharCount = 0;
            bool ans = false;
            while (OperandEnum.MoveNext())
            {
                CharCount++;
                char t = (char)OperandEnum.Current;
                if (char.IsNumber(t))//Check for AccountNumber
                {
                    ans = true;
                }
                else if (char.IsLetter(t))//Check for AccountName
                {
                    ans = false;
                }

                return ans;
            }
            return ans;

        }
        
        private bool AccountVerificationType(string Accountnumber, string UserName, string Currenturl)
        {
            bool validuser = false;

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (StaffSalaryAccountEntity AccSalaryContext = new StaffSalaryAccountEntity(Currenturl))
                {
                    string[] usernameToken = UserName.Split('\\');
                    var menuitem = (from accSalary in AccSalaryContext.StaffSalaryAccount
                                    where accSalary.Title == usernameToken[1] && accSalary.SalaryAccountNumber == Accountnumber
                                    select new { Valid = "true" }).FirstOrDefault();
                    if (menuitem != null && menuitem.Valid == "true")
                    {
                        Session["UserAccount"] = Accountnumber;
                        validuser = true;
                    }
                    else if (menuitem == null)
                        validuser = false;

                }

            });
            return validuser;
        }

        
        
        
        protected void grdCustomerAccSummary_Rowcommand(object sender, GridViewCommandEventArgs e)
        {
            bool AccCus = true;
            //this get the text of ur link button
            LinkButton lnkAccountNo = (LinkButton)e.CommandSource;
            GridView gview = (GridView)sender;

            if (!string.IsNullOrEmpty(lnkAccountNo.Text))
            {
                //
                AccCus = EnumerateValue(lnkAccountNo.Text);
                if (AccCus == true)//AccountDetails by clicking on Customer Number
                {
                    txtAccountNumber.Text = lnkAccountNo.Text;
                    Panel1.Style["display"] = "none";

                    //GetAccountSummary(lnkAccountNo.Text);
                }
                else if (AccCus == false)//CustomerDetails by clicking on Customer Name
                {


                }

            }

        }

        protected void grdCustomerAccSummary_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[3].Text.Contains("-"))
                {
                    double clearCol = double.Parse(e.Row.Cells[3].Text.Remove(0, 1));
                    e.Row.Cells[3].Text = "(" + clearCol + ")";
                }
                if (e.Row.Cells[6].Text.Contains("-"))
                {
                    double netBalance = double.Parse(e.Row.Cells[6].Text.Remove(0, 1));
                    e.Row.Cells[6].Text = "(" + netBalance + ")";
                }
            }


        }

        public string GetCusID()
        {
            string custId = customerid.Text;
            return custId;
        }

        public string GetUserPermission()
        {
            //ProductCode=3 is Staff
            string Res = null;
            SPWeb web = SPContext.Current.Web;
            if (web.Groups["helpdesk"].ContainsCurrentUser)
            {
                SPGroupCollection gcoll = web.CurrentUser.Groups;
                foreach (SPGroup ng in gcoll)
                {
                    //ListBox1.Items.Add(ng.Name);
                }
                int t = gcoll.Count;
                //Label1.Text = t.ToString();
                return Res = "Yes";
            }
            else
            {

                return Res = "No";
            }

        }

        public bool VerifyUser()
        {
            bool verifyuserIsTrue = false;


            if (CheckUserPermission.Ispermitted("AccountBalance"))
            {
                verifyuserIsTrue = true;
            }
            else
            {
                //show message here
                verifyuserIsTrue = false;
                Panel1.Visible = false;
                string script = "<script language='javascript'>alert('" + "You are not allowed to view other staff accounts other than yours." + "This is however open to Branch Services staff(Ops Heads,CCOs & Tellers)and requires user logs in." + "')</script>";
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);

            }
            return verifyuserIsTrue;
        }

    }
}
