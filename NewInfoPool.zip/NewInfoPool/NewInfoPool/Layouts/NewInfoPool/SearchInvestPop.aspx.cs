﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Web.UI.WebControls;


namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class SearchInvestPop : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {



            }
        }

        protected void Btn_Search_Click(object sender, EventArgs e)
        {
            try
            {
                LBL_Message.Text = "";
                GridView1.Visible = false;
                AccountEnquiryGhana account = new AccountEnquiryGhana();

                long accountNo = 0;
                if (long.TryParse(TXT_AccountNo.Text, out accountNo))
                {
                    AccountSearchInfo info = account.getAccountSerachByAccountNumber(TXT_AccountNo.Text);
                    if (info.accountSearchByAcctTitle[0].accountname != "")
                    {
                        if (Page.Request.QueryString["SrchType"] == null)
                        {
                            GridView1.Visible = true;


                            AccountSearchByAcctTitle[] accresult = info.accountSearchByAcctTitle;
                            ViewState["AccountSearchList"] = accresult;
                            GridView1.DataSource = info.accountSearchByAcctTitle;
                            GridView1.DataBind();



                            //GridView1.DataSource = info.accountSearchByAcctTitle;
                            //GridView1.DataBind();
                        }
                        else
                        {
                            GridView2.Visible = true;

                            AccountSearchByAcctTitle[] accresult = info.accountSearchByAcctTitle;
                            ViewState["AccountSearchList"] = accresult;
                            GridView2.DataSource = info.accountSearchByAcctTitle;
                            GridView2.DataBind();
                        }
                    }
                    else
                        LBL_Message.Text = "No Match Found";
                }
                else
                {
                    AccountSearchInfo info = account.getAccountSerachByAccountTitle(TXT_AccountNo.Text);
                    if (info.accountSearchByAcctTitle[0].accountname != "")
                    {
                        if (Page.Request.QueryString["SrchType"] == null)
                        {
                            GridView1.Visible = true;
                            AccountSearchByAcctTitle[] accresult = info.accountSearchByAcctTitle;
                            ViewState["AccountSearchList"] = accresult;
                            GridView1.DataSource = info.accountSearchByAcctTitle;
                            GridView1.DataBind();
                        }
                        else
                        {
                            GridView2.Visible = true;
                            AccountSearchByAcctTitle[] accresult = info.accountSearchByAcctTitle;
                            ViewState["AccountSearchList"] = accresult;
                            GridView2.DataSource = info.accountSearchByAcctTitle;
                            GridView2.DataBind();
                        }

                    }
                    else
                        LBL_Message.Text = "No Match Found";
                }
            }
            catch
            {
                LBL_Message.Text = "Error in connection";
            }
        }

        private const string ASCENDING = " ASC";
        private const string DESCENDING = " DESC";
        public SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }

        public SortDirection GridViewSortDirection2
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }

        protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;

            if (GridViewSortDirection == SortDirection.Ascending)
            {
                GridViewSortDirection = SortDirection.Descending;
                SortGridView(sortExpression, DESCENDING);
            }
            else
            {
                GridViewSortDirection = SortDirection.Ascending;
                SortGridView(sortExpression, ASCENDING);
            }

        }
        protected void GridView2_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;

            if (GridViewSortDirection2 == SortDirection.Ascending)
            {
                GridViewSortDirection2 = SortDirection.Descending;
                SortGridView2(sortExpression, DESCENDING);
            }
            else
            {
                GridViewSortDirection2 = SortDirection.Ascending;
                SortGridView2(sortExpression, ASCENDING);
            }

        }
        private void SortGridView(string sortExpression, string direction)
        {

            AccountSearchByAcctTitle[] searchResultList = (AccountSearchByAcctTitle[])ViewState["AccountSearchList"];
            DataTable dt = new DataTable();
            dt.Columns.Add("accountname");
            dt.Columns.Add("customerid");
            dt.Columns.Add("nam_product");
            dt.Columns.Add("accountno");
            dt.Columns.Add("currencyDesc");

            dt.Columns["accountname"].DataType = System.Type.GetType("System.String");
            dt.Columns["customerid"].DataType = System.Type.GetType("System.String");
            dt.Columns["nam_product"].DataType = System.Type.GetType("System.String");
            dt.Columns["accountno"].DataType = System.Type.GetType("System.String");
            dt.Columns["currencyDesc"].DataType = System.Type.GetType("System.String");



            foreach (AccountSearchByAcctTitle accsrlist in searchResultList)
            {
                DataRow dr = dt.NewRow();
                dr["accountname"] = accsrlist.accountname;
                dr["customerid"] = accsrlist.customerid;
                dr["nam_product"] = accsrlist.nam_product;
                dr["accountno"] = accsrlist.accountno;
                dr["currencyDesc"] = accsrlist.currencyDesc;
                dt.Rows.Add(dr);
            }

            DataView dv = new DataView(dt);
            dv.Sort = sortExpression + direction;
            GridView1.DataSource = dv;
            GridView1.DataBind();

            ////  You can cache the DataTable for improving performance
            //DataTable dt = GetData().Tables[0];

            //DataView dv = new DataView(dt);
            //dv.Sort = sortExpression + direction;

            //GridView1.DataSource = dv;
            //GridView1.DataBind();
        }

        private void SortGridView2(string sortExpression, string direction)
        {

            AccountSearchByAcctTitle[] searchResultList = (AccountSearchByAcctTitle[])ViewState["AccountSearchList"];
            DataTable dt = new DataTable();
            dt.Columns.Add("accountname");
            dt.Columns.Add("customerid");
            dt.Columns.Add("nam_product");
            dt.Columns.Add("accountno");
            dt.Columns.Add("currencyDesc");

            dt.Columns["accountname"].DataType = System.Type.GetType("System.String");
            dt.Columns["customerid"].DataType = System.Type.GetType("System.String");
            dt.Columns["nam_product"].DataType = System.Type.GetType("System.String");
            dt.Columns["accountno"].DataType = System.Type.GetType("System.String");
            dt.Columns["currencyDesc"].DataType = System.Type.GetType("System.String");



            foreach (AccountSearchByAcctTitle accsrlist in searchResultList)
            {
                DataRow dr = dt.NewRow();
                dr["accountname"] = accsrlist.accountname;
                dr["customerid"] = accsrlist.customerid;
                dr["nam_product"] = accsrlist.nam_product;
                dr["accountno"] = accsrlist.accountno;
                dr["currencyDesc"] = accsrlist.currencyDesc;
                dt.Rows.Add(dr);
            }

            DataView dv = new DataView(dt);
            dv.Sort = sortExpression + direction;
            GridView2.DataSource = dv;
            GridView2.DataBind();

        }
    }
}
