﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using AccountReportSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class BranchesReport : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadBranches();
            }
        }


        public void LoadBranches()
        {
            AccountReport report = new AccountReport();

            BranchesInfo braInfo = report.getBranches("");
            Branches[] bran = braInfo.branches;
            grdBranch.DataSource = bran;
            grdBranch.DataBind();
          
        }
    }
}
