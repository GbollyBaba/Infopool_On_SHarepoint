﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using NewInfoPool.Utilities;
using System.Linq;
using Microsoft.SharePoint.Linq;
using System.Text;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class CustomerODFacility : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenSrchPopup()");
            }
        }

        protected void btnGetOd_Click(object sender, EventArgs e)
        {
            string AccountNumber = txtAccountNumber.Text;
            bool CanView = false;
            if (txtAccountNumber.Text == "")
            {
                return;
            }
            AccountEnquiryGhana en = new AccountEnquiryGhana();
            AccountEnquiryGhana2 accenq = new AccountEnquiryGhana2();
            CustomerAcctsInfo info = en.getAccountSummary(txtAccountNumber.Text);
            CustomerODLimitInfo odInfo = accenq.getCustomerODLimit(txtAccountNumber.Text);
            CustomerODLimit[] cusOdLimit = odInfo.customerODLimit;
            if (info.acctsumm[0] != null)
            {
                #region
                //Check to see if the user can view this account
                if (info.acctsumm[0].flgempacct == "Y" && info.acctsumm[0].flgstaff == "N")
                {
                    //Staff or Employee Account
                    CanView = VerifyUser();
                }
                else if (info.acctsumm[0].flgempacct == "Y" && info.acctsumm[0].flgstaff == "Y")
                {
                    //Staff or Employee Account
                    CanView = VerifyUser();
                }
                else if (info.acctsumm[0].flgempacct == "N" && info.acctsumm[0].flgstaff == "Y")
                {
                    //Staff or Employee Account
                    CanView = VerifyUser();
                }
                else if (info.acctsumm[0].flgempacct == "N" && info.acctsumm[0].flgstaff == "N")
                {
                    //This is for individual
                    CanView = true;
                }
                #endregion
                if (CanView)
                {
                    if (info.acctsumm[0].accountname != null)
                    {
                        tblContent.Visible = true;
                        Panel1.Style["display"] = "block";

                        lkbAccountName.Text = info.acctsumm[0].accountname;
                    }
                    if (info.acctsumm[0].hasCOT == "1")
                    {
                        lnkCOT.Visible = true;
                        lnkCOT.Attributes.Add("onclick", "window.open('COTDetails.aspx?Cdetails=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                    }
                    if (info.acctsumm[0].accountNo != null)
                    {
                        lblAccountNumber.Text = info.acctsumm[0].accountNo;
                        lblAccountNumber.Attributes.Add("onclick", "window.open('AccountDetails.aspx?accountNo=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                    }
                    string customerToken = info.customerID;
                    string[] cusToken = customerToken.Split('~');//To get Customer ID
                    lnkMandate.Visible = true;
                    lnkMandate.Attributes.Add("onclick", "window.open('AccountMandate.aspx?AccMandate=" + cusToken[1].ToString() + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

                    if (info.acctsumm[0].accountproduct != null)
                    {
                        lblAccountType.Text = info.acctsumm[0].accountproduct;
                    }
                    if (info.acctsumm[0].ODLimit != null && info.acctsumm[0].ODLimit != "")
                    {
                        lblOdLimit.Text = info.acctsumm[0].ODLimit;
                    }
                    else
                        lblOdLimit.Text = "0.00";

                    if (cusOdLimit != null)
                    {
                        if (cusOdLimit[0] == null)
                        {

                        }
                        else
                        {
                            grdCustomerOdLimitInfo.DataSource = cusOdLimit;
                            grdCustomerOdLimitInfo.DataBind();
                            tblcustomerAccSummaryId.Visible = true;
                        }
                    }
                    else
                    {
                        tblcustomerAccSummaryId.Visible = false;
                    }
                }
            }

        }

        public bool VerifyUser()
        {
            bool verifyuserIsTrue = false;
            if (Session["UserAccount"] != null)
            {
                //Get the session value
                //Compare sessionvalue with txtAccountNumber
                string sessionvalue = Session["UserAccount"].ToString();
                int returnvalue = string.Compare(txtAccountNumber.Text, sessionvalue);
                if (returnvalue == 0)//it shows that the user is checking his account
                {
                    //Show The details for the user
                    verifyuserIsTrue = true;
                }
                else
                {
                    //check to see if this user belongs to the view group
                    if (CheckUserPermission.Ispermitted("AccountBalance"))
                    {
                        //To get here it shows that the account is not the user's Account ,but a staff or employee Account
                        //You are permitted to view this account due to the group previledge the user belongs
                        verifyuserIsTrue = true;
                    }
                    else
                    {
                        //show message here
                        verifyuserIsTrue = false;
                        Panel1.Visible = false;
                        string script = "<script language='javascript'>alert('" + "You are not allowed to view other staff accounts other than yours." + "This is however open to Branch Services staff(Ops Heads,CCOs & Tellers)and requires user logs in." + "')</script>";
                        Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);

                    }
                }
            }
            else
            {
                SPSite site = SPContext.Current.Site;
                using (SPWeb web = site.OpenWeb())
                {
                    SPUser usr = web.EnsureUser(SPContext.Current.Web.CurrentUser.LoginName);
                    string username = usr.LoginName;
                    bool valid = AccountVerificationType(txtAccountNumber.Text.Trim(), username, site.RootWeb.Url);
                    if (!valid)
                    {
                        //check to see if this user belongs to the view group
                        if (CheckUserPermission.Ispermitted("AccountBalance"))
                        {
                            verifyuserIsTrue = true;
                        }
                        else
                        {
                            //show message here
                            verifyuserIsTrue = false;
                            Panel1.Visible = false;
                            string script = "<script language='javascript'>alert('" + "You are not allowed to view other staff accounts other than yours." + "This is however open to Branch Services staff(Ops Heads,CCOs & Tellers)and requires user logs in." + "')</script>";
                            Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);

                        }
                    }
                    else
                    {
                        verifyuserIsTrue = true;
                    }
                }
            }
            return verifyuserIsTrue;
        }

        private bool AccountVerificationType(string Accountnumber, string UserName, string Currenturl)
        {
            bool validuser = false;

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (StaffSalaryAccountEntity AccSalaryContext = new StaffSalaryAccountEntity(Currenturl))
                {
                    string[] usernameToken = UserName.Split('\\');
                    var menuitem = (from accSalary in AccSalaryContext.StaffSalaryAccount
                                    where accSalary.Title == usernameToken[1] && accSalary.SalaryAccountNumber == Accountnumber
                                    select new { Valid = "true" }).FirstOrDefault();
                    if (menuitem != null && menuitem.Valid == "true")
                    {
                        Session["UserAccount"] = Accountnumber;
                        validuser = true;
                    }
                    else if (menuitem == null)
                        validuser = false;

                }

            });
            return validuser;
        }
        StringBuilder alert2 = new StringBuilder();


        //    public void testing()
        //    {
        //   alert2.= "<script language='javascript'>"+
        ////    window.alert=function( alertMessage )
        ////        {
        ////            var alertBox = "";
        ////                    alertBox +="<div style=\"width:350px;height:70px\" class=\"alertBoxIn alertPosition\" >";
        ////                             alertBox  +="<img src=\"n\" style=\"position: relative; top: 1%; left: 2%\" /></td>";
        ////                             alertBox +="<SPAN style=\"position: relative; top:-30%; left: 12%\">"+alertMessage+"</SPAN>";
        ////                             alertBox  +="<input style=\"position: relative; top:20%; left:10%\" type=\"button\" value=\"    Ok      \" onclick=\"closeAlert();\" />";
        ////                    alertBox+="</div>";
        ////            document.getElementById("alertPanel").innerHTML = alertBox;
        ////            document.getElementById("alertPanel").focus();
        ////         }

        ////        function closeAlert()
        ////        {
        ////            var alertBox =  document.getElementById("alertPanel");
        ////            alertBox.innerHTML ="";
        ////        }

        ////</script>
        //}


    }
}
