﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Drawing;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class CotDetails : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.Request.QueryString["Cdetails"] != null)
            {
                string AccountNumber = Page.Request.QueryString["Cdetails"].ToString();
                AccountEnquiryGhana en = new AccountEnquiryGhana();             
                COTDetailsInfo cotDetails = en.getCOTDetails(AccountNumber);
                if (cotDetails.cOTDetails[0] != null)
                {
                    lblCotMessage.Style["display"] = "none";
                    lblAccountNumber.Text = AccountNumber;
                    if (cotDetails.cOTDetails != null)
                    {
                        grdCotDetails.DataSource = cotDetails.cOTDetails;
                        grdCotDetails.DataBind();
                    }
                }
                else
                {
                    lblCotMessage.Style["display"] = "block";
                    lblCotMessage.Text = "No Record Found";
                    lblCotMessage.ForeColor = Color.Red;
                }
            }
        }
    }
}
