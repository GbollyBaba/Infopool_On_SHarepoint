﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Utilities.ActiveDirectory;
using System.DirectoryServices;
using AuditSpace;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccNumber : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            
            try
            {
                //Get the Current UserName
                string username=SPContext.Current.Web.CurrentUser.LoginName;
                string[] loginname = username.Split('\\');
                string staffAcountNumber=txtStaffAccountNumber.Text;
                string StaffStatus="A";
               string staffEmail =txtStaffEmail.Text;
                string staffNumber=txtStaffNo.Text;
                AccountAudit audit = new AccountAudit();
                string result = audit.getInsertStaffAccount(loginname[1], staffAcountNumber, StaffStatus, staffEmail, staffNumber);
               if (result == "00")//means Success
               {

                   Response.Redirect("AccountBalance.aspx");
               }
               else
               {
                   MessagePrompt.ShowMessage(this, "Contac your Administrator");
               }
                
                
            }
            catch (Exception)
            {
               //LBL_Message.Visible = true;
               // LBL_Message.Text = ex.Message;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            
        }
    }
}
