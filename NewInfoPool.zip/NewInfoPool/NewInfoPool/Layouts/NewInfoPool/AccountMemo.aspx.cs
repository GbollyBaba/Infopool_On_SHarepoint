﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using NewInfoPool.Utilities;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccountMemo : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String memobuilder = "\\n";
            if (Page.Request.QueryString["Memo"] != null)
            {
                string CustomerID = Page.Request.QueryString["Memo"].ToString();

                AccountEnquiryGhana2 enqAccMemo = new AccountEnquiryGhana2();
                AccountMemoInfo memoinfo = enqAccMemo.getAccounMemoInfo(CustomerID);

                if (memoinfo.description != null)
                {
                                   


                    //for (int i = 0; i < memoinfo.accountMemo.Length; i++)
                    //{
                    //    memobuilder += "\\n" + memoinfo.accountMemo[i].memotext;
                    //}
                    grdMemo.DataSource = memoinfo.accountMemo;
                    grdMemo.DataBind();

                   // grdMemo.DataSource = memobuilder;
                   // grdMemo.DataBind();
                }

                       
            }
        }
    }
}
