﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using NewInfoPool.Utilities;
using System.Linq;
using System.Text;
namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class HomePage : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                if (!IsPostBack)
                {
                    if (Session["StaffSalaryAcc"] != null)
                    {

                    }
                    else
                    {
                        //get to the active directory and get the ssa

                        SPUser Currentuser = SPContext.Current.Web.CurrentUser;
                        string[] loginname = Currentuser.LoginName.Split('\\');
                        AccountEnquiryGhana en = new AccountEnquiryGhana();

                        loginname[1] = "igwee";
                        //Fms080811$$
                        int result = GetCurrentUserActiveDirectoryInfo.GetActiveDirectoryInfo(loginname[1].ToString(),en);

                        if (result == 1)//
                        {
                            StringBuilder builderinfo = new StringBuilder();
                            builderinfo.AppendLine("Current User: " + Currentuser.Name);
                            builderinfo.AppendLine("Date :" + DateTime.Now.ToString());
                            //User can proceed on 
                        }
                        else if (result == 0)
                        {
                            //Register Staff Account Info to Active Directory
                            Response.Redirect("AccNumber.aspx");
                        }
                        else if (result==null)
                        {
                            string script = "<script language='javascript'>alert('" + "The server is not operational.Contact Your System Administrator" + "')</script>";
                            Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
                        }

                    }
                    FillApplicatioDropDown();

                }
            }
            catch (Exception ex)
            {
                //Response.Write(ex.Message);
                string script = "<script language='javascript'>alert('" + ex.Message + "')</script>";
                Page.ClientScript.RegisterClientScriptBlock(GetType(), "Register", script);
            }
        }

        public void FillApplicatioDropDown()
        {
            try
            {
                string url = SPContext.Current.Web.Url;

                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    SPSite root = new SPSite(url);
                    SPWeb web = root.OpenWeb();
                    web.AllowUnsafeUpdates = true;
                    SPList selectedList = web.Lists["Applications"];
                    string query = "<Query><OrderBy><FieldRef Name=\"Order0\" Ascending=\"True\" /></OrderBy></Query>";
                    SPQuery SPQuery = new Microsoft.SharePoint.SPQuery();
                    SPQuery.Query = query;
                    SPListItemCollection collection = selectedList.GetItems(SPQuery);
                    DDL_Applications.Items.Clear();
                    foreach (SPListItem item in collection)
                    {
                        DDL_Applications.Items.Add(new ListItem(item["Title"].ToString(), item["URL"].ToString() + ";##;" + item["WIndow Type"].ToString()));
                    }




                    web.AllowUnsafeUpdates = false;
                    if (web != null)
                        web.Dispose();
                    if (root != null)
                        root.Dispose();

                });

            }
            catch (Exception ex)
            {
                Response.Write("Error Loading Application DropDown" + ex.Message);
            }

        }
        public bool ConfirmUserSalaryAccoount()
        {
            //Check to see if the user has Salary Account
            //Get the username of the current user
            SPSite site = SPContext.Current.Site;
            string loginName = site.RootWeb.CurrentUser.LoginName;

            bool validuser = false;

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (StaffSalaryAccountEntity AccSalaryContext = new StaffSalaryAccountEntity(site.RootWeb.Url))
                {
                    string[] usernameToken = loginName.Split('\\');
                    var menuitem = (from accSalary in AccSalaryContext.StaffSalaryAccount
                                    where accSalary.Title == usernameToken[1] && accSalary.SalaryAccountNumber != null
                                    select new { Valid = "true", Accountnumber = accSalary.SalaryAccountNumber }).FirstOrDefault();
                    if (menuitem != null && menuitem.Valid == "true")
                    {
                        Session["UserAccount"] = menuitem.Accountnumber;
                        validuser = true;
                    }
                    else if (menuitem == null)
                        validuser = false;

                }

            });
            return validuser;
        }
    }
}
