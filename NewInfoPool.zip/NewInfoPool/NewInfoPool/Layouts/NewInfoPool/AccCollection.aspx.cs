﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Linq;
using Microsoft.SharePoint.Linq;
using Utilities.Branch;
using System.Web.UI.WebControls;
using System.Drawing;
using NewInfoPool.Utilities;

namespace NewInfoPool.Layouts.NewInfoPool
{
    public partial class AccCollection : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Branch List Here
                this.btnSearch.Attributes.Add("onclick", "javascript:return OpenSrchPopup()");
                dtcStartDate.SelectedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                dtcEndDate.SelectedDate = DateTime.Today;
                BranchList();
            }
        }

       
        protected void btnGetColHis_Click(object sender, EventArgs e)
        {

            //Check to see that the user enter value to the box
            if (string.IsNullOrEmpty(txtAccountNumber.Text))
            {
                //Prompt the user to type something
            }
            else
            {
                string AccountNumber = txtAccountNumber.Text.Trim();
                string startdate = dtcStartDate.SelectedDate.ToString("dd-MMM-yyyy");
                string enddate = dtcEndDate.SelectedDate.ToString("dd-MMM-yyyy");

                GetAccountCollection(AccountNumber, startdate, enddate);
            }
        }

        private void GetAccountCollection(string AccountNumber, string startdate, string enddate)
        {
            AccountEnquiryGhana2 AccEnq = new AccountEnquiryGhana2();
            CustomerAcctsWithTransactionInfoWithBranch cusTransBranch = AccEnq.getAccountSummaryANDTransactions(AccountNumber, startdate, enddate);

            if (cusTransBranch.acctsumm != null)
            {
            }
            if (cusTransBranch.acctsumm[0].accountname != null)
            {
                tblContent.Visible = true;
                lkbAccountName.Text = cusTransBranch.acctsumm[0].accountname;
            }
            if (cusTransBranch.acctsumm[0].hasCOT == "1")
            {
                lnkCOT.Visible = true;
                lnkCOT.Attributes.Add("onclick", "window.open('COTDetails.aspx?Cdetails=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

            }
            if (cusTransBranch.acctsumm[0].accountNo != null)
            {
                lblAccountNumber.Text = cusTransBranch.acctsumm[0].accountNo;
                lblAccountNumber.Attributes.Add("onclick", "window.open('AccountDetails.aspx?accountNo=" + AccountNumber + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");

            }
            string customerToken = cusTransBranch.customerID;
            if (cusTransBranch.acctsumm[0].accountproduct != null)
            {
                lblAccountType.Text = cusTransBranch.acctsumm[0].accountproduct;
            }
            string[] cusToken = customerToken.Split('~');//To get Customer ID
            lnkMandate.Visible = true;
            lnkMandate.Attributes.Add("onclick", "window.open('AccountMandate.aspx?AccMandate=" + cusToken[1].ToString() + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
            lblDatePeriod.Text = startdate + "to" + enddate;



            AccountEnquiryGhana2 accenq = new AccountEnquiryGhana2();
            CustomerAcctsWithTransactionInfoWithBranch cusAccTransWithBranch = accenq.getAccountSummaryANDTransactions(AccountNumber, startdate, enddate);
            TranDetailsWithBranch[] cusAccWithTransWithBranch = cusAccTransWithBranch.acctsumm[0].tranDetails;
            
            TableCell branchnamecell = null;
            TableCell Printcollectionreportforcell = null;
            TableCell subTotalforcell = null;
            //check to see what the user pick from dropdown
            TableRow SummaryrowNew = new TableRow();
            SummaryrowNew.BackColor = Color.DarkGray;
            SummaryrowNew.ForeColor = Color.White;
            
            AccCollSumary.Controls.Add(SummaryrowNew);

            TableCell TxtDatecell = new TableCell();
            TxtDatecell.Width = Unit.Percentage(10);
            Label lblTxtDateName = new Label();
            lblTxtDateName.Text = "Tnt Date";
            TxtDatecell.Controls.Add(lblTxtDateName);
            SummaryrowNew.Controls.Add(TxtDatecell);


            TableCell Descrcell = new TableCell();
            Descrcell.Width = Unit.Percentage(60);
            Label Descr = new Label();
            Descr.Text = "Description";
            Descrcell.Controls.Add(Descr);
            SummaryrowNew.Controls.Add(Descrcell);



            TableCell VDate = new TableCell();
            VDate.Width = Unit.Percentage(15);
            VDate.HorizontalAlign = HorizontalAlign.Center;
            Label lblVdate = new Label();
            lblVdate.Text = "Value Date";
            VDate.Controls.Add(lblVdate);
            SummaryrowNew.Controls.Add(VDate);

            TableCell lodgeg = new TableCell();
            lodgeg.Width = Unit.Percentage(15);
            lodgeg.HorizontalAlign = HorizontalAlign.Center;
            Label lblVlodge = new Label();
            lblVlodge.Text = "Lodgement";
            lodgeg.Controls.Add(lblVlodge);
            SummaryrowNew.Controls.Add(lodgeg);

            if (drpBranch.SelectedIndex == 0)//All Branches
            {


                foreach (ListItem itembranch in drpBranch.Items)
                {
                    if (itembranch.Value == "-1")
                    { continue; }
                    if (cusAccWithTransWithBranch != null && cusAccWithTransWithBranch[0]!=null)
                    {
                        Decimal decnumber = cusAccWithTransWithBranch.Where(a => a.branchid == itembranch.Value).Sum(a => Convert.ToDecimal(("0" + a.lodgement)));

                        if (decnumber == 0)
                        { continue; }

                        Table accountcollRowReport = new Table();
                        accountcollRowReport.Width = Unit.Percentage(100);
                        accountcollRowReport.CellPadding = 3;
                        accountcollRowReport.CellSpacing = 1;
                        accountcollRowReport.BorderStyle = BorderStyle.Solid;
                        accountcollRowReport.BorderWidth = Unit.Pixel(1);
                        accountcollRowReport.BorderColor = Color.Gray;

                        TableRow rowNew = new TableRow();
                        accountcollRowReport.Controls.Add(rowNew);
                        TablePaceHolder.Controls.Add(accountcollRowReport);

                        branchnamecell = new TableCell();
                        Label lblBranchName = new Label();
                        lblBranchName.Text = itembranch.Text;
                        branchnamecell.Controls.Add(lblBranchName);
                        branchnamecell.Font.Bold = true;
                        rowNew.Controls.Add(branchnamecell);


                        Printcollectionreportforcell = new TableCell();
                        LinkButton cusDeatilsLink = new LinkButton();
                        //cusDeatilsLink.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + accimgDtr.cod_cust_id + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                        cusDeatilsLink.Text = "Print Collection Report for " + itembranch.Text;
                        Printcollectionreportforcell.Controls.Add(cusDeatilsLink);
                        rowNew.Controls.Add(Printcollectionreportforcell);

                        subTotalforcell = new TableCell();
                        subTotalforcell.Font.Bold = true;
                        Label lblname = new Label();
                        lblname.Text = "Sub Total for &nbsp&nbsp" + itembranch.Text + "&nbsp&nbsp" + decnumber.ToString();
                        subTotalforcell.HorizontalAlign = HorizontalAlign.Right;
                        subTotalforcell.Controls.Add(lblname);
                        rowNew.Controls.Add(subTotalforcell);

                        //Collection for a particular current branch
                        var grdcoll = cusAccWithTransWithBranch.Where(c => c.branchid == itembranch.Value).ToList();
                        int CollLenght = grdcoll.Count;

                        // Current row count
                        int rowCtr;
                        Table tbl = new Table();
                        tbl.Width = Unit.Percentage(100);
                        TablePaceHolder.Controls.Add(tbl);

                        for (rowCtr = 0; rowCtr < grdcoll.Count; rowCtr++)
                        {
                            if (grdcoll[rowCtr].lodgement == "")
                            {
                                continue;
                            }
                            // Create new row and add it to the table.
                            TableRow tRow = new TableRow();
                            tRow.BorderWidth = Unit.Pixel(0);
                            tbl.Rows.Add(tRow);
                            TableCell tdate = new TableCell();
                            tdate.BackColor = Color.FromArgb(235, 235, 235);
                            tdate.BorderColor = Color.FromArgb(235, 235, 235);
                            TableCell description = new TableCell();
                            description.BackColor = Color.FromArgb(235, 235, 235);
                            description.BorderColor = Color.FromArgb(235, 235, 235);
                            TableCell valuedate = new TableCell();
                            valuedate.BackColor = Color.FromArgb(235, 235, 235);
                            valuedate.BorderColor = Color.FromArgb(235, 235, 235);
                            TableCell lodgement = new TableCell();
                            lodgement.BackColor = Color.FromArgb(235, 235, 235);
                            lodgement.BorderColor = Color.FromArgb(235, 235, 235);

                            tdate.Text = grdcoll[rowCtr].tDate;
                            tdate.Width = Unit.Percentage(10);
                            tRow.Controls.Add(tdate);

                            description.Text = grdcoll[rowCtr].desc;
                            description.Width = Unit.Percentage(60);
                            tRow.Controls.Add(description);

                            valuedate.Text = grdcoll[rowCtr].valueDate;
                            valuedate.Width = Unit.Percentage(15);
                            valuedate.HorizontalAlign = HorizontalAlign.Center;
                            tRow.Controls.Add(valuedate);

                            lodgement.Text = grdcoll[rowCtr].lodgement;
                            lodgement.Width = Unit.Percentage(15);
                            lodgement.HorizontalAlign = HorizontalAlign.Center;
                            tRow.Controls.Add(lodgement);
                        }
                    }
                }

            }
            else if (drpBranch.SelectedIndex > 0)//loop through a particular branch
            {
                if (cusAccWithTransWithBranch != null || cusAccWithTransWithBranch[0] != null)
                {

                    Decimal decnumber = cusAccWithTransWithBranch.Where(a => a.branchid == drpBranch.SelectedItem.Value).Sum(a => Convert.ToDecimal(("0" + a.lodgement)));
                    TableRow rowNew = new TableRow();
                    AccountCollTab.Controls.Add(rowNew);

                    branchnamecell = new TableCell();
                    Label lblBranchName = new Label();
                    lblBranchName.Text = drpBranch.SelectedItem.Text;
                    branchnamecell.Controls.Add(lblBranchName);
                    rowNew.Controls.Add(branchnamecell);


                    Printcollectionreportforcell = new TableCell();
                    LinkButton cusDeatilsLink = new LinkButton();
                    //cusDeatilsLink.Attributes.Add("onclick", "window.open('CustomerDetails.aspx?CusNum=" + accimgDtr.cod_cust_id + "&" + "', 'newwindow','toolbar=yes,location=no,menubar=no,width=600,height=600,resizable=no,scrollbars=yes,top=200,left=250');return false;");
                    cusDeatilsLink.Text = "Print Collection Report for " + drpBranch.SelectedItem.Text;
                    Printcollectionreportforcell.Controls.Add(cusDeatilsLink);
                    rowNew.Controls.Add(Printcollectionreportforcell);

                    subTotalforcell = new TableCell();
                    Label lblname = new Label();
                    lblname.Text = decnumber.ToString();
                    subTotalforcell.Controls.Add(lblname);
                    rowNew.Controls.Add(subTotalforcell);

                    if (chkDisplay.Checked)
                    {
                        var grdcoll = cusAccWithTransWithBranch.Where(c => c.branchid == drpBranch.SelectedItem.Value).ToList();
                        #region
                        //GridView gridview = new GridView();
                        //gridview.ID = "gridData";
                        //gridview.AutoGenerateColumns = false;

                        //foreach (var itembran in grdcoll)
                        //{
                        //BoundField bTDate = new BoundField();
                        //bTDate.DataField = "TDate";
                        //bTDate.HeaderText = "Txn Date";
                        //gridview.Columns.Add(bTDate);

                        //BoundField bDescrption = new BoundField();
                        //bDescrption.DataField = "desc";
                        //bDescrption.HeaderText = "Description";
                        //gridview.Columns.Add(bDescrption);

                        //BoundField bValueDate = new BoundField();
                        //bValueDate.DataField = "valueDate";
                        //bValueDate.HeaderText = "Value Date";
                        //gridview.Columns.Add(bValueDate);

                        //BoundField blodgement = new BoundField();
                        //blodgement.DataField = "lodgement";
                        //blodgement.HeaderText = "Lodgement";
                        //gridview.Columns.Add(blodgement);
                        //}

                        //gridview.DataSource = grdcoll;
                        //gridview.DataBind();
                        #endregion
                        grdAccCollection.DataSource = grdcoll;
                        grdAccCollection.DataBind();
                    }
                }

            }

        }


        private void BranchList()
        {
            drpBranch.Items.Clear();
            ListItem Item = new ListItem();
            Item.Text = "All Branches";
            Item.Value = "-1";
            drpBranch.Items.Add(Item);
            drpBranch.AppendDataBoundItems = true;

            string url = SPContext.Current.Web.Url;

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (BranchCodesEntity BranchCodesContext = new BranchCodesEntity(SPContext.Current.Web.Url))
                {

                    var branchCodes = (from branchcode in BranchCodesContext.BranchCodes
                                       select new { Code = branchcode.Code, BranchName = branchcode.Title }).ToList();

                    //drpBranch.Items.Clear();
                    foreach (var item in branchCodes)
                    {
                        drpBranch.Items.Add(new ListItem(item.BranchName.ToString(), item.Code.ToString()));
                    }
                }

            });
        }
    }
}