﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

    public class MessagePrompt
    {
        public static void ShowMessage(Page target, string message)
        {
            string alert = "<script language=\"javascript\">" + "alert('" + message + "');" + "<" + "/Script>";
            target.ClientScript.RegisterStartupScript(target.GetType(), "Notice", alert);
        }
    }



    
